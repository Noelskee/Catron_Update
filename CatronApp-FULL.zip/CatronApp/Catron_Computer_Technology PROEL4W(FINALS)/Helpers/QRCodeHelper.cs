﻿// ============================================================
//  QRCodeHelper.cs
//  Namespace: Catron_Computer_Technology_PROEL4W_FINALS_.Helpers
//
//  Purpose:
//    Static helper that generates QR code images for the GCash
//    payment flow on the customer payment page (Views/Customer/Pay).
//
//    The QR code encodes the order reference text (amount, order
//    number, store name) as a PNG image, then returns it Base64-
//    encoded so it can be embedded directly in an <img> tag:
//
//      <img src="data:image/png;base64,@Model.QrCodeBase64" />
//
//  Dependencies:
//    QRCoder NuGet package (QRCoder.QRCodeGenerator, PngByteQRCode)
//
//  Usage:
//    string? base64 = QRCodeHelper.GenerateBase64("GCash Payment\nAmount: PHP 500");
//    if (base64 != null)
//        // embed in view
// ============================================================

namespace Catron_Computer_Technology_PROEL4W_FINALS_.Helpers
{
    /// <summary>
    /// Generates Base64-encoded PNG QR codes for display on the GCash payment page.
    /// Returns null on any generation failure so the view can show a fallback.
    /// </summary>
    public static class QRCodeHelper
    {
        // ────────────────────────────────────────────────────────────────
        //  GenerateBase64
        // ────────────────────────────────────────────────────────────────

        /// <summary>
        /// Creates a QR code from the provided text and returns it as a
        /// Base64-encoded PNG string ready to embed in an HTML &lt;img&gt; src attribute.
        ///
        /// Error correction level Q (≈25% recovery) is used so the QR code
        /// remains scannable even if partially obscured or printed imperfectly.
        ///
        /// Pixel size of 10 produces a reasonably large image without being huge.
        /// </summary>
        /// <param name="text">
        ///   The text to encode in the QR code.
        ///   For GCash payments this typically includes the amount,
        ///   order number, and store name.
        /// </param>
        /// <returns>
        ///   Base64 PNG string on success, or null if generation fails
        ///   (e.g. if the QRCoder library throws an unexpected exception).
        /// </returns>
        public static string? GenerateBase64(string text)
        {
            try
            {
                // Step 1: Create QR code data from the input text.
                //   ECCLevel.Q = Error Correction Level Q (25% data recovery).
                using var gen = new QRCoder.QRCodeGenerator();
                var data = gen.CreateQrCode(text, QRCoder.QRCodeGenerator.ECCLevel.M);

                // Step 2: Render the QR code data as a PNG byte array.
                //   pixelsPerModule = 10 → each QR module is a 10×10 pixel block.
                using var code = new QRCoder.PngByteQRCode(data);
                byte[] png = code.GetGraphic(20); // larger modules = easier to scan on phone

                // Step 3: Convert the PNG bytes to a Base64 string for the <img> tag.
                return Convert.ToBase64String(png);
            }
            catch
            {
                // Silently return null so the payment view can degrade gracefully
                // (e.g. show manual payment instructions instead of the QR code).
                return null;
            }
        }
    }
}
