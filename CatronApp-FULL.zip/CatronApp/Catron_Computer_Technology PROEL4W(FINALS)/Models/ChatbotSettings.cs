namespace Catron_Computer_Technology_PROEL4W_FINALS_.Models
{
    public class ChatbotSettings
    {
        public string ApiKey { get; set; } = "";
        public string ApiUrl { get; set; } =
            "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent";
        public string SystemPrompt { get; set; } = "";
    }
}
