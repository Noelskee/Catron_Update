// ============================================================
//  Review.cs — ratings + Q&A + official Catron store replies
// ============================================================

using System.ComponentModel.DataAnnotations;

namespace Catron_Computer_Technology_PROEL4W_FINALS_.Models
{
    public class Review
    {
        public int Id { get; set; }
        public int CustomerId { get; set; }
        public int ProductId { get; set; }
        public int OrderId { get; set; }

        [Range(1, 5)]
        public int Rating { get; set; }

        [StringLength(1000)]
        public string? Comment { get; set; }

        [StringLength(2000)]
        public string? ImageUrls { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        public Customer Customer { get; set; } = null!;
        public Product Product { get; set; } = null!;
        public ICollection<ReviewReply> Replies { get; set; } = new List<ReviewReply>();
    }

    /// <summary>
    /// Thread under a review: customer Q&amp;A or official Catron Ops reply.
    /// CustomerId set for customer messages; AdminId + IsOfficialReply for store.
    /// </summary>
    public class ReviewReply
    {
        public int Id { get; set; }
        public int ReviewId { get; set; }

        /// <summary>Null when this is an official store reply.</summary>
        public int? CustomerId { get; set; }

        /// <summary>Set when Catron staff replies from the back office.</summary>
        public int? AdminId { get; set; }

        /// <summary>True when the reply author is the original product reviewer.</summary>
        public bool IsReviewerReply { get; set; }

        /// <summary>True when Catron (store/staff) posted this reply.</summary>
        public bool IsOfficialReply { get; set; }

        [Required, StringLength(500)]
        public string Message { get; set; } = "";

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        public Review Review { get; set; } = null!;
        public Customer? Customer { get; set; }
        public Admin? Admin { get; set; }
    }
}
