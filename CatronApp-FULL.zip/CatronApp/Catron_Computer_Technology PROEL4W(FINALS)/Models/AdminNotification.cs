using System.ComponentModel.DataAnnotations;

namespace Catron_Computer_Technology_PROEL4W_FINALS_.Models
{
    /// <summary>Admin bell notifications (new orders, returns, low stock, etc.).</summary>
    public class AdminNotification
    {
        public int Id { get; set; }

        [Required, MaxLength(200)]
        public string Title { get; set; } = "";

        [MaxLength(500)]
        public string? Message { get; set; }

        /// <summary>Optional link when clicked (e.g. /Admin/OrderDetail/12).</summary>
        [MaxLength(300)]
        public string? LinkUrl { get; set; }

        /// <summary>order | return | product | system</summary>
        [MaxLength(40)]
        public string Category { get; set; } = "system";

        public bool IsRead { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }
}
