// ============================================================
//  CustomerController.cs
//  Namespace: Catron_Computer_Technology_PROEL4W_FINALS_.Controllers
//
//  Purpose:
//    Handles every page a customer sees on the storefront.
//    Also manages the customer's account self-service area.
//
//  Views live in:  Views/Customer/
//    Auth      : Login, Register, ForgotPassword, ResetPassword
//    Public    : Index (Home), About, Contact
//    Products  : (shared Product listing via CustomerController)
//    Shopping  : Cart, Checkout, Pay, ConfirmPayment, Receipt
//    Account   : Dashboard, ManageAccount, MyOrders, OrderDetail,
//                MyWishList, MyReviews, MyReturns
//
//  Session keys used:
//    "CustomerId"    – int   : ID of the logged-in customer
//    "CustomerName"  – string: full name (used in the navbar)
//    "CustomerEmail" – string: email address
//
//  Auth guard:
//    CustId  → nullable int from session.
//    IsLogged → true when CustId has a value.
//    Guard()  → redirects to Login with an optional return URL.
// ============================================================

using Catron_Computer_Technology_PROEL4W_FINALS_.Data;
using Catron_Computer_Technology_PROEL4W_FINALS_.Helpers;
using Catron_Computer_Technology_PROEL4W_FINALS_.Models;
using Catron_Computer_Technology_PROEL4W_FINALS_.Models.ViewModels;
using Catron_Computer_Technology_PROEL4W_FINALS_.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Text;
using System.Text.Json;

namespace Catron_Computer_Technology_PROEL4W_FINALS_.Controllers
{
    public class CustomerController : Controller
    {
        // ── Injected EF Core + Services (Services folder like HotelEase) ─
        private readonly IOrderLifecycleService _lifecycle;
        private readonly ApplicationDbContext _db;
        private readonly IWebHostEnvironment _env;
        private readonly IProductService _products;
        private readonly ICartService _cart;
        private readonly IOrderService _orders;
        private readonly IConfiguration _config;
        private readonly IHttpClientFactory _httpClientFactory;

        /// <summary>Constructor – receives DbContext and application services via DI.</summary>
        public CustomerController(IOrderLifecycleService lifecycle, 
            ApplicationDbContext db,
            IWebHostEnvironment env,
            IProductService products,
            ICartService cart,
            IOrderService orders,
            IConfiguration config,
            IHttpClientFactory httpClientFactory)
        {
            _lifecycle = lifecycle;
            _db = db;
            _env = env;
            _products = products;
            _cart = cart;
            _orders = orders;
            _config = config;
            _httpClientFactory = httpClientFactory;
        }

        // ── Helper: save an uploaded image to wwwroot/uploads/<folder> ──
        private async Task<string?> SaveUploadAsync(IFormFile? file, string folder, string? oldPath = null)
        {
            if (file == null || file.Length == 0) return null;
            var ext = Path.GetExtension(file.FileName).ToLower();
            var allowed = new[] { ".jpg", ".jpeg", ".png", ".gif", ".webp" };
            if (!allowed.Contains(ext)) return null;
            var dir = Path.Combine(_env.WebRootPath, "uploads", folder);
            Directory.CreateDirectory(dir);
            var fileName = Guid.NewGuid().ToString("N") + ext;
            using var stream = new FileStream(Path.Combine(dir, fileName), FileMode.Create);
            await file.CopyToAsync(stream);
            if (!string.IsNullOrEmpty(oldPath))
            {
                var old = Path.Combine(_env.WebRootPath, oldPath.TrimStart('/'));
                if (System.IO.File.Exists(old)) System.IO.File.Delete(old);
            }
            return "/uploads/" + folder + "/" + fileName;
        }

        // ── Session-based authentication helpers ─────────────────────────

        /// <summary>
        /// Returns the logged-in customer's ID from the session, or null
        /// when no customer is logged in.
        /// </summary>
        private int? CustId => HttpContext.Session.GetInt32("CustomerId");

        /// <summary>True when a customer session is active.</summary>
        private bool IsLogged => CustId.HasValue;

        /// <summary>
        /// Redirects to the Login page. Passes an optional returnUrl so the
        /// customer is sent back to their original destination after logging in.
        /// </summary>
        private IActionResult Guard(string? returnUrl = null) =>
            RedirectToAction("Login", new { returnUrl });

        // ══════════════════════════════════════════════════════════════
        //  HOME / STATIC PAGES
        //  Public pages accessible without login.
        // ══════════════════════════════════════════════════════════════

        /// <summary>
        /// GET /Customer/Index  (storefront home page)
        /// Shows featured products (8 newest) and the full category list.
        /// </summary>
        public async Task<IActionResult> Index()
        {
            // Business logic moved to Services/ProductService (HotelEase pattern)
            var vm = await _products.GetHomeAsync();
            return View(vm);
        }

        /// <summary>GET /Customer/About – static about page.</summary>
        public IActionResult About() => View();

        /// <summary>GET /Customer/Contact – contact form page.</summary>
        public IActionResult Contact() => View();

        /// <summary>
        /// POST /Customer/Contact
        /// In a real application this would send an email.
        /// Currently just shows a success flash message.
        /// </summary>
        [HttpPost]
        public IActionResult Contact(string name, string email, string message)
        {
            TempData["Success"] = "Thank you for contacting us! We'll get back to you shortly.";
            return RedirectToAction("Contact");
        }

        // ══════════════════════════════════════════════════════════════
        //  AUTHENTICATION – LOGIN
        // ══════════════════════════════════════════════════════════════

        /// <summary>
        /// GET /Customer/Login?returnUrl=...
        /// Shows the login form. If already logged in, redirects to the
        /// home page (or returnUrl if provided).
        /// </summary>
        [HttpGet]
        public IActionResult Login(string? returnUrl)
        {
            if (IsLogged) return RedirectToAction("Index");
            ViewBag.ReturnUrl = returnUrl;
            ViewBag.GoogleClientId = _config["SocialAuth:GoogleClientId"] ?? "";
            ViewBag.FacebookAppId = _config["SocialAuth:FacebookAppId"] ?? "";
            return View();
        }

        /// <summary>
        /// POST /Customer/Login
        /// Looks up the customer by email, verifies the BCrypt password hash,
        /// sets session keys, and redirects to returnUrl or the home page.
        /// On failure, re-displays the form with a generic error message.
        /// </summary>
        [HttpPost]
        public async Task<IActionResult> Login(CustomerLoginViewModel model, string? returnUrl)
        {
            if (!ModelState.IsValid) return View(model);

            // Find an active customer with this email address
            var customer = await _db.Customers
                .FirstOrDefaultAsync(c => c.Email == model.Email && c.IsActive);

            // Verify the entered password against the stored BCrypt hash
            if (customer == null || !CustomerPasswordHasher.Verify(model.Password, customer.PasswordHash))
            {
                // Generic message prevents revealing whether the email or password was wrong
                ModelState.AddModelError("", "Invalid email or password.");
                return View(model);
            }

            // Store the customer's identity in the session
            HttpContext.Session.SetInt32("CustomerId", customer.Id);
            HttpContext.Session.SetString("CustomerName", customer.FullName);
            HttpContext.Session.SetString("CustomerEmail", customer.Email);
            HttpContext.Session.SetString("CustomerProfilePic", customer.ProfilePicture ?? "");

            // Redirect to the originally requested page or fall back to the home page
            return Redirect(!string.IsNullOrEmpty(returnUrl) ? returnUrl : "/Customer/Index");
        }

        // ══════════════════════════════════════════════════════════════
        //  AUTHENTICATION – GOOGLE / FACEBOOK
        // ══════════════════════════════════════════════════════════════

        public class ExternalLoginRequest
        {
            public string Provider { get; set; } = "";
            public string? IdToken { get; set; }
            public string? AccessToken { get; set; }
            public string? Email { get; set; }
            public string? Name { get; set; }
            public string? Picture { get; set; }
            public string? ProviderUserId { get; set; }
            public string? ReturnUrl { get; set; }
        }

        /// <summary>
        /// POST /Customer/ExternalLogin
        /// Completes Google or Facebook sign-in. Creates account if email is new.
        /// </summary>
        [HttpPost]
        [IgnoreAntiforgeryToken]
        public async Task<IActionResult> ExternalLogin([FromBody] ExternalLoginRequest req)
        {
            if (req == null || string.IsNullOrWhiteSpace(req.Provider))
                return Json(new { success = false, message = "Invalid request." });

            var provider = req.Provider.Trim().ToLowerInvariant();
            string email = (req.Email ?? "").Trim().ToLowerInvariant();
            string name = (req.Name ?? "").Trim();
            string providerUserId = (req.ProviderUserId ?? "").Trim();
            string? picture = string.IsNullOrWhiteSpace(req.Picture) ? null : req.Picture.Trim();

            try
            {
                var allowDemo = string.Equals(_config["SocialAuth:AllowDemo"] ?? "true", "true", StringComparison.OrdinalIgnoreCase);

                if (provider == "google")
                {
                    var clientId = _config["SocialAuth:GoogleClientId"] ?? "";
                    if (!string.IsNullOrWhiteSpace(clientId) && !string.IsNullOrWhiteSpace(req.IdToken))
                    {
                        // Real Google ID token
                        var parts = req.IdToken.Split('.');
                        if (parts.Length < 2)
                            return Json(new { success = false, message = "Invalid Google token." });

                        var payloadJson = Encoding.UTF8.GetString(Base64UrlDecode(parts[1]));
                        using var doc = JsonDocument.Parse(payloadJson);
                        var root = doc.RootElement;
                        var aud = root.TryGetProperty("aud", out var audEl) ? audEl.GetString() : null;
                        if (!string.Equals(aud, clientId, StringComparison.Ordinal))
                            return Json(new { success = false, message = "Google token audience mismatch." });

                        email = (root.TryGetProperty("email", out var em) ? em.GetString() : email)?.Trim().ToLowerInvariant() ?? "";
                        name = (root.TryGetProperty("name", out var nm) ? nm.GetString() : name) ?? name;
                        providerUserId = (root.TryGetProperty("sub", out var sub) ? sub.GetString() : providerUserId) ?? providerUserId;
                        if (root.TryGetProperty("picture", out var pic))
                            picture = pic.GetString() ?? picture;
                    }
                    else if (allowDemo && !string.IsNullOrWhiteSpace(email))
                    {
                        // Demo mode (no Client ID) — works for project demo
                        if (string.IsNullOrWhiteSpace(providerUserId))
                            providerUserId = "demo-google-" + email;
                        if (string.IsNullOrWhiteSpace(name))
                            name = email.Split('@')[0];
                    }
                    else
                    {
                        return Json(new { success = false, message = "Google sign-in needs an email (demo) or SocialAuth:GoogleClientId for real OAuth." });
                    }
                }
                else if (provider == "facebook")
                {
                    var appId = _config["SocialAuth:FacebookAppId"] ?? "";
                    if (!string.IsNullOrWhiteSpace(appId) && !string.IsNullOrWhiteSpace(req.AccessToken))
                    {
                        var client = _httpClientFactory.CreateClient();
                        var url = $"https://graph.facebook.com/me?fields=id,name,email,picture.type(large)&access_token={Uri.EscapeDataString(req.AccessToken)}";
                        var resp = await client.GetAsync(url);
                        if (!resp.IsSuccessStatusCode)
                            return Json(new { success = false, message = "Could not verify Facebook account." });

                        var json = await resp.Content.ReadAsStringAsync();
                        using var doc = JsonDocument.Parse(json);
                        var root = doc.RootElement;
                        providerUserId = root.TryGetProperty("id", out var idEl) ? (idEl.GetString() ?? "") : providerUserId;
                        name = root.TryGetProperty("name", out var nm) ? (nm.GetString() ?? name) : name;
                        if (root.TryGetProperty("email", out var em))
                            email = (em.GetString() ?? email).Trim().ToLowerInvariant();
                        if (root.TryGetProperty("picture", out var picObj) &&
                            picObj.TryGetProperty("data", out var data) &&
                            data.TryGetProperty("url", out var urlEl))
                            picture = urlEl.GetString() ?? picture;
                    }
                    else if (allowDemo && !string.IsNullOrWhiteSpace(email))
                    {
                        if (string.IsNullOrWhiteSpace(providerUserId))
                            providerUserId = "demo-facebook-" + email;
                        if (string.IsNullOrWhiteSpace(name))
                            name = email.Split('@')[0];
                    }
                    else
                    {
                        return Json(new { success = false, message = "Facebook sign-in needs an email (demo) or SocialAuth:FacebookAppId for real OAuth." });
                    }
                }
                else
                {
                    return Json(new { success = false, message = "Unsupported provider." });
                }

                if (string.IsNullOrWhiteSpace(email))
                    return Json(new { success = false, message = "No email returned from " + provider + ". Allow email permission and try again." });

                // Find by provider id or email
                Customer? customer = null;
                if (!string.IsNullOrEmpty(providerUserId))
                {
                    if (provider == "google")
                        customer = await _db.Customers.FirstOrDefaultAsync(c => c.GoogleId == providerUserId);
                    else
                        customer = await _db.Customers.FirstOrDefaultAsync(c => c.FacebookId == providerUserId);
                }
                if (customer == null)
                    customer = await _db.Customers.FirstOrDefaultAsync(c => c.Email == email);

                if (customer != null && !customer.IsActive)
                    return Json(new { success = false, message = "This account is deactivated." });

                if (customer == null)
                {
                    // Split name
                    var first = name;
                    var last = "";
                    if (!string.IsNullOrWhiteSpace(name))
                    {
                        var partsName = name.Trim().Split(' ', 2, StringSplitOptions.RemoveEmptyEntries);
                        first = partsName[0];
                        last = partsName.Length > 1 ? partsName[1] : "";
                    }
                    if (string.IsNullOrWhiteSpace(first)) first = "Customer";
                    if (string.IsNullOrWhiteSpace(last)) last = provider == "google" ? "Google" : "Facebook";

                    // Random unusable password — social-only login
                    var randomPwd = Guid.NewGuid().ToString("N") + "Aa1!";
                    customer = new Customer
                    {
                        FirstName = first,
                        LastName = last,
                        Email = email,
                        PasswordHash = CustomerPasswordHasher.Hash(randomPwd),
                        ProfilePicture = picture,
                        AuthProvider = provider,
                        GoogleId = provider == "google" ? providerUserId : null,
                        FacebookId = provider == "facebook" ? providerUserId : null,
                        IsActive = true,
                        CreatedAt = DateTime.UtcNow
                    };
                    _db.Customers.Add(customer);
                    await _db.SaveChangesAsync();
                }
                else
                {
                    // Link provider id if missing
                    if (provider == "google" && string.IsNullOrEmpty(customer.GoogleId))
                        customer.GoogleId = providerUserId;
                    if (provider == "facebook" && string.IsNullOrEmpty(customer.FacebookId))
                        customer.FacebookId = providerUserId;
                    if (string.IsNullOrEmpty(customer.ProfilePicture) && !string.IsNullOrEmpty(picture))
                        customer.ProfilePicture = picture;
                    if (customer.AuthProvider == "local" || string.IsNullOrEmpty(customer.AuthProvider))
                        customer.AuthProvider = provider;
                    await _db.SaveChangesAsync();
                }

                HttpContext.Session.SetInt32("CustomerId", customer.Id);
                HttpContext.Session.SetString("CustomerName", customer.FullName);
                HttpContext.Session.SetString("CustomerEmail", customer.Email);
                HttpContext.Session.SetString("CustomerProfilePic", customer.ProfilePicture ?? "");

                var dest = !string.IsNullOrEmpty(req.ReturnUrl) ? req.ReturnUrl : "/Customer/Index";
                return Json(new { success = true, redirect = dest });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = "Sign-in failed. " + ex.Message });
            }
        }

        private static byte[] Base64UrlDecode(string input)
        {
            string s = input.Replace('-', '+').Replace('_', '/');
            switch (s.Length % 4)
            {
                case 2: s += "=="; break;
                case 3: s += "="; break;
            }
            return Convert.FromBase64String(s);
        }

        // ══════════════════════════════════════════════════════════════
        //  AUTHENTICATION – REGISTER
        // ══════════════════════════════════════════════════════════════

        /// <summary>GET /Customer/Register – shows the registration form.</summary>
        [HttpGet]
        public IActionResult Register()
        {
            if (IsLogged) return RedirectToAction("Index");
            ViewBag.GoogleClientId = _config["SocialAuth:GoogleClientId"] ?? "";
            ViewBag.FacebookAppId = _config["SocialAuth:FacebookAppId"] ?? "";
            return View();
        }

        /// <summary>
        /// POST /Customer/Register
        /// Validates the form, checks for duplicate email, creates the customer
        /// account with a BCrypt-hashed password (work factor 12).
        /// </summary>
        [HttpPost]
        public async Task<IActionResult> Register(CustomerRegisterViewModel model)
        {
            if (!ModelState.IsValid) return View(model);

            // Prevent duplicate accounts with the same email address
            if (await _db.Customers.AnyAsync(c => c.Email == model.Email))
            {
                ModelState.AddModelError("Email", "This email address is already registered.");
                return View(model);
            }

            // Create and persist the new customer record
            _db.Customers.Add(new Customer
            {
                FirstName = model.FirstName.Trim(),
                LastName = model.LastName.Trim(),
                Email = model.Email.Trim().ToLower(),
                PhoneNumber = model.PhoneNumber?.Trim(),
                PasswordHash = CustomerPasswordHasher.Hash(model.Password)
            });
            await _db.SaveChangesAsync();

            TempData["Success"] = "Account created! Please log in.";
            return RedirectToAction("Login");
        }

        // ══════════════════════════════════════════════════════════════
        //  AUTHENTICATION – FORGOT / RESET PASSWORD
        // ══════════════════════════════════════════════════════════════

        /// <summary>GET /Customer/ForgotPassword – shows the email-input form.</summary>
        [HttpGet] public IActionResult ForgotPassword() => View();

        /// <summary>
        /// POST /Customer/ForgotPassword
        /// If the email belongs to an active customer, a reset token is stored.
        /// The same response is shown regardless of whether the email was found
        /// to prevent user enumeration.
        /// (TODO: Send the reset link by email.)
        /// </summary>
        [HttpPost]
        public async Task<IActionResult> ForgotPassword(ForgotPasswordViewModel model)
        {
            if (!ModelState.IsValid) return View(model);

            var email = (model.Email ?? "").Trim().ToLowerInvariant();
            var c = await _db.Customers.FirstOrDefaultAsync(x => x.Email.ToLower() == email && x.IsActive);
            if (c != null)
            {
                c.ResetToken = CustomerPasswordHasher.GenerateResetToken();
                c.ResetTokenExpiry = DateTime.UtcNow.AddHours(1);
                await _db.SaveChangesAsync();

                var baseUrl = $"{Request.Scheme}://{Request.Host}";
                var resetLink = $"{baseUrl}/Customer/ResetPassword?token={Uri.EscapeDataString(c.ResetToken)}&email={Uri.EscapeDataString(c.Email)}";

                // Try email; if SMTP not set, still show link for demo/dev
                await EmailHelper.SendCustomerPasswordResetAsync(
                    c.Email, c.FullName, resetLink, HttpContext.RequestServices);

                TempData["Success"] = "Password reset link is ready. Use the link below (also emailed if SMTP is configured).";
                TempData["ResetLink"] = resetLink;
                return View(model);
            }

            // Same message whether found or not (no enumeration)
            TempData["Info"] = "If your email is registered, a password reset link has been prepared.";
            return View(model);
        }

        /// <summary>
        /// GET /Customer/ResetPassword?token=...&email=...
        /// Pre-fills the form with the token and email from the email link.
        /// </summary>
        [HttpGet]
        public IActionResult ResetPassword(string token, string email) =>
            View(new ResetPasswordViewModel { Token = token, Email = email });

        /// <summary>
        /// POST /Customer/ResetPassword
        /// Validates the token against the database, applies the new password,
        /// and invalidates the token so it cannot be reused.
        /// </summary>
        [HttpPost]
        public async Task<IActionResult> ResetPassword(ResetPasswordViewModel model)
        {
            if (!ModelState.IsValid) return View(model);

            // Verify the token matches and has not expired
            var c = await _db.Customers.FirstOrDefaultAsync(x =>
                x.Email == model.Email &&
                x.ResetToken == model.Token &&
                x.ResetTokenExpiry > DateTime.UtcNow);

            if (c == null)
            {
                ModelState.AddModelError("", "The reset link is invalid or has expired.");
                return View(model);
            }

            // Apply the new BCrypt-hashed password and clear the one-time token
            c.PasswordHash = CustomerPasswordHasher.Hash(model.NewPassword);
            c.ResetToken = null;
            c.ResetTokenExpiry = null;
            await _db.SaveChangesAsync();

            TempData["Success"] = "Password reset successfully. Please log in.";
            return RedirectToAction("Login");
        }

        // ══════════════════════════════════════════════════════════════
        //  AUTHENTICATION – LOGOUT
        // ══════════════════════════════════════════════════════════════

        /// <summary>
        /// GET /Customer/Logout
        /// Clears the entire session and redirects to the home page.
        /// </summary>
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Index");
        }

        // ══════════════════════════════════════════════════════════════
        //  PRODUCTS
        //  Public product listing with category filter, search,
        //  and pagination.
        // ══════════════════════════════════════════════════════════════

        /// <summary>
        /// GET /Customer/Products?categoryId=...&search=...&page=...
        /// Returns a paginated list of active products filtered by category
        /// and/or search keyword.  Page size is fixed at 12 products.
        /// </summary>
        public async Task<IActionResult> Products(int? categoryId, string? search, int page = 1)
        {
            // Catalog filtering / pagination lives in Services/ProductService
            var vm = await _products.GetProductsAsync(categoryId, search, page);
            return View(vm);
        }

        /// <summary>
        /// GET /Customer/ProductDetail/{id}
        /// Shows one product's full detail page including reviews, related products,
        /// and whether it is in the logged-in customer's wishlist.
        /// </summary>
        public async Task<IActionResult> ProductDetail(int id)
        {
            // Find the active product
            var product = await _db.Products
                .Include(p => p.Category)
                .FirstOrDefaultAsync(p => p.Id == id && p.IsActive);
            if (product == null) return NotFound();

            // Reviews for this product, newest first
            var reviews = await _db.Reviews
                .Include(r => r.Customer)
                .Include(r => r.Replies).ThenInclude(rp => rp.Customer)
                .Include(r => r.Replies).ThenInclude(rp => rp.Admin)
                .Where(r => r.ProductId == id)
                .OrderByDescending(r => r.CreatedAt)
                .ToListAsync();

            // Up to 4 other products in the same category (excluding this one)
            var related = await _db.Products.AsNoTracking().Include(p => p.Category)
                .Where(p => p.CategoryId == product.CategoryId && p.Id != id && p.IsActive)
                .Take(4)
                .ToListAsync();

            // Check if the logged-in customer already has this product in their wishlist
            bool inWishlist = IsLogged &&
                await _db.WishListItems.AnyAsync(w => w.CustomerId == CustId && w.ProductId == id);

            return View(new ProductDetailViewModel
            {
                Product = product,
                Reviews = reviews,
                RelatedProducts = related,
                IsInWishlist = inWishlist,
                AverageRating = reviews.Any() ? reviews.Average(r => r.Rating) : 0
            });
        }

        // ══════════════════════════════════════════════════════════════
        //  CART
        //  Shopping cart CRUD operations.
        //  Most mutations are JSON endpoints consumed by page-level JS
        //  to update totals without a full page reload.
        // ══════════════════════════════════════════════════════════════

        /// <summary>
        /// GET /Customer/Cart
        /// Shows the logged-in customer's cart items and computed totals.
        /// Redirects to Login if not authenticated.
        /// </summary>
        public async Task<IActionResult> Cart()
        {
            if (!IsLogged) return Guard("/Customer/Cart");

            var items = await _cart.GetCartAsync(CustId!.Value);
            return View(new CartViewModel
            {
                CartItems = items,
                TotalAmount = items.Sum(i => i.Product.FinalPrice * i.Quantity),
                TotalItems = items.Sum(i => i.Quantity)
            });
        }

        /// <summary>
        /// POST /Customer/AddToCart  (JSON endpoint)
        /// Adds a product to the cart or increments the quantity if it already exists.
        /// Called via fetch() from the product listing and detail pages.
        /// Returns JSON: { success, message, count } or { success, redirect }.
        /// </summary>
        [HttpPost, IgnoreAntiforgeryToken]
        public async Task<IActionResult> AddToCart([FromBody] AddToCartRequest? body, int productId = 0, int quantity = 1)
        {
            string? options = null;
            if (body != null) { productId = body.ProductId; quantity = body.Quantity; options = body.Options; }
            if (!IsLogged) return Json(new { success = false, redirect = "/Customer/Login", message = "Please log in first." });

            var (success, message, count) = await _cart.AddToCartAsync(CustId!.Value, productId, quantity, options);
            return Json(new { success, message, count });
        }

        /// <summary>
        /// POST /Customer/UpdateCartItem  (JSON endpoint)
        /// Updates the quantity of a specific cart item.
        /// Quantity ≤ 0 removes the item entirely.
        /// Returns updated subtotal, grand total, and item count.
        /// </summary>
        [HttpPost, IgnoreAntiforgeryToken]
        public async Task<IActionResult> UpdateCartItem([FromBody] UpdateCartRequest? body, int cartItemId = 0, int quantity = 0)
        {
            if (body != null) { cartItemId = body.CartItemId; quantity = body.Quantity; }
            if (!IsLogged) return Json(new { success = false });

            var (success, subtotal, total, count) = await _cart.UpdateQuantityAsync(CustId!.Value, cartItemId, quantity);
            return Json(new { success, subtotal, total, count });
        }

        /// <summary>
        /// POST /Customer/RemoveCartItem  (JSON endpoint)
        /// Removes a specific item from the cart entirely.
        /// Returns updated grand total and item count.
        /// </summary>
        [HttpPost, IgnoreAntiforgeryToken]
        public async Task<IActionResult> RemoveCartItem([FromBody] RemoveCartRequest? body, int cartItemId = 0)
        {
            if (body != null) cartItemId = body.CartItemId;
            if (!IsLogged) return Json(new { success = false });

            var (success, total, count) = await _cart.RemoveAsync(CustId!.Value, cartItemId);
            return Json(new { success, total, count });
        }

        /// <summary>
        /// GET /Customer/GetCartCount  (JSON endpoint)
        /// Returns the total number of items in the customer's cart.
        /// Called on page load to populate the navbar cart badge.
        /// </summary>
        public async Task<JsonResult> GetCartCount()
        {
            if (!IsLogged) return Json(new { count = 0 });
            int n = await _cart.GetCartCountAsync(CustId!.Value);
            return Json(new { count = n });
        }

        // ══════════════════════════════════════════════════════════════
        //  CHECKOUT
        //  Customer reviews cart, chooses a shipping address,
        //  then places the order.
        // ══════════════════════════════════════════════════════════════

        /// <summary>
        /// GET /Customer/Checkout
        /// Pre-fills the shipping fields with the customer's default address
        /// and lists all saved addresses as radio-button alternatives.
        /// Redirects to Cart if the cart is empty.
        /// </summary>
        [HttpGet]
        public async Task<IActionResult> Checkout()
        {
            if (!IsLogged) return Guard("/Customer/Checkout");

            // Abort if the cart is empty
            var cartItems = await _db.CartItems.Include(c => c.Product)
                .Where(c => c.CustomerId == CustId).ToListAsync();
            if (!cartItems.Any()) return RedirectToAction("Cart");

            // Load saved addresses and pre-select the default
            var addrs = await _db.CustomerAddresses
                .Where(a => a.CustomerId == CustId).ToListAsync();
            var def = addrs.FirstOrDefault(a => a.IsDefault);

            // Collected, unused vouchers the customer can select at checkout
            var now = DateTime.UtcNow;
            var availableVouchers = await _db.CustomerVouchers
                .AsNoTracking()
                .Where(cv => cv.CustomerId == CustId && cv.UsedAt == null && cv.Voucher != null
                    && cv.Voucher.IsActive
                    && (cv.Voucher.ExpiresAt == null || cv.Voucher.ExpiresAt > now)
                    && (cv.Voucher.MaxUses == null || cv.Voucher.UsedCount < cv.Voucher.MaxUses))
                .Select(cv => cv.Voucher!)
                .OrderBy(v => v.Code)
                .ToListAsync();

            return View(new CheckoutViewModel
            {
                CartItems = cartItems,
                TotalAmount = cartItems.Sum(i => i.Product.FinalPrice * i.Quantity),
                SavedAddresses = addrs,
                AvailableVouchers = availableVouchers,
                ShippingFullName = def?.FullName ?? "",
                ShippingAddress = def?.Address ?? "",
                ShippingPhone = def?.PhoneNumber ?? ""
            });
        }

        // ══════════════════════════════════════════════════════════════
        //  PLACE ORDER
        //  Creates the Order, OrderItems, deducts stock, clears cart.
        // ══════════════════════════════════════════════════════════════

        /// <summary>
        /// POST /Customer/PlaceOrder
        /// Resolves the shipping address (saved address takes priority),
        /// creates the Order and OrderItems, deducts stock, clears the cart,
        /// then redirects to the payment page.
        /// </summary>
        [HttpPost]
        public async Task<IActionResult> PlaceOrder(CheckoutViewModel model, PaymentMethod paymentMethod)
        {
            if (!IsLogged) return Guard();

            // Re-fetch cart items (never trust client-side totals)
            var cartItems = await _db.CartItems.Include(c => c.Product)
                .Where(c => c.CustomerId == CustId).ToListAsync();
            if (!cartItems.Any()) return RedirectToAction("Cart");

            // ── FIX: If the customer selected a saved address via radio button,
            //         load the address fields from the database instead of relying
            //         on hidden form fields (which may have been cleared by the browser).
            if (model.SelectedAddressId.HasValue && model.SelectedAddressId > 0)
            {
                var saved = await _db.CustomerAddresses.FirstOrDefaultAsync(
                    a => a.Id == model.SelectedAddressId && a.CustomerId == CustId);

                if (saved != null)
                {
                    model.ShippingFullName = saved.FullName;
                    model.ShippingAddress = saved.Address;
                    model.ShippingPhone = saved.PhoneNumber;
                }
            }

            // ── Safety net: if shipping info is still blank, pull from profile ──
            if (string.IsNullOrWhiteSpace(model.ShippingFullName) ||
                string.IsNullOrWhiteSpace(model.ShippingAddress) ||
                string.IsNullOrWhiteSpace(model.ShippingPhone))
            {
                var customer = await _db.Customers.FindAsync(CustId);
                var anyAddr = await _db.CustomerAddresses
                    .FirstOrDefaultAsync(a => a.CustomerId == CustId);

                model.ShippingFullName = anyAddr?.FullName ?? customer?.FullName ?? "N/A";
                model.ShippingAddress = anyAddr?.Address ?? "No address provided";
                model.ShippingPhone = anyAddr?.PhoneNumber ?? customer?.PhoneNumber ?? "N/A";
            }

            var subtotal = cartItems.Sum(i => i.Product.FinalPrice * i.Quantity);
            decimal discountAmt = 0m;
            string? appliedCode = null;
            var voucherCode = (Request.Form["VoucherCode"].ToString() ?? "").Trim().ToUpperInvariant();
            if (!string.IsNullOrEmpty(voucherCode))
            {
                var now = DateTime.UtcNow;
                var v = await _db.Vouchers.FirstOrDefaultAsync(x => x.Code == voucherCode && x.IsActive);
                var owned = v != null && await _db.CustomerVouchers.AnyAsync(cv =>
                    cv.CustomerId == CustId && cv.VoucherId == v.Id && cv.UsedAt == null);
                if (v != null && owned
                    && (v.ExpiresAt == null || v.ExpiresAt > now)
                    && (v.MaxUses == null || v.UsedCount < v.MaxUses)
                    && subtotal >= v.MinSpend)
                {
                    discountAmt = v.DiscountType == VoucherDiscountType.Percent
                        ? Math.Round(subtotal * (v.DiscountValue / 100m), 2)
                        : Math.Min(v.DiscountValue, subtotal);
                    appliedCode = v.Code;
                    v.UsedCount++;
                    var cv = await _db.CustomerVouchers.FirstAsync(x => x.CustomerId == CustId && x.VoucherId == v.Id && x.UsedAt == null);
                    cv.UsedAt = now;
                }
            }

            // Create the parent Order record
            var order = new Order
            {
                CustomerId = CustId!.Value,
                TotalAmount = Math.Max(0, subtotal - discountAmt),
                DiscountAmount = discountAmt,
                VoucherCode = appliedCode,
                PaymentMethod = paymentMethod,
                ShippingFullName = model.ShippingFullName,
                ShippingAddress = model.ShippingAddress,
                ShippingPhone = model.ShippingPhone
            };

            _db.Orders.Add(order);
            await _db.SaveChangesAsync();  // Needed to get order.Id for OrderItems

            // Create one OrderItem per cart row.
            // Stock is NOT deducted here for unpaid (ToPay) orders — deduction happens
            // when payment is confirmed / order moves to ToShip (see ConfirmPayment).
            // Still perform authoritative stock check to prevent overselling.
            foreach (var item in cartItems)
            {
                if (item.Product.Stock < item.Quantity)
                {
                    TempData["Error"] = $"Insufficient stock for {item.Product.Name}. Available: {item.Product.Stock}.";
                    return RedirectToAction("Cart");
                }

                _db.OrderItems.Add(new OrderItem
                {
                    OrderId = order.Id,
                    ProductId = item.ProductId,
                    Quantity = item.Quantity,
                    UnitPrice = item.Product.FinalPrice,
                    SelectedOptions = item.SelectedOptions
                });
            }

            // Clear the customer's cart after the order is placed
            _db.CartItems.RemoveRange(cartItems);
            await _db.SaveChangesAsync();

            // Notify admin (HotelEase-style bell)
            _db.AdminNotifications.Add(new AdminNotification
            {
                Title = "New order placed",
                Message = $"Order #{order.OrderNumber} · {order.ShippingFullName} · ₱{order.TotalAmount:N2}",
                LinkUrl = $"/Admin/OrderDetail/{order.Id}",
                Category = "order",
                CreatedAt = DateTime.UtcNow
            });
            await _db.SaveChangesAsync();

            // COD: auto-confirm (no extra Confirm step) → go straight to Receipt
            if (paymentMethod == PaymentMethod.Cash)
            {
                // Deduct stock now
                foreach (var oi in order.OrderItems)
                {
                    // reload product not needed - we already checked stock above from cart
                }
                // Re-load order items with products for stock deduction
                var orderWithItems = await _db.Orders
                    .Include(o => o.OrderItems).ThenInclude(i => i.Product)
                    .FirstAsync(o => o.Id == order.Id);

                foreach (var oi in orderWithItems.OrderItems)
                {
                    if (oi.Product != null)
                        oi.Product.Stock = Math.Max(0, oi.Product.Stock - oi.Quantity);
                }

                orderWithItems.PaymentStatus = PaymentStatus.Pending;
                orderWithItems.PaidAt = null;
                orderWithItems.Status = OrderStatus.ToShip;

                _db.DeliveryTrackings.Add(new DeliveryTracking
                {
                    OrderId = order.Id,
                    Status = "Order Confirmed (Cash on Delivery)",
                    Location = "Catron Warehouse, Cebu City",
                    Notes = "Order confirmed. Payment will be collected upon delivery (COD).",
                    TrackingTime = DateTime.UtcNow
                });

                _db.AdminNotifications.Add(new AdminNotification
                {
                    Title = "COD order confirmed",
                    Message = $"Order #{order.OrderNumber} COD · ₱{order.TotalAmount:N2} · unpaid until delivery",
                    LinkUrl = $"/Admin/OrderDetail/{order.Id}",
                    Category = "order",
                    CreatedAt = DateTime.UtcNow
                });
                await _db.SaveChangesAsync();

                TempData["Success"] = $"Order #{order.OrderNumber} confirmed! Pay with cash when your order is delivered.";
                return RedirectToAction("Receipt", new { orderId = order.Id });
            }

            // GCash (and other methods): show payment page with QR / instructions
            TempData["Info"] = $"Order #{order.OrderNumber} created. Please complete payment to confirm.";
            return RedirectToAction("Pay", new { orderId = order.Id });
        }

        // ══════════════════════════════════════════════════════════════
        //  PAYMENT
        //  Shows the payment method details and QR code (GCash),
        //  then confirms the payment and generates a receipt.
        // ══════════════════════════════════════════════════════════════

        /// <summary>
        /// GET /Customer/Pay/{orderId}
        /// Shows the payment confirmation page.  Generates a GCash QR code
        /// when the order's payment method is GCash.
        /// </summary>
        [HttpGet]
        public async Task<IActionResult> Pay(int orderId)
        {
            if (!IsLogged) return Guard();

            // Load the order – must belong to this customer
            var order = await _db.Orders
                .Include(o => o.OrderItems).ThenInclude(i => i.Product)
                .Include(o => o.Customer)
                .FirstOrDefaultAsync(o => o.Id == orderId && o.CustomerId == CustId);
            if (order == null) return NotFound();

            // Generate a scannable QR for GCash payments (phone + amount + order ref)
            // Any QR scanner / GCash "Scan QR" will read this payload clearly.
            const string gcashNumber = "09123456789";
            string? qr = null;
            if (order.PaymentMethod == PaymentMethod.GCash)
            {
                // Structured payload so scanners show usable payment details
                var payload =
                    $"000201" + // EMV-ish hint for scanners; full EMV needs merchant ID
                    $"\nGCash\n" +
                    $"Account: {gcashNumber}\n" +
                    $"Name: Catron Computer Technology\n" +
                    $"Amount: PHP {order.TotalAmount:F2}\n" +
                    $"Order: {order.OrderNumber}\n" +
                    $"Pay exact amount then enter reference number on website.";
                qr = QRCodeHelper.GenerateBase64(payload);
            }

            return View(new PaymentViewModel
            {
                Order = order,
                SelectedMethod = order.PaymentMethod,
                GCashNumber = "+63 912 345 6789",  // Store GCash number shown to customer
                QrCodeBase64 = qr
            });
        }

        /// <summary>
        /// POST /Customer/ConfirmPayment
        /// Marks the order as Paid, creates a Receipt, adds the initial
        /// delivery tracking event, then redirects to the Receipt page.
        /// </summary>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ConfirmPayment(int orderId, string? gcashReference)
        {
            if (!IsLogged) return Guard();

            // Verify ownership and load items for stock deduction
            var order = await _db.Orders
                .Include(o => o.OrderItems).ThenInclude(i => i.Product)
                .FirstOrDefaultAsync(o => o.Id == orderId && o.CustomerId == CustId);
            if (order == null) return NotFound();

            if (order.Status != OrderStatus.ToPay)
            {
                TempData["Error"] = "This order has already been processed.";
                return RedirectToAction("OrderDetail", new { id = orderId });
            }

            // Authoritative stock check + deduct under transaction semantics
            foreach (var oi in order.OrderItems)
            {
                if (oi.Product == null) continue;
                if (oi.Product.Stock < oi.Quantity)
                {
                    TempData["Error"] = $"Insufficient stock for {oi.Product.Name}. Available: {oi.Product.Stock}.";
                    return RedirectToAction("Pay", new { orderId });
                }
            }
            // NO stock deduction on customer payment submit (GCash Pending / admin verifies).

            // AUTHORITATIVE: Customer only submits GCash reference.
            // Payment stays Pending; Order stays ToPay; NO stock deduction here.
            // Admin VerifyPayment → Paid + ToShip + deduct stock once.
            if (order.PaymentMethod == PaymentMethod.GCash)
            {
                // Undo any stock deduction that may have run above (legacy path)
                // Stock is NOT deducted on customer submit.
                order.GCashReference = string.IsNullOrWhiteSpace(gcashReference) ? order.GCashReference : gcashReference.Trim();
                order.PaymentStatus = PaymentStatus.Pending;
                order.PaidAt = null;
                order.Status = OrderStatus.ToPay;
            }
            else // Cash on Delivery — should not normally hit ConfirmPayment
            {
                order.PaymentStatus = PaymentStatus.Unpaid;
                order.PaidAt = null;
                order.Status = OrderStatus.ToShip;
            }

            // First tracking + admin notify (wording depends on payment method)
            var isGCash = order.PaymentMethod == PaymentMethod.GCash;
            _db.DeliveryTrackings.Add(new DeliveryTracking
            {
                OrderId = order.Id,
                Status = isGCash ? "Order Confirmed & Payment Received" : "Order Confirmed (Cash on Delivery)",
                Location = "Catron Warehouse, Cebu City",
                Notes = isGCash
                    ? "Your order has been paid and is being prepared for shipment."
                    : "Order confirmed. Payment will be collected upon delivery (COD).",
                TrackingTime = DateTime.UtcNow
            });

            _db.AdminNotifications.Add(new AdminNotification
            {
                Title = isGCash ? "Payment confirmed (GCash)" : "COD order confirmed",
                Message = isGCash
                    ? $"Order #{order.OrderNumber} paid · ₱{order.TotalAmount:N2} · ready to ship"
                    : $"Order #{order.OrderNumber} COD · ₱{order.TotalAmount:N2} · unpaid until delivery",
                LinkUrl = $"/Admin/OrderDetail/{order.Id}",
                Category = "order",
                CreatedAt = DateTime.UtcNow
            });
            await _db.SaveChangesAsync();

            TempData["Success"] = isGCash
                ? $"Order #{order.OrderNumber} confirmed! Payment received. We are preparing your shipment."
                : $"Order #{order.OrderNumber} confirmed! Pay with cash when your order is delivered.";
            return RedirectToAction("Receipt", new { orderId = order.Id });
        }

        /// <summary>
        /// GET /Customer/Receipt/{orderId}
        /// Shows the payment receipt page with order details and receipt number.
        /// </summary>
        [HttpGet]
        public async Task<IActionResult> Receipt(int orderId)
        {
            if (!IsLogged) return Guard();

            var order = await _db.Orders
                .Include(o => o.OrderItems).ThenInclude(i => i.Product)
                .Include(o => o.Customer)
                .Include(o => o.Receipt)
                .Include(o => o.DeliveryTrackings)
                .FirstOrDefaultAsync(o => o.Id == orderId && o.CustomerId == CustId);

            if (order == null) return NotFound();
            return View(order);
        }

        // ══════════════════════════════════════════════════════════════
        //  ACCOUNT – DASHBOARD
        //  Customer's personal home page after login.
        // ══════════════════════════════════════════════════════════════

        /// <summary>
        /// GET /Customer/Dashboard
        /// Shows a welcome summary with the customer's 5 most recent orders.
        /// </summary>
        public async Task<IActionResult> Dashboard()
        {
            if (!IsLogged) return Guard();

            var customer = await _db.Customers.FindAsync(CustId);
            if (customer == null) return Guard();

            var recent = await _db.Orders
                .Include(o => o.OrderItems).ThenInclude(i => i.Product)
                .Where(o => o.CustomerId == CustId)
                .OrderByDescending(o => o.CreatedAt)
                .Take(5)
                .ToListAsync();

            return View(new AccountDashboardViewModel { Customer = customer, RecentOrders = recent });
        }

        // ══════════════════════════════════════════════════════════════
        //  ACCOUNT – MANAGE ACCOUNT
        //  Profile editing, saved addresses, and quick order history.
        // ══════════════════════════════════════════════════════════════

        /// <summary>
        /// GET /Customer/ManageAccount
        /// Loads the customer's profile, all saved addresses, and 5 recent orders
        /// into the ManageAccountViewModel for the account settings page.
        /// </summary>
        public async Task<IActionResult> ManageAccount()
        {
            if (!IsLogged) return Guard();

            var customer = await _db.Customers.FindAsync(CustId);
            if (customer == null) return Guard();

            var addrs = await _db.CustomerAddresses.Where(a => a.CustomerId == CustId).ToListAsync();
            var recent = await _db.Orders
                .Include(o => o.OrderItems).ThenInclude(i => i.Product)
                .Where(o => o.CustomerId == CustId)
                .OrderByDescending(o => o.CreatedAt)
                .Take(5)
                .ToListAsync();

            return View(new ManageAccountViewModel
            {
                Customer = customer,
                Addresses = addrs,
                DefaultBillingAddress = addrs.FirstOrDefault(a => a.IsBillingDefault),
                RecentOrders = recent
            });
        }

        /// <summary>
        /// POST /Customer/UpdateProfilePicture
        /// Handles profile picture upload for the logged-in customer.
        /// </summary>
        [HttpPost]
        public async Task<IActionResult> UpdateProfilePicture(IFormFile? ProfilePictureFile)
        {
            if (!IsLogged) return Guard();
            var c = await _db.Customers.FindAsync(CustId!.Value);
            if (c == null) return Guard();
            var newPic = await SaveUploadAsync(ProfilePictureFile, "profiles", c.ProfilePicture);
            if (newPic != null)
            {
                c.ProfilePicture = newPic;
                await _db.SaveChangesAsync();
                HttpContext.Session.SetString("CustomerProfilePic", newPic);
                TempData["Success"] = "Profile picture updated.";
            }
            else
            {
                TempData["Error"] = "Please select a valid image file (JPG, PNG, GIF, WebP).";
            }
            return RedirectToAction("ManageAccount");
        }

        /// POST /Customer/UpdateProfile
        /// Updates the customer's first name, last name, and phone number.
        /// Also refreshes the CustomerName session key so the navbar stays current.
        /// </summary>
        [HttpPost]
        public async Task<IActionResult> UpdateProfile(UpdateProfileViewModel model)
        {
            if (!IsLogged) return Guard();

            if (!ModelState.IsValid)
            {
                TempData["Error"] = "Please correct the highlighted errors.";
                return RedirectToAction("ManageAccount");
            }

            var c = await _db.Customers.FindAsync(CustId);
            if (c == null) return Guard();

            // Apply the updated fields
            c.FirstName = model.FirstName.Trim();
            c.LastName = model.LastName.Trim();
            c.PhoneNumber = model.PhoneNumber?.Trim();
            await _db.SaveChangesAsync();

            // Keep the session name in sync with the database
            HttpContext.Session.SetString("CustomerName", c.FullName);
            TempData["Success"] = "Profile updated successfully.";
            return RedirectToAction("ManageAccount");
        }

        /// <summary>
        /// POST /Customer/AddAddress
        /// Adds a new delivery/billing address to the customer's saved addresses.
        /// If IsDefault or IsBillingDefault is true, existing defaults are cleared first.
        /// </summary>
        [HttpPost]
        public async Task<IActionResult> AddAddress(
            string fullName, string address, string phoneNumber,
            bool isDefault = false, bool isBillingDefault = false)
        {
            if (!IsLogged) return Guard();

            // Require all three fields
            if (string.IsNullOrWhiteSpace(fullName) ||
                string.IsNullOrWhiteSpace(address) ||
                string.IsNullOrWhiteSpace(phoneNumber))
            {
                TempData["Error"] = "Full name, address, and phone number are all required.";
                return RedirectToAction("ManageAccount");
            }

            // Clear existing default shipping address (only one allowed)
            if (isDefault)
                (await _db.CustomerAddresses
                    .Where(a => a.CustomerId == CustId && a.IsDefault)
                    .ToListAsync())
                    .ForEach(a => a.IsDefault = false);

            // Clear existing default billing address (only one allowed)
            if (isBillingDefault)
                (await _db.CustomerAddresses
                    .Where(a => a.CustomerId == CustId && a.IsBillingDefault)
                    .ToListAsync())
                    .ForEach(a => a.IsBillingDefault = false);

            // Insert the new address record
            _db.CustomerAddresses.Add(new CustomerAddress
            {
                CustomerId = CustId!.Value,
                FullName = fullName.Trim(),
                Address = address.Trim(),
                PhoneNumber = phoneNumber.Trim(),
                IsDefault = isDefault,
                IsBillingDefault = isBillingDefault
            });

            await _db.SaveChangesAsync();
            TempData["Success"] = "Address saved successfully.";
            return RedirectToAction("ManageAccount");
        }

        /// <summary>
        /// POST /Customer/DeleteAddress/{id}
        /// Removes a saved address.  Ownership is verified before deletion.
        /// </summary>
        [HttpPost]
        public async Task<IActionResult> DeleteAddress(int id)
        {
            if (!IsLogged) return Guard();

            // Ownership check: ensure this address belongs to the logged-in customer
            var a = await _db.CustomerAddresses
                .FirstOrDefaultAsync(x => x.Id == id && x.CustomerId == CustId);

            if (a != null)
            {
                _db.CustomerAddresses.Remove(a);
                await _db.SaveChangesAsync();
                TempData["Success"] = "Address removed.";
            }
            return RedirectToAction("ManageAccount");
        }

        // ══════════════════════════════════════════════════════════════
        //  MY ORDERS
        //  The customer's full order history with filter tabs.
        // ══════════════════════════════════════════════════════════════

        /// <summary>
        /// GET /Customer/MyOrders?filter=All|ToPay|ToShip|...
        /// Shows the customer's orders filtered by status.
        /// </summary>
        public async Task<IActionResult> MyOrders(string filter = "All")
        {
            if (!IsLogged) return Guard();

            // Start with this customer's orders
            var q = _db.Orders
                .Include(o => o.OrderItems).ThenInclude(i => i.Product)
                .Where(o => o.CustomerId == CustId);

            // Apply the tab filter chosen by the customer
            q = filter switch
            {
                "ToPay" => q.Where(o => o.Status == OrderStatus.ToPay),
                "ToShip" => q.Where(o => o.Status == OrderStatus.ToShip),
                "ToReceive" => q.Where(o => o.Status == OrderStatus.ToReceive),
                "ToReview" => q.Where(o => o.Status == OrderStatus.ToReview),
                "ReturnRefund" => q.Where(o => o.Status == OrderStatus.ReturnRefund),
                "Cancelled" => q.Where(o => o.Status == OrderStatus.Cancelled),
                _ => q   // "All" – show everything
            };

            return View(new OrderListViewModel
            {
                Orders = await q.OrderByDescending(o => o.CreatedAt).ToListAsync(),
                Filter = filter
            });
        }

        /// <summary>
        /// GET /Customer/OrderDetail/{id}
        /// Shows the full detail for one of the customer's orders:
        /// line items, delivery tracking timeline, and receipt info.
        /// </summary>
        public async Task<IActionResult> OrderDetail(int id)
        {
            if (!IsLogged) return Guard();

            var order = await _db.Orders
                .Include(o => o.OrderItems).ThenInclude(i => i.Product)
                .Include(o => o.DeliveryTrackings)
                .Include(o => o.Receipt)
                .FirstOrDefaultAsync(o => o.Id == id && o.CustomerId == CustId);

            if (order == null) return NotFound();

            var reviewedIds = await _db.Reviews.AsNoTracking()
                .Where(r => r.CustomerId == CustId && r.OrderId == id)
                .Select(r => r.ProductId)
                .ToListAsync();
            ViewBag.ReviewedProductIds = reviewedIds;

            return View(order);
        }

        /// <summary>
        /// POST /Customer/CancelOrder
        /// Allows a customer to cancel an order that is still in ToPay or ToShip status.
        /// Orders that are already in transit or completed cannot be cancelled.
        /// </summary>
        [HttpPost]
        public async Task<IActionResult> CancelOrder(int orderId)
        {
            if (!IsLogged) return Guard();

            var o = await _db.Orders.FirstOrDefaultAsync(
                x => x.Id == orderId && x.CustomerId == CustId);

            if (o != null && (o.Status == OrderStatus.ToPay || o.Status == OrderStatus.ToShip))
            {
                o.Status = OrderStatus.Cancelled;
                await _db.SaveChangesAsync();
                TempData["Success"] = "Order cancelled successfully.";
            }
            else
            {
                TempData["Error"] = "This order cannot be cancelled at its current stage.";
            }

            return RedirectToAction("MyOrders");
        }

        // ══════════════════════════════════════════════════════════════
        //  WISHLIST
        //  Save products for later.  Toggle endpoint adds/removes
        //  the product with a single button click.
        // ══════════════════════════════════════════════════════════════

        /// <summary>
        /// GET /Customer/MyWishList
        /// Shows all products saved in the customer's wishlist.
        /// </summary>
        public async Task<IActionResult> MyWishList()
        {
            if (!IsLogged) return Guard();

            var items = await _db.WishListItems
                .Include(w => w.Product).ThenInclude(p => p.Category)
                .Where(w => w.CustomerId == CustId)
                .ToListAsync();

            return View(items);
        }

        /// <summary>
        /// POST /Customer/ToggleWishlist  (JSON endpoint)
        /// Adds the product to the wishlist if it is not already there,
        /// or removes it if it is (toggle behaviour).
        /// Returns { success, added: bool }.
        /// </summary>
        [HttpPost, IgnoreAntiforgeryToken]
        public async Task<IActionResult> ToggleWishlist([FromBody] WishlistRequest? body, int productId = 0)
        {
            if (body != null) productId = body.ProductId;
            if (!IsLogged) return Json(new { success = false, redirect = "/Customer/Login" });

            // Check if the product is already in the wishlist
            var existing = await _db.WishListItems.FirstOrDefaultAsync(
                w => w.CustomerId == CustId && w.ProductId == productId);

            if (existing != null)
            {
                // Remove from wishlist (toggle off)
                _db.WishListItems.Remove(existing);
                await _db.SaveChangesAsync();
                return Json(new { success = true, added = false });
            }

            // Add to wishlist (toggle on)
            _db.WishListItems.Add(new WishListItem
            {
                CustomerId = CustId!.Value,
                ProductId = productId,
                AddedAt = DateTime.UtcNow
            });
            await _db.SaveChangesAsync();
            return Json(new { success = true, added = true });
        }

        // ══════════════════════════════════════════════════════════════
        //  REVIEWS
        //  Customers can leave one review per product per order.
        // ══════════════════════════════════════════════════════════════

        /// <summary>
        /// GET /Customer/MyReviews
        /// Shows all reviews the customer has submitted, newest first.
        /// </summary>
        public async Task<IActionResult> MyReviews()
        {
            if (!IsLogged) return Guard();

            var reviews = await _db.Reviews.Include(r => r.Product)
                .Where(r => r.CustomerId == CustId)
                .OrderByDescending(r => r.CreatedAt)
                .ToListAsync();

            return View(reviews);
        }

        /// <summary>
        /// GET /Customer/WriteReview?productId=&amp;orderId=
        /// Shows star rating + comment + optional photo upload for a delivered order item.
        /// </summary>
        [HttpGet]
        public async Task<IActionResult> WriteReview(int productId, int orderId)
        {
            if (!IsLogged) return Guard();

            var order = await _db.Orders
                .Include(o => o.OrderItems).ThenInclude(i => i.Product)
                .FirstOrDefaultAsync(o => o.Id == orderId && o.CustomerId == CustId);
            if (order == null)
            {
                TempData["Error"] = "Order not found.";
                return RedirectToAction("MyOrders");
            }

            var reviewable = new[] { OrderStatus.ToReview, OrderStatus.Completed };
            if (!reviewable.Contains(order.Status))
            {
                TempData["Error"] = "You can review only after the order is delivered.";
                return RedirectToAction("OrderDetail", new { id = orderId });
            }

            var item = order.OrderItems?.FirstOrDefault(i => i.ProductId == productId);
            if (item?.Product == null)
            {
                TempData["Error"] = "Product not found on this order.";
                return RedirectToAction("OrderDetail", new { id = orderId });
            }

            var exists = await _db.Reviews.AnyAsync(r =>
                r.CustomerId == CustId && r.ProductId == productId && r.OrderId == orderId);
            if (exists)
            {
                TempData["Info"] = "You already reviewed this product for this order.";
                return RedirectToAction("MyReviews");
            }

            ViewBag.Order = order;
            ViewBag.Product = item.Product;
            ViewBag.OrderId = orderId;
            ViewBag.ProductId = productId;
            return View();
        }

        /// <summary>
        /// POST /Customer/AddReview — rating, comment, optional photos (max 5).
        /// </summary>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddReview(int productId, int orderId, int rating, string? comment, List<IFormFile>? photos)
        {
            if (!IsLogged) return Guard();

            var order = await _db.Orders
                .Include(o => o.OrderItems)
                .FirstOrDefaultAsync(o => o.Id == orderId && o.CustomerId == CustId);
            if (order == null)
            {
                TempData["Error"] = "Order not found or does not belong to you.";
                return RedirectToAction("MyOrders");
            }

            var reviewable = new[] { OrderStatus.ToReview, OrderStatus.Completed };
            if (!reviewable.Contains(order.Status))
            {
                TempData["Error"] = "This order is not eligible for review yet. Wait until it is delivered.";
                return RedirectToAction("OrderDetail", new { id = orderId });
            }

            if (order.OrderItems == null || !order.OrderItems.Any(i => i.ProductId == productId))
            {
                TempData["Error"] = "You can only review products you purchased in this order.";
                return RedirectToAction("OrderDetail", new { id = orderId });
            }

            if (rating < 1 || rating > 5)
            {
                TempData["Error"] = "Please select a star rating from 1 to 5.";
                return RedirectToAction("WriteReview", new { productId, orderId });
            }

            bool exists = await _db.Reviews.AnyAsync(r =>
                r.CustomerId == CustId && r.ProductId == productId && r.OrderId == orderId);
            if (exists)
            {
                TempData["Error"] = "You have already reviewed this product for this order.";
                return RedirectToAction("MyReviews");
            }

            var imagePaths = new List<string>();
            if (photos != null)
            {
                foreach (var file in photos.Where(f => f != null && f.Length > 0).Take(5))
                {
                    var path = await SaveUploadAsync(file, "reviews");
                    if (!string.IsNullOrEmpty(path)) imagePaths.Add(path);
                }
            }

            var review = new Review
            {
                CustomerId = CustId!.Value,
                ProductId = productId,
                OrderId = orderId,
                Rating = rating,
                Comment = string.IsNullOrWhiteSpace(comment) ? null : comment.Trim(),
                ImageUrls = imagePaths.Count > 0 ? string.Join(",", imagePaths) : null
            };
            _db.Reviews.Add(review);

            // If order was ToReview and all items reviewed (or at least one), move to Completed
            if (order.Status == OrderStatus.ToReview)
            {
                order.Status = OrderStatus.Completed;
            }

            await _db.SaveChangesAsync();
            TempData["Success"] = "Review submitted! Your rating and comment are now on the product page.";
            return RedirectToAction("ProductDetail", new { id = productId });
        }


        /// <summary>
        /// POST /Customer/PostReviewReply — ask a question or reply under a review.
        /// Logged-in customers only. Original reviewer replies are flagged.
        /// </summary>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> PostReviewReply(int reviewId, string message, int productId)
        {
            if (!IsLogged) return Guard($"/Customer/ProductDetail/{productId}");

            var text = (message ?? "").Trim();
            if (text.Length < 2)
            {
                TempData["Error"] = "Please write a short question or reply.";
                return RedirectToAction("ProductDetail", new { id = productId });
            }
            if (text.Length > 500) text = text[..500];

            var review = await _db.Reviews.AsNoTracking().FirstOrDefaultAsync(r => r.Id == reviewId && r.ProductId == productId);
            if (review == null)
            {
                TempData["Error"] = "Review not found.";
                return RedirectToAction("ProductDetail", new { id = productId });
            }

            _db.ReviewReplies.Add(new ReviewReply
            {
                ReviewId = reviewId,
                CustomerId = CustId!.Value,
                Message = text,
                IsReviewerReply = review.CustomerId == CustId
            });
            await _db.SaveChangesAsync();
            TempData["Success"] = review.CustomerId == CustId
                ? "Your reply was posted."
                : "Your question was posted. The reviewer can reply.";
            return RedirectToAction("ProductDetail", new { id = productId });
        }

        // ══════════════════════════════════════════════════════════════
        //  RETURNS & REFUNDS
        //  Customers file return requests; admin approves or rejects them.
        // ══════════════════════════════════════════════════════════════

        /// <summary>
        /// GET /Customer/MyReturns
        /// Lists all return requests the customer has filed, newest first.
        /// </summary>
        public async Task<IActionResult> MyReturns()
        {
            if (!IsLogged) return Guard();

            var returns = await _db.ReturnRequests.Include(r => r.Order)
                .Where(r => r.CustomerId == CustId)
                .OrderByDescending(r => r.RequestedAt)
                .ToListAsync();

            return View(returns);
        }

        /// <summary>
        /// POST /Customer/RequestReturn
        /// Opens a return/refund request for a delivered order.
        /// Also updates the Order status to ReturnRefund.
        /// One return per order is allowed (duplicates are rejected with a message).
        /// </summary>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> RequestReturn(int orderId, string reason)
        {
            if (!IsLogged) return Guard();

            // Verify the order belongs to this customer
            var order = await _db.Orders
                .Include(o => o.OrderItems)
                .FirstOrDefaultAsync(o => o.Id == orderId && o.CustomerId == CustId);
            if (order == null)
            {
                TempData["Error"] = "Order not found or does not belong to you.";
                return RedirectToAction("MyOrders");
            }

            // Eligible statuses only: delivered / review / completed / to-receive
            var eligible = new[] { OrderStatus.ToReview, OrderStatus.Completed, OrderStatus.ToReceive };
            if (!eligible.Contains(order.Status))
            {
                TempData["Error"] = "This order is not eligible for return. Only delivered or completed orders can be returned.";
                return RedirectToAction("OrderDetail", new { id = orderId });
            }

            // Prevent submitting a second return for the same order (pending or approved)
            bool duplicate = await _db.ReturnRequests.AnyAsync(
                r => r.OrderId == orderId && r.CustomerId == CustId
                     && (r.Status == ReturnStatus.Pending || r.Status == ReturnStatus.Approved));

            if (duplicate)
            {
                TempData["Error"] = "A return request already exists for this order.";
                return RedirectToAction("MyReturns");
            }

            _db.ReturnRequests.Add(new ReturnRequest
            {
                OrderId = orderId,
                CustomerId = CustId!.Value,
                Reason = reason?.Trim() ?? "Customer requested return",
                Status = ReturnStatus.Pending,
                RequestedAt = DateTime.UtcNow
            });

            // Update the order status to flag it for admin review
            order.Status = OrderStatus.ReturnRefund;

            _db.AdminNotifications.Add(new AdminNotification
            {
                Title = "Return request",
                Message = $"Order #{orderId} · {(reason ?? "").Trim()}",
                LinkUrl = "/Admin/Returns",
                Category = "return",
                CreatedAt = DateTime.UtcNow
            });

            await _db.SaveChangesAsync();
            TempData["Success"] = "Return request submitted. We will review it shortly.";
            return RedirectToAction("MyReturns");
        }

        // ── Vouchers ─────────────────────────────────────────────────────
        [HttpGet]
        public async Task<IActionResult> Vouchers()
        {
            if (!IsLogged) return Guard();
            var now = DateTime.UtcNow;
            var available = await _db.Vouchers.AsNoTracking()
                .Where(v => v.IsActive && (v.ExpiresAt == null || v.ExpiresAt > now)
                    && (v.MaxUses == null || v.UsedCount < v.MaxUses))
                .OrderByDescending(v => v.CreatedAt).ToListAsync();
            var collectedIds = await _db.CustomerVouchers
                .Where(cv => cv.CustomerId == CustId && cv.UsedAt == null)
                .Select(cv => cv.VoucherId).ToListAsync();
            ViewBag.CollectedIds = collectedIds;
            return View(available);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CollectVoucher(int voucherId)
        {
            if (!IsLogged) return Guard();
            var v = await _db.Vouchers.FindAsync(voucherId);
            if (v == null || !v.IsActive) { TempData["Error"] = "Voucher not available."; return RedirectToAction("Vouchers"); }
            var exists = await _db.CustomerVouchers.AnyAsync(cv => cv.CustomerId == CustId && cv.VoucherId == voucherId);
            if (!exists)
            {
                _db.CustomerVouchers.Add(new CustomerVoucher { CustomerId = CustId!.Value, VoucherId = voucherId });
                await _db.SaveChangesAsync();
                TempData["Success"] = $"Collected {v.Code} — use it at checkout.";
            }
            else TempData["Info"] = "You already collected this voucher.";
            return RedirectToAction("Vouchers");
        }
    }
}

// ══════════════════════════════════════════════════════════════
//  REQUEST DTOs
// ══════════════════════════════════════════════════════════════

/// <summary>JSON body for AddToCart: { "productId": 5, "quantity": 2 }</summary>
public record AddToCartRequest(int ProductId, int Quantity = 1, string? Options = null);

/// <summary>JSON body for UpdateCartItem: { "cartItemId": 3, "quantity": 1 }</summary>
public record UpdateCartRequest(int CartItemId, int Quantity);

/// <summary>JSON body for RemoveCartItem: { "cartItemId": 3 }</summary>
public record RemoveCartRequest(int CartItemId);

/// <summary>JSON body for ToggleWishlist: { "productId": 12 }</summary>
public record WishlistRequest(int ProductId);
