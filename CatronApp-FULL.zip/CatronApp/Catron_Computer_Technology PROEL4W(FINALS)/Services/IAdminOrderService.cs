// ============================================================
//  IAdminOrderService.cs – back-office orders (HotelEase-style)
// ============================================================
using Catron_Computer_Technology_PROEL4W_FINALS_.Models;
using Catron_Computer_Technology_PROEL4W_FINALS_.Models.ViewModels;

namespace Catron_Computer_Technology_PROEL4W_FINALS_.Services
{
    public interface IAdminOrderService
    {
        Task<AdminDashboardViewModel> GetDashboardAsync();
        Task<List<Order>> GetOrdersAsync(string filter = "All");
        Task<Order?> GetOrderDetailAsync(int id);
        Task<bool> UpdateStatusAsync(int orderId, OrderStatus status);
    }
}
