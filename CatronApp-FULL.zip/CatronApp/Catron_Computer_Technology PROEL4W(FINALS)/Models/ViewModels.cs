﻿// ============================================================
//  ViewModels.cs
//  Namespace: Catron_Computer_Technology_PROEL4W_FINALS_.Models.ViewModels
//
//  Purpose:
//    Strongly-typed view model classes passed between Controllers
//    and Razor Views.  ViewModels carry ONLY the data each view
//    needs – they are never stored directly in the database.
//
//  Sections:
//    A. Customer Authentication ViewModels
//    B. Admin Authentication ViewModels
//    C. Shared Auth ViewModels (Forgot / Reset Password)
//    D. Customer Storefront ViewModels (Home, Products, Cart,
//       Checkout, Payment, Account, Orders)
//    E. Admin Panel ViewModels (Dashboard, Product Form,
//       Delivery Tracking, Customer Detail)
//    F. Category Management ViewModels   ← NEW
//    G. User (Admin) Management ViewModels ← NEW
// ============================================================

using System.ComponentModel.DataAnnotations;

namespace Catron_Computer_Technology_PROEL4W_FINALS_.Models.ViewModels
{
    // ══════════════════════════════════════════════════════════════
    //  A. CUSTOMER AUTHENTICATION
    // ══════════════════════════════════════════════════════════════

    /// <summary>
    /// Data the login form posts to CustomerController.Login (POST).
    /// Validates email format and requires both fields.
    /// </summary>
    public class CustomerLoginViewModel
    {
        [Required(ErrorMessage = "Email is required.")]
        [EmailAddress(ErrorMessage = "Enter a valid email address.")]
        public string Email { get; set; } = "";

        [Required(ErrorMessage = "Password is required.")]
        [DataType(DataType.Password)]
        public string Password { get; set; } = "";

        /// <summary>Unused for now; reserved for future cookie-based remember-me.</summary>
        public bool RememberMe { get; set; }
    }

    /// <summary>
    /// Data the registration form posts to CustomerController.Register (POST).
    /// ConfirmPassword must match Password – enforced by [Compare].
    /// </summary>
    public class CustomerRegisterViewModel
    {
        [Required(ErrorMessage = "First name is required."), StringLength(100)]
        public string FirstName { get; set; } = "";

        [Required(ErrorMessage = "Last name is required."), StringLength(100)]
        public string LastName { get; set; } = "";

        [Required(ErrorMessage = "Email is required."), EmailAddress]
        public string Email { get; set; } = "";

        [Phone]
        public string? PhoneNumber { get; set; }

        [Required, DataType(DataType.Password), MinLength(6, ErrorMessage = "Minimum 6 characters.")]
        public string Password { get; set; } = "";

        [Required, DataType(DataType.Password), Compare("Password", ErrorMessage = "Passwords do not match.")]
        public string ConfirmPassword { get; set; } = "";
    }

    // ══════════════════════════════════════════════════════════════
    //  B. ADMIN AUTHENTICATION
    // ══════════════════════════════════════════════════════════════

    /// <summary>
    /// Data posted to AdminController.Login (POST).
    /// Uses Username (not Email) for admin authentication.
    /// </summary>
    public class AdminLoginViewModel
    {
        [Required(ErrorMessage = "Username is required.")]
        public string Username { get; set; } = "";

        [Required(ErrorMessage = "Password is required."), DataType(DataType.Password)]
        public string Password { get; set; } = "";
    }

    /// <summary>
    /// Data posted to AdminController.Register (POST).
    /// Creates a new Admin record with a BCrypt-hashed password.
    /// </summary>
    public class AdminRegisterViewModel
    {
        [Required, StringLength(100)]
        public string Username { get; set; } = "";

        [Required, EmailAddress]
        public string Email { get; set; } = "";

        [Required, DataType(DataType.Password), MinLength(6, ErrorMessage = "Minimum 6 characters.")]
        public string Password { get; set; } = "";

        [Required, DataType(DataType.Password), Compare("Password", ErrorMessage = "Passwords do not match.")]
        public string ConfirmPassword { get; set; } = "";
    }

    // ══════════════════════════════════════════════════════════════
    //  C. SHARED AUTH – FORGOT / RESET PASSWORD
    //     Used by both Admin and Customer reset flows.
    // ══════════════════════════════════════════════════════════════

    /// <summary>
    /// Carries the email the user types on the Forgot Password page.
    /// The controller looks up the matching account and stores a reset token.
    /// </summary>
    public class ForgotPasswordViewModel
    {
        [Required, EmailAddress]
        public string Email { get; set; } = "";
    }

    /// <summary>
    /// Carries the token (from the email link), the email, and the new password.
    /// Token and Email are hidden fields in the Reset Password view.
    /// </summary>
    public class ResetPasswordViewModel
    {
        /// <summary>The secure random token from the password-reset email link.</summary>
        [Required] public string Token { get; set; } = "";

        /// <summary>Email address identifies which account to reset.</summary>
        [Required, EmailAddress] public string Email { get; set; } = "";

        [Required, DataType(DataType.Password), MinLength(6)]
        public string NewPassword { get; set; } = "";

        [Required, DataType(DataType.Password), Compare("NewPassword", ErrorMessage = "Passwords do not match.")]
        public string ConfirmPassword { get; set; } = "";
    }

    // ══════════════════════════════════════════════════════════════
    //  D. CUSTOMER STOREFRONT
    // ══════════════════════════════════════════════════════════════

    /// <summary>
    /// Passed to Views/Customer/Index.cshtml (the storefront home page).
    /// Shows featured products and a list of categories for navigation.
    /// </summary>
    public class HomeViewModel
    {
        public IEnumerable<Product> FeaturedProducts { get; set; } = new List<Product>();
        public IEnumerable<Category> Categories { get; set; } = new List<Category>();
    }

    /// <summary>
    /// Passed to Views/Customer/Products.cshtml (the product listing page).
    /// Supports filtering by category, full-text search, and pagination.
    /// </summary>
    public class ProductListViewModel
    {
        /// <summary>The paginated product results for the current page.</summary>
        public IEnumerable<Product> Products { get; set; } = new List<Product>();

        /// <summary>All categories – used to render the filter sidebar.</summary>
        public IEnumerable<Category> Categories { get; set; } = new List<Category>();

        /// <summary>The currently active category filter (null = show all).</summary>
        public int? SelectedCategoryId { get; set; }

        /// <summary>The user's search keyword (null = no search).</summary>
        public string? SearchQuery { get; set; }

        public int CurrentPage { get; set; } = 1;
        public int TotalPages { get; set; } = 1;
        public int TotalItems { get; set; }
    }

    /// <summary>
    /// Passed to Views/Customer/ProductDetail.cshtml.
    /// Bundles the main product with its reviews, related products,
    /// wishlist status, and average star rating.
    /// </summary>
    public class ProductDetailViewModel
    {
        public Product Product { get; set; } = null!;
        public IEnumerable<Review> Reviews { get; set; } = new List<Review>();
        public IEnumerable<Product> RelatedProducts { get; set; } = new List<Product>();

        /// <summary>True if the logged-in customer has this product in their wishlist.</summary>
        public bool IsInWishlist { get; set; }

        /// <summary>Average of all review ratings for this product (0 if no reviews).</summary>
        public double AverageRating { get; set; }
    }

    /// <summary>
    /// Passed to Views/Customer/Cart.cshtml.
    /// Contains all cart line items plus computed totals.
    /// </summary>
    public class CartViewModel
    {
        public IEnumerable<CartItem> CartItems { get; set; } = new List<CartItem>();

        /// <summary>Grand total across all cart items.</summary>
        public decimal TotalAmount { get; set; }

        /// <summary>Total number of individual units in the cart.</summary>
        public int TotalItems { get; set; }
    }

    /// <summary>
    /// Passed to Views/Customer/Checkout.cshtml and posted back to
    /// CustomerController.PlaceOrder (POST).
    /// The customer chooses a saved address OR enters a new one.
    /// </summary>
    public class CheckoutViewModel
    {
        public IEnumerable<CartItem> CartItems { get; set; } = new List<CartItem>();
        public decimal TotalAmount { get; set; }

        /// <summary>The customer's saved addresses shown as radio-button options.</summary>
        public List<CustomerAddress> SavedAddresses { get; set; } = new();

        /// <summary>
        /// Collected, unused vouchers available for this customer to select at checkout.
        /// </summary>
        public List<Voucher> AvailableVouchers { get; set; } = new();

        /// <summary>
        /// Which saved address the customer selected via radio button.
        /// When set, PlaceOrder loads the address from DB instead of
        /// relying on the text fields (which may be blank after posting).
        /// </summary>
        public int? SelectedAddressId { get; set; }

        [Required(ErrorMessage = "Full name is required.")]
        public string ShippingFullName { get; set; } = "";

        [Required(ErrorMessage = "Address is required.")]
        public string ShippingAddress { get; set; } = "";

        [Required(ErrorMessage = "Phone number is required."), Phone]
        public string ShippingPhone { get; set; } = "";
    }

    /// <summary>
    /// Passed to Views/Customer/Pay.cshtml (the payment confirmation page).
    /// Carries the order summary plus QR code for GCash payments.
    /// </summary>
    public class PaymentViewModel
    {
        public Order Order { get; set; } = null!;
        public PaymentMethod SelectedMethod { get; set; }

        /// <summary>Store GCash number displayed on the payment page.</summary>
        public string? GCashNumber { get; set; }

        /// <summary>Base64 PNG of the GCash QR code. Null for non-GCash methods.</summary>
        public string? QrCodeBase64 { get; set; }
    }

    /// <summary>
    /// Passed to Views/Customer/Dashboard.cshtml (logged-in customer home).
    /// Shows a greeting and the customer's 5 most recent orders.
    /// </summary>
    public class AccountDashboardViewModel
    {
        public Customer Customer { get; set; } = null!;
        public IEnumerable<Order> RecentOrders { get; set; } = new List<Order>();
    }

    /// <summary>
    /// Passed to Views/Customer/ManageAccount.cshtml.
    /// Bundles the customer profile, saved addresses, and recent orders
    /// into one page for account self-service.
    /// </summary>
    public class ManageAccountViewModel
    {
        public Customer Customer { get; set; } = null!;
        public List<CustomerAddress> Addresses { get; set; } = new();
        public CustomerAddress? DefaultBillingAddress { get; set; }

        /// <summary>Last 5 orders shown in the account summary sidebar.</summary>
        public List<Order> RecentOrders { get; set; } = new();
    }

    /// <summary>
    /// Posted by the Edit Profile form in ManageAccount.
    /// Only editable fields are included – Email and Password are changed separately.
    /// </summary>
    public class UpdateProfileViewModel
    {
        [Required, StringLength(100)] public string FirstName { get; set; } = "";
        [Required, StringLength(100)] public string LastName { get; set; } = "";
        [Phone] public string? PhoneNumber { get; set; }
    }

    /// <summary>
    /// Passed to Views/Customer/MyOrders.cshtml.
    /// The Filter property controls which tab is active
    /// (All / ToPay / ToShip / ToReceive / Cancelled, etc.).
    /// </summary>
    public class OrderListViewModel
    {
        public IEnumerable<Order> Orders { get; set; } = new List<Order>();
        public string Filter { get; set; } = "All";
    }

    // ══════════════════════════════════════════════════════════════
    //  E. ADMIN PANEL
    // ══════════════════════════════════════════════════════════════

    /// <summary>
    /// Passed to Views/Admin/Dashboard.cshtml.
    /// Aggregates KPI counts and lists for the admin overview page.
    /// </summary>
    public class AdminDashboardViewModel
    {
        public int TotalCustomers { get; set; }
        public int TotalOrders { get; set; }
        public int TotalProducts { get; set; }
        public decimal TotalRevenue { get; set; }

        // Operational counts — "what needs attention"
        public int OrdersToPay { get; set; }
        public int OrdersToShip { get; set; }
        public int OrdersToReceive { get; set; }
        public int PendingGCashCount { get; set; }
        public int PendingReturnCount { get; set; }
        public int LowStockCount { get; set; }
        public int OutOfStockCount { get; set; }

        // Today KPIs
        public int OrdersToday { get; set; }
        public decimal RevenueToday { get; set; }
        public int OrdersYesterday { get; set; }
        public decimal RevenueYesterday { get; set; }

        public IEnumerable<Order> RecentOrders { get; set; } = new List<Order>();
        public IEnumerable<Product> LowStockProducts { get; set; } = new List<Product>();
        public IEnumerable<ReturnRequest> PendingReturns { get; set; } = new List<ReturnRequest>();
        public IEnumerable<Customer> RecentCustomers { get; set; } = new List<Customer>();
    }

    /// <summary>
    /// Used by the Add Product and Edit Product form (Views/Admin/ProductForm.cshtml).
    /// Id = 0 means a new product; Id > 0 means edit an existing one.
    /// Categories is populated from DB for the category dropdown.
    /// </summary>
    public class ProductFormViewModel
    {
        /// <summary>0 for a new product; existing product Id for edits.</summary>
        public int Id { get; set; }

        [Required(ErrorMessage = "Product name is required."), StringLength(200)]
        public string Name { get; set; } = "";

        public string? Description { get; set; }

        [Required, Range(0.01, 9999999, ErrorMessage = "Price must be greater than 0.")]
        public decimal Price { get; set; }

        [Range(0.01, 9999999)]
        public decimal? DiscountPrice { get; set; }

        [Range(0, int.MaxValue)]
        public int Stock { get; set; }

        public string? ImageUrl { get; set; }
        public string? Brand { get; set; }
        public bool IsActive { get; set; } = true;
        /// <summary>Used only to carry IsCreate flag for view logic.</summary>
        public bool IsCreateMode { get; set; } = false;

        [Required(ErrorMessage = "Please select a category.")]
        public int CategoryId { get; set; }

        /// <summary>Populated in the controller for the category &lt;select&gt; dropdown.</summary>
        public IEnumerable<Category> Categories { get; set; } = new List<Category>();
    }

    /// <summary>
    /// Posted by the Add Tracking form on Views/Admin/OrderDetail.cshtml.
    /// Creates a new DeliveryTracking milestone for an order.
    /// </summary>
    public class AddDeliveryTrackingViewModel
    {
        public int OrderId { get; set; }

        [Required(ErrorMessage = "Status is required."), StringLength(200)]
        public string Status { get; set; } = "";

        [StringLength(300)] public string? Location { get; set; }
        public string? Notes { get; set; }
        public DateTime TrackingTime { get; set; } = DateTime.Now;
    }

    /// <summary>
    /// Passed to Views/Admin/CustomerDetail.cshtml.
    /// Bundles the customer record with their address list and order history.
    /// </summary>
    public class CustomerDetailViewModel
    {
        public Customer Customer { get; set; } = null!;
        public List<CustomerAddress> Addresses { get; set; } = new();
        public List<Order> Orders { get; set; } = new();
    }

    // ══════════════════════════════════════════════════════════════
    //  F. CATEGORY MANAGEMENT  ← NEW SECTION
    //     Used by AdminController actions:
    //       Categories    – list all categories
    //       CategoryForm  – add / edit a category
    // ══════════════════════════════════════════════════════════════

    /// <summary>
    /// Form view model for adding or editing a Category
    /// (Views/Admin/CategoryForm.cshtml).
    /// Id = 0 → new category; Id > 0 → edit existing.
    /// </summary>
    public class CategoryFormViewModel
    {
        /// <summary>0 for a new category; existing Category.Id for edits.</summary>
        public int Id { get; set; }

        [Required(ErrorMessage = "Category name is required."), StringLength(100)]
        public string Name { get; set; } = "";

        [StringLength(500)]
        public string? Description { get; set; }

        /// <summary>
        /// Font Awesome icon class shown in the storefront navigation.
        /// Example: "fas fa-laptop", "fas fa-print".
        /// </summary>
        [StringLength(100)]
        public string? IconClass { get; set; }

        /// <summary>False hides the category from customers while preserving its products.</summary>
        public bool IsActive { get; set; } = true;

        /// <summary>Existing image path (for edit mode display).</summary>
        public string? ImageUrl { get; set; }
    }

    // ══════════════════════════════════════════════════════════════
    //  G. USER (ADMIN) MANAGEMENT  ← NEW SECTION
    //     Used by AdminController actions:
    //       UserManagement   – list all admin accounts
    //       UserForm         – add / edit an admin account
    //       ChangeAdminPassword – admin changes another admin's password
    // ══════════════════════════════════════════════════════════════

    /// <summary>
    /// Form view model for creating or editing an Admin account
    /// (Views/Admin/UserForm.cshtml).
    /// When editing (Id > 0) the Password fields are left blank;
    /// only fill them in to set a new password.
    /// </summary>
    public class UserFormViewModel
    {
        /// <summary>0 for a new admin account; existing Admin.Id for edits.</summary>
        public int Id { get; set; }

        [Required(ErrorMessage = "Username is required."), StringLength(100)]
        public string Username { get; set; } = "";

        [Required(ErrorMessage = "Email is required."), EmailAddress]
        public string Email { get; set; } = "";

        /// <summary>
        /// Required only when creating a new admin.
        /// Leave blank when editing to keep the existing password unchanged.
        /// </summary>
        [DataType(DataType.Password), MinLength(6, ErrorMessage = "Minimum 6 characters.")]
        public string? Password { get; set; }

        [DataType(DataType.Password), Compare("Password", ErrorMessage = "Passwords do not match.")]
        public string? ConfirmPassword { get; set; }

        /// <summary>Inactive admins cannot log in to the admin panel.</summary>
        public bool IsActive { get; set; } = true;

        /// <summary>Existing profile picture path (for edit mode display).</summary>
        public string? ProfilePicture { get; set; }

        /// <summary>Staff role (Admin / Sales / Inventory / Support).</summary>
        public AdminRole Role { get; set; } = AdminRole.Admin;
    }

    /// <summary>Admin profile edit view model.</summary>
    public class AdminProfileViewModel
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Username is required."), StringLength(100)]
        public string Username { get; set; } = "";

        [Required(ErrorMessage = "Email is required."), EmailAddress]
        public string Email { get; set; } = "";

        public string? ProfilePicture { get; set; }

        [DataType(DataType.Password), MinLength(6, ErrorMessage = "Minimum 6 characters.")]
        public string? NewPassword { get; set; }

        [DataType(DataType.Password), Compare("NewPassword", ErrorMessage = "Passwords do not match.")]
        public string? ConfirmPassword { get; set; }
    }
}
