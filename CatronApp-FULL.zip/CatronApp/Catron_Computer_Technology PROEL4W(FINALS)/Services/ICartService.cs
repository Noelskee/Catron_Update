using Catron_Computer_Technology_PROEL4W_FINALS_.Models;

namespace Catron_Computer_Technology_PROEL4W_FINALS_.Services
{
    public interface ICartService
    {
        Task<List<CartItem>> GetCartAsync(int customerId);
        Task<int> GetCartCountAsync(int customerId);
        Task<(bool success, string message, int count)> AddToCartAsync(int customerId, int productId, int quantity, string? selectedOptions = null);
        Task<(bool success, decimal subtotal, decimal total, int count)> UpdateQuantityAsync(int customerId, int cartItemId, int quantity);
        Task<(bool success, decimal total, int count)> RemoveAsync(int customerId, int cartItemId);
    }
}
