// ============================================================
//  ISalesInvoiceService.cs – personal SI (like HotelEase BillingService)
// ============================================================
using Catron_Computer_Technology_PROEL4W_FINALS_.Models;

namespace Catron_Computer_Technology_PROEL4W_FINALS_.Services
{
    public class SalesInvoiceLine
    {
        public int LineNo { get; set; }
        public string Description { get; set; } = "";
        public string? Brand { get; set; }
        public int Quantity { get; set; }
        public decimal UnitPrice { get; set; }
        public decimal Amount => UnitPrice * Quantity;
    }

    public class SalesInvoiceDocument
    {
        public string InvoiceNumber { get; set; } = "";
        public DateTime IssuedAt { get; set; }
        public string OrderNumber { get; set; } = "";
        public int OrderId { get; set; }

        // Seller (from BusinessInfo)
        public string SellerName { get; set; } = BusinessInfo.LegalName;
        public string SellerAddress { get; set; } = BusinessInfo.FullAddress;
        public string SellerPhone { get; set; } = BusinessInfo.PhonePrimary;
        public string SellerEmail { get; set; } = BusinessInfo.Email;

        // Buyer (from order shipping snapshot)
        public string BuyerName { get; set; } = "";
        public string BuyerAddress { get; set; } = "";
        public string BuyerPhone { get; set; } = "";

        public List<SalesInvoiceLine> Lines { get; set; } = new();
        public decimal Subtotal { get; set; }
        public decimal TotalAmount { get; set; }
        public string PaymentMethod { get; set; } = "";
        public string PaymentStatus { get; set; } = "";
        public string? PaymentReference { get; set; }
        public string Notes { get; set; } = "Thank you for your purchase. For support, contact us on Viber " + BusinessInfo.Viber + ".";
    }

    public interface ISalesInvoiceService
    {
        /// <summary>Build a personal Sales Invoice document for an order (creates Receipt if missing).</summary>
        Task<SalesInvoiceDocument?> GetOrCreateInvoiceAsync(int orderId);

        /// <summary>SI-YYYYMMDD-#### sequential-style number for the day.</summary>
        string FormatInvoiceNumber(int orderId, DateTime issuedAt);
    }
}
