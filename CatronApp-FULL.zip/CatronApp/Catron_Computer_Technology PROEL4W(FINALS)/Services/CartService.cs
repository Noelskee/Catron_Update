// ============================================================
//  CartService.cs – shopping cart logic (HotelEase-style service)
// ============================================================
using Catron_Computer_Technology_PROEL4W_FINALS_.Data;
using Catron_Computer_Technology_PROEL4W_FINALS_.Models;
using Microsoft.EntityFrameworkCore;

namespace Catron_Computer_Technology_PROEL4W_FINALS_.Services
{
    public class CartService : ICartService
    {
        private readonly ApplicationDbContext _db;

        public CartService(ApplicationDbContext db)
        {
            _db = db;
        }

        public async Task<List<CartItem>> GetCartAsync(int customerId)
        {
            return await _db.CartItems
                .Include(c => c.Product)
                .Where(c => c.CustomerId == customerId)
                .OrderByDescending(c => c.AddedAt)
                .ToListAsync();
        }

        public async Task<int> GetCartCountAsync(int customerId)
        {
            return await _db.CartItems
                .Where(c => c.CustomerId == customerId)
                .SumAsync(c => (int?)c.Quantity) ?? 0;
        }

        public async Task<(bool success, string message, int count)> AddToCartAsync(int customerId, int productId, int quantity, string? selectedOptions = null)
        {
            if (quantity < 1) quantity = 1;

            var product = await _db.Products.FirstOrDefaultAsync(p => p.Id == productId && p.IsActive);
            if (product == null)
                return (false, "Product not found.", 0);
            if (product.Stock <= 0)
                return (false, "Out of stock.", 0);

            var opt = string.IsNullOrWhiteSpace(selectedOptions) ? null : selectedOptions.Trim();

            var existing = await _db.CartItems
                .FirstOrDefaultAsync(c => c.CustomerId == customerId && c.ProductId == productId
                    && (c.SelectedOptions == opt || (c.SelectedOptions == null && opt == null)));

            if (existing != null)
            {
                existing.Quantity = Math.Min(existing.Quantity + quantity, product.Stock);
            }
            else
            {
                _db.CartItems.Add(new CartItem
                {
                    CustomerId = customerId,
                    ProductId = productId,
                    Quantity = Math.Min(quantity, product.Stock),
                    AddedAt = DateTime.UtcNow,
                    SelectedOptions = opt
                });
            }

            await _db.SaveChangesAsync();
            var count = await GetCartCountAsync(customerId);
            return (true, "Added to cart.", count);
        }

        public async Task<(bool success, decimal subtotal, decimal total, int count)> UpdateQuantityAsync(int customerId, int cartItemId, int quantity)
        {
            var item = await _db.CartItems.Include(c => c.Product)
                .FirstOrDefaultAsync(c => c.Id == cartItemId && c.CustomerId == customerId);
            if (item == null)
                return (false, 0, 0, 0);

            if (quantity <= 0)
                _db.CartItems.Remove(item);
            else
                item.Quantity = Math.Min(quantity, item.Product.Stock);

            await _db.SaveChangesAsync();

            var all = await GetCartAsync(customerId);
            decimal line = quantity > 0 ? item.Product.FinalPrice * quantity : 0;
            decimal total = all.Sum(i => i.Product.FinalPrice * i.Quantity);
            int count = all.Sum(i => i.Quantity);
            return (true, line, total, count);
        }

        public async Task<(bool success, decimal total, int count)> RemoveAsync(int customerId, int cartItemId)
        {
            var item = await _db.CartItems
                .FirstOrDefaultAsync(c => c.Id == cartItemId && c.CustomerId == customerId);
            if (item != null)
            {
                _db.CartItems.Remove(item);
                await _db.SaveChangesAsync();
            }

            var all = await GetCartAsync(customerId);
            return (true, all.Sum(i => i.Product.FinalPrice * i.Quantity), all.Sum(i => i.Quantity));
        }
    }
}
