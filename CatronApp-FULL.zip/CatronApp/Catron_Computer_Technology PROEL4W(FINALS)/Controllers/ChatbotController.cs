using System.Text;
using System.Text.Json;
using Catron_Computer_Technology_PROEL4W_FINALS_.Models;
using Catron_Computer_Technology_PROEL4W_FINALS_.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;

namespace Catron_Computer_Technology_PROEL4W_FINALS_.Controllers
{
    public class ChatMessageRequest
    {
        public string? Message { get; set; }
    }

    /// <summary>
    /// Catron AI Assistant.
    /// - If Chatbot:ApiKey is set → Google Gemini (chat about anything)
    /// - If no key / API fails → offline store FAQ fallback
    /// </summary>
    [Route("[controller]")]
    public class ChatbotController : Controller
    {
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly ChatbotSettings _settings;
        private readonly ILogger<ChatbotController> _logger;

        public ChatbotController(
            IHttpClientFactory httpClientFactory,
            IOptions<ChatbotSettings> settings,
            ILogger<ChatbotController> logger)
        {
            _httpClientFactory = httpClientFactory;
            _settings = settings.Value;
            _logger = logger;
        }

        [HttpPost("SendMessage")]
        public async Task<IActionResult> SendMessage([FromBody] ChatMessageRequest request)
        {
            var text = (request?.Message ?? "").Trim();
            if (string.IsNullOrEmpty(text))
                return Json(new { success = false, message = "Please type a message." });

            if (HasRealApiKey())
            {
                try
                {
                    var ai = await CallGeminiAsync(text);
                    if (!string.IsNullOrWhiteSpace(ai))
                        return Json(new { success = true, message = ai });
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, "Gemini failed — using offline fallback");
                }
            }

            return Json(new { success = true, message = BuildOfflineReply(text) });
        }

        private async Task<string?> CallGeminiAsync(string userMessage)
        {
            var client = _httpClientFactory.CreateClient("Chatbot");
            client.Timeout = TimeSpan.FromSeconds(45);

            var systemText = string.IsNullOrWhiteSpace(_settings.SystemPrompt)
                ? DefaultSystemPrompt()
                : _settings.SystemPrompt + "\n\n" + StoreContext();

            var payload = new Dictionary<string, object?>
            {
                ["system_instruction"] = new
                {
                    parts = new[] { new { text = systemText } }
                },
                ["contents"] = new object[]
                {
                    new
                    {
                        role = "user",
                        parts = new[] { new { text = userMessage } }
                    }
                },
                ["generationConfig"] = new
                {
                    temperature = 0.8,
                    maxOutputTokens = 2048
                }
            };
            var json = JsonSerializer.Serialize(payload);

            // Prefer models known to work for new API keys (order matters)
            var models = new List<string>();
            if (!string.IsNullOrWhiteSpace(_settings.ApiUrl))
            {
                var configured = _settings.ApiUrl.Trim();
                // Extract model name from full URL if needed
                if (configured.Contains("/models/"))
                {
                    var part = configured.Split(new[] { "/models/" }, StringSplitOptions.None).LastOrDefault() ?? "";
                    part = part.Split(':')[0].Split('?')[0];
                    if (!string.IsNullOrEmpty(part)) models.Add(part);
                }
                else if (!configured.Contains("://"))
                {
                    models.Add(configured);
                }
            }
            models.AddRange(new[]
            {
                "gemini-3.5-flash",
                "gemini-3.8-flash",
                "gemini-flash-latest",
                "gemini-3.5-flash-lite",
                "gemini-2.5-flash",
                "gemini-3-flash-preview"
            });

            // unique keep order
            var tried = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            string? lastError = null;

            foreach (var model in models)
            {
                if (!tried.Add(model)) continue;
                var endpoint = $"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
                               + "?key=" + Uri.EscapeDataString(_settings.ApiKey);
                try
                {
                    using var req = new HttpRequestMessage(HttpMethod.Post, endpoint);
                    req.Content = new StringContent(json, Encoding.UTF8, "application/json");
                    using var res = await client.SendAsync(req);
                    var body = await res.Content.ReadAsStringAsync();

                    if (!res.IsSuccessStatusCode)
                    {
                        lastError = $"HTTP {(int)res.StatusCode} ({model})";
                        _logger.LogWarning("Gemini {Model} failed: {Code} {Body}", model, (int)res.StatusCode, body.Length > 300 ? body[..300] : body);
                        // try next model on 404/503
                        continue;
                    }

                    using var doc = JsonDocument.Parse(body);
                    var root = doc.RootElement;
                    if (!root.TryGetProperty("candidates", out var cands) || cands.GetArrayLength() == 0)
                    {
                        lastError = "No candidates from " + model;
                        continue;
                    }

                    var content = cands[0].GetProperty("content");
                    if (!content.TryGetProperty("parts", out var parts) || parts.GetArrayLength() == 0)
                    {
                        lastError = "Empty parts from " + model;
                        continue;
                    }

                    // Find first part with text (skip thought-only parts if any)
                    foreach (var part in parts.EnumerateArray())
                    {
                        if (part.TryGetProperty("text", out var t))
                        {
                            var answer = t.GetString()?.Trim();
                            if (!string.IsNullOrWhiteSpace(answer))
                            {
                                _logger.LogInformation("Gemini answered via {Model}", model);
                                return answer;
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    lastError = ex.Message;
                    _logger.LogWarning(ex, "Gemini call exception for {Model}", model);
                }
            }

            _logger.LogWarning("All Gemini models failed. Last: {Err}", lastError);
            return null;
        }

        private static string DefaultSystemPrompt() =>
            "You are Catron AI Assistant for Catron Computer Technology – CEBU, a computer and office supplies store in Cebu City, Philippines. " +
            "Be helpful, friendly, and concise. You can answer ANY question (like ChatGPT): tech, school, general knowledge, as well as store topics. " +
            "When relevant, help with products (laptops, desktops, components, software), prices in PHP (₱), delivery in Cebu, GCash/COD, order tracking, and 7-day returns.";

        private static string StoreContext() =>
            $"Store: {BusinessInfo.TradeName}\n" +
            $"Address: {BusinessInfo.FullAddress}\n" +
            $"Phone: {BusinessInfo.PhonePrimary}\n" +
            $"Viber: {BusinessInfo.Viber}\n" +
            $"Email: {BusinessInfo.Email}\n" +
            $"Hours: {BusinessInfo.BusinessHours}";

        private bool HasRealApiKey()
        {
            var k = (_settings.ApiKey ?? "").Trim();
            if (string.IsNullOrEmpty(k)) return false;
            // Ignore common placeholders so Gemini is not called with a fake key
            if (k.Contains("PASTE_", StringComparison.OrdinalIgnoreCase)) return false;
            if (k.Contains("YOUR_", StringComparison.OrdinalIgnoreCase)) return false;
            if (k.Equals("changeme", StringComparison.OrdinalIgnoreCase)) return false;
            return k.Length >= 20;
        }

        private static string BuildOfflineReply(string input)
        {
            var q = input.ToLowerInvariant();

            if (Contains(q, "hello", "hi", "hey", "good morning", "good afternoon"))
                return $"Hi! Welcome to {BusinessInfo.TradeName}. Ask me about laptops, delivery, GCash/COD, vouchers, returns, or store contact.";

            if (Contains(q, "contact", "viber", "phone", "address", "location", "where"))
                return $"{BusinessInfo.TradeName}\n📍 {BusinessInfo.FullAddress}\n📞 {BusinessInfo.PhonePrimary}\n💬 Viber: {BusinessInfo.Viber}\n✉️ {BusinessInfo.Email}\n🕒 {BusinessInfo.BusinessHours}";

            if (Contains(q, "gcash", "payment", "cod", "cash on delivery", "pay"))
                return "Payment options:\n• GCash — pay online (marked Paid after you confirm)\n• Cash on Delivery (COD) — pay when the parcel is delivered\n\nCard options may also be available at checkout.";

            if (Contains(q, "deliver", "shipping", "ship", "free delivery", "cebu"))
                return "We deliver across Cebu. Free delivery for qualified orders in the metro area. Tracking updates appear under My Orders after you place an order.";

            if (Contains(q, "return", "refund", "warranty", "7-day"))
                return "7-day returns on eligible items. Open My Orders → the order → Request Return. Admin reviews each request.";

            if (Contains(q, "voucher", "promo", "discount", "coupon"))
                return "Collect vouchers under Account → Vouchers, then select one at checkout (no need to type the code).";

            if (Contains(q, "track", "order status", "my order"))
                return "Track orders under My Orders. Status goes: To Pay → To Ship → To Receive → Completed. COD is Paid only after delivery.";

            if (Contains(q, "laptop", "desktop", "printer", "product", "price", "stock"))
                return "Browse Laptops, Components, Peripherals from the menu or use search. Product pages show price, stock, and specs. Need a specific model? Message us on Viber: " + BusinessInfo.Viber;

            if (Contains(q, "hour", "open", "close", "schedule"))
                return $"Store hours: {BusinessInfo.BusinessHours}";

            if (Contains(q, "what is catron", "who is catron", "about catron", "catron"))
                return $"{BusinessInfo.TradeName} is a computer & office supplies store in Cebu City.\n" +
                       $"We sell laptops, desktops, components, peripherals, software, and more.\n" +
                       $"📍 {BusinessInfo.FullAddress}\n📞 {BusinessInfo.PhonePrimary}\n💬 Viber: {BusinessInfo.Viber}\n" +
                       "Payment: GCash or Cash on Delivery. Free delivery in Cebu (qualified orders). 7-day returns.";

            // General / non-store questions when Gemini is not configured / failed
            return "I can help with Catron store topics (products, delivery, COD/GCash, vouchers, returns, contact).\n\n" +
                   "If Gemini AI is not answering general questions, check:\n" +
                   "1) appsettings.json → Chatbot:ApiKey is filled\n" +
                   "2) ApiUrl uses gemini-2.5-flash\n" +
                   "3) Restart the app after changing settings\n\n" +
                   $"Store Viber: {BusinessInfo.Viber}";
        }

        private static bool Contains(string hay, params string[] needles)
            => needles.Any(n => hay.Contains(n));
    }
}
