// ============================================================
//  IProductService.cs – Service layer (same pattern as HotelEase)
// ============================================================
using Catron_Computer_Technology_PROEL4W_FINALS_.Models;
using Catron_Computer_Technology_PROEL4W_FINALS_.Models.ViewModels;

namespace Catron_Computer_Technology_PROEL4W_FINALS_.Services
{
    public interface IProductService
    {
        Task<HomeViewModel> GetHomeAsync();
        Task<ProductListViewModel> GetProductsAsync(int? categoryId, string? search, int page = 1, int pageSize = 12);
        Task<Product?> GetByIdAsync(int id, bool activeOnly = true);
        Task<List<Product>> GetRelatedAsync(int productId, int categoryId, int take = 4);
        Task<List<Category>> GetActiveCategoriesAsync();
    }
}
