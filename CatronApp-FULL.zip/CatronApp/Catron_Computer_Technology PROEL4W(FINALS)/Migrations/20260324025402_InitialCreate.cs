﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace Catron_Computer_Technology_PROEL4W_FINALS_.Migrations
{
    /// <inheritdoc />
    public partial class InitialCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Admins",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Username = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Email = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    PasswordHash = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ResetToken = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ResetTokenExpiry = table.Column<DateTime>(type: "datetime2", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    ProfilePicture = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Admins", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Categories",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    IconClass = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    ImageUrl = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Categories", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Customers",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FirstName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    LastName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Email = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    PasswordHash = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    PhoneNumber = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    ResetToken = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ResetTokenExpiry = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ProfilePicture = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Customers", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Products",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Price = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    DiscountPrice = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    Stock = table.Column<int>(type: "int", nullable: false),
                    ImageUrl = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Brand = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CategoryId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Products", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Products_Categories_CategoryId",
                        column: x => x.CategoryId,
                        principalTable: "Categories",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "CustomerAddresses",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CustomerId = table.Column<int>(type: "int", nullable: false),
                    FullName = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    Address = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                    PhoneNumber = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    IsDefault = table.Column<bool>(type: "bit", nullable: false),
                    IsBillingDefault = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CustomerAddresses", x => x.Id);
                    table.ForeignKey(
                        name: "FK_CustomerAddresses_Customers_CustomerId",
                        column: x => x.CustomerId,
                        principalTable: "Customers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Orders",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CustomerId = table.Column<int>(type: "int", nullable: false),
                    OrderNumber = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    TotalAmount = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Status = table.Column<int>(type: "int", nullable: false),
                    PaymentMethod = table.Column<int>(type: "int", nullable: false),
                    PaymentStatus = table.Column<int>(type: "int", nullable: false),
                    GCashReference = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    GCashNumber = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ShippingFullName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ShippingAddress = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ShippingPhone = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    PaidAt = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Orders", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Orders_Customers_CustomerId",
                        column: x => x.CustomerId,
                        principalTable: "Customers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "CartItems",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CustomerId = table.Column<int>(type: "int", nullable: false),
                    ProductId = table.Column<int>(type: "int", nullable: false),
                    Quantity = table.Column<int>(type: "int", nullable: false),
                    AddedAt = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CartItems", x => x.Id);
                    table.ForeignKey(
                        name: "FK_CartItems_Customers_CustomerId",
                        column: x => x.CustomerId,
                        principalTable: "Customers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_CartItems_Products_ProductId",
                        column: x => x.ProductId,
                        principalTable: "Products",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Reviews",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CustomerId = table.Column<int>(type: "int", nullable: false),
                    ProductId = table.Column<int>(type: "int", nullable: false),
                    OrderId = table.Column<int>(type: "int", nullable: false),
                    Rating = table.Column<int>(type: "int", nullable: false),
                    Comment = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Reviews", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Reviews_Customers_CustomerId",
                        column: x => x.CustomerId,
                        principalTable: "Customers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Reviews_Products_ProductId",
                        column: x => x.ProductId,
                        principalTable: "Products",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "WishListItems",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CustomerId = table.Column<int>(type: "int", nullable: false),
                    ProductId = table.Column<int>(type: "int", nullable: false),
                    AddedAt = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_WishListItems", x => x.Id);
                    table.ForeignKey(
                        name: "FK_WishListItems_Customers_CustomerId",
                        column: x => x.CustomerId,
                        principalTable: "Customers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_WishListItems_Products_ProductId",
                        column: x => x.ProductId,
                        principalTable: "Products",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "DeliveryTrackings",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    OrderId = table.Column<int>(type: "int", nullable: false),
                    Status = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    Location = table.Column<string>(type: "nvarchar(300)", maxLength: 300, nullable: true),
                    Notes = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TrackingTime = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DeliveryTrackings", x => x.Id);
                    table.ForeignKey(
                        name: "FK_DeliveryTrackings_Orders_OrderId",
                        column: x => x.OrderId,
                        principalTable: "Orders",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "OrderItems",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    OrderId = table.Column<int>(type: "int", nullable: false),
                    ProductId = table.Column<int>(type: "int", nullable: false),
                    Quantity = table.Column<int>(type: "int", nullable: false),
                    UnitPrice = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    ProductId1 = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_OrderItems", x => x.Id);
                    table.ForeignKey(
                        name: "FK_OrderItems_Orders_OrderId",
                        column: x => x.OrderId,
                        principalTable: "Orders",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_OrderItems_Products_ProductId",
                        column: x => x.ProductId,
                        principalTable: "Products",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_OrderItems_Products_ProductId1",
                        column: x => x.ProductId1,
                        principalTable: "Products",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "Receipts",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    OrderId = table.Column<int>(type: "int", nullable: false),
                    ReceiptNumber = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    IssuedAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    AmountPaid = table.Column<decimal>(type: "decimal(18,2)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Receipts", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Receipts_Orders_OrderId",
                        column: x => x.OrderId,
                        principalTable: "Orders",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "ReturnRequests",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    OrderId = table.Column<int>(type: "int", nullable: false),
                    CustomerId = table.Column<int>(type: "int", nullable: false),
                    Reason = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: false),
                    Status = table.Column<int>(type: "int", nullable: false),
                    RequestedAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ResolvedAt = table.Column<DateTime>(type: "datetime2", nullable: true),
                    AdminNote = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ReturnRequests", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ReturnRequests_Customers_CustomerId",
                        column: x => x.CustomerId,
                        principalTable: "Customers",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ReturnRequests_Orders_OrderId",
                        column: x => x.OrderId,
                        principalTable: "Orders",
                        principalColumn: "Id");
                });

            migrationBuilder.InsertData(
                table: "Admins",
                columns: new[] { "Id", "CreatedAt", "Email", "IsActive", "PasswordHash", "ProfilePicture", "ResetToken", "ResetTokenExpiry", "Username" },
                values: new object[] { 1, new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc), "admin@catrontech.ph", true, "$2a$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi", null, null, null, "admin" });

            migrationBuilder.InsertData(
                table: "Categories",
                columns: new[] { "Id", "Description", "IconClass", "ImageUrl", "IsActive", "Name" },
                values: new object[,]
                {
                    { 1, "Portable computing", "fas fa-laptop", null, true, "Laptops" },
                    { 2, "Desktop computers", "fas fa-desktop", null, true, "Desktops" },
                    { 3, "Office essentials", "fas fa-briefcase", null, true, "Office Supplies" },
                    { 4, "School essentials", "fas fa-book", null, true, "School Supplies" },
                    { 5, "Phones & tablets", "fas fa-mobile-alt", null, true, "Mobile Devices" },
                    { 6, "Software licenses", "fas fa-compact-disc", null, true, "Software" },
                    { 7, "PC components", "fas fa-microchip", null, true, "Hardware" },
                    { 8, "Printers & scanners", "fas fa-print", null, true, "Printers" }
                });

            migrationBuilder.InsertData(
                table: "Products",
                columns: new[] { "Id", "Brand", "CategoryId", "CreatedAt", "Description", "DiscountPrice", "ImageUrl", "IsActive", "Name", "Price", "Stock" },
                values: new object[,]
                {
                    { 1, "Dell", 1, new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc), "Powerful laptop with 11th Gen Intel Core processors, stunning display, and premium build quality.", null, "https://i.dell.com/is/image/DellContent/content/dam/ss2/product-images/dell-client-products/notebooks/xps-notebooks/xps-15-9530/media-gallery/touch-black/notebook-xps-15-9530-t-black-gallery-1.psd?fmt=png-alpha&pscan=auto&scl=1&hei=402&wid=654&qlt=100,1&resMode=sharp2&size=654,402&chrss=full", true, "Dell XPS 15 Laptop", 65999m, 45 },
                    { 2, "HP", 1, new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc), "Gaming laptop with NVIDIA GTX graphics, fast refresh display, and excellent cooling.", null, "https://m.media-amazon.com/images/I/61YT2eKwcbL._AC_SL1004_.jpg", true, "HP Pavilion Gaming Laptop", 52999m, 32 },
                    { 3, "Acer", 1, new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc), "A mid-range gaming laptop powered by Ryzen 5 and GTX graphics.", null, "https://m.media-amazon.com/images/I/71ctRE34RuL._AC_SL1500_.jpg", true, "Acer Nitro 5 Gaming Laptop", 42999m, 28 },
                    { 4, "Lenovo", 1, new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc), "Business laptop with robust security, professional design, and reliable performance.", null, "https://p1-ofp.static.pub//fes/cms/2024/03/04/b3npyptzskczdme2uxdo3e9f65zvqd800519.jpg", true, "Lenovo ThinkPad E14", 38999m, 50 },
                    { 5, "ASUS", 1, new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc), "Lightweight laptop perfect for students and professionals, with all-day battery life.", null, "https://pcx.com.ph/cdn/shop/files/LT-ASUS-VIVOBOOK-15-X1504VA-NJ1622WSM-I5-OFFICE-1_437cd931-856b-442b-b4cb-97f034a7e121.jpg", true, "ASUS VivoBook 15", 32999m, 65 },
                    { 6, "HP", 2, new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc), "Powerful desktop PC for business and creative work with expandable storage.", null, "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTkQxMACaBfiPJ0KtjghQzfVo3DesYYWfzM9A&s", true, "HP Desktop Elite Tower", 35999m, 38 },
                    { 7, "Dell", 2, new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc), "Reliable desktop computer for office work with energy-efficient components.", null, "https://down-ph.img.susercontent.com/file/ph-11134207-81ztm-mee0ucd5k1z612", true, "Dell OptiPlex Desktop", 32999m, 42 },
                    { 8, "Lenovo", 2, new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc), "Compact desktop with modern design, perfect for home and small office use.", null, "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSc3G--14y8J_m4BdHMX_BYLypUvu6OSsp2zQ&s", true, "Lenovo IdeaCentre Desktop", 28999m, 55 },
                    { 9, "ASUS", 2, new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc), "High-performance gaming desktop with RGB lighting and powerful graphics card.", null, "https://down-ph.img.susercontent.com/file/ph-11134207-7r98t-lpeiomr12e3ted_tn.webp", true, "ASUS Gaming Desktop", 55999m, 22 },
                    { 10, "Acer", 2, new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc), "Budget-friendly desktop computer for everyday computing tasks.", null, "https://down-ph.img.susercontent.com/file/ph-11134207-81ztj-mhmt2qer9q8451_tn.webp", true, "Acer Aspire Desktop", 25999m, 70 },
                    { 11, "Samsung", 5, new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc), "Latest flagship smartphone with advanced camera system and powerful performance.", null, "https://d1rlzxa98cyc61.cloudfront.net/catalog/product/1/8/186715_2_1.jpg?auto=webp&format=pjpg&width=640", true, "Samsung Galaxy S23", 45999m, 85 },
                    { 12, "Apple", 5, new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc), "Premium iPhone with Dynamic Island, Pro camera system, and A16 Bionic chip.", null, "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTm7JS13wDMiCD9C0el9ZDlfdBeeJjYuTPwAA&s", true, "iPhone 14 Pro", 62999m, 60 },
                    { 13, "Apple", 5, new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc), "Versatile tablet with M1 chip, perfect for creativity and productivity.", null, "https://cdsassets.apple.com/live/SZLF0YNV/images/sp/111887_sp866-ipad-air-5gen.png", true, "iPad Air 5th Gen", 35999m, 48 },
                    { 14, "Samsung", 5, new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc), "Android tablet with S Pen, great for note-taking and multimedia.", null, "https://down-ph.img.susercontent.com/file/ph-11134207-7r98t-lm49ngmnhu33e4", true, "Samsung Galaxy Tab S8", 32999m, 52 },
                    { 15, "OnePlus", 5, new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc), "Fast-charging smartphone with flagship specs at competitive price.", null, "https://down-ph.img.susercontent.com/file/cn-11134207-7ras8-m0dyi7kb1vf2b8", true, "OnePlus 11", 38999m, 42 },
                    { 16, "Mongol", 4, new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc), "Quality notebooks perfect for students, with ruled pages and durable covers.", null, "https://static.wixstatic.com/media/e57753_cafb1a4da53e4bacafde1f9bbc9796ad~mv2.jpg/v1/fit/w_500,h_500,q_90/file.jpg", true, "Notebook Set (5 Pack)", 299m, 200 },
                    { 17, "Pilot", 4, new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc), "High-quality ballpoint pens for smooth writing, available in multiple colors.", null, "https://cf.shopee.ph/file/ph-11134207-7r98p-lva2lp32b8yab7", true, "Pen Set Professional", 199m, 350 },
                    { 18, "Casio", 4, new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc), "Advanced calculator for mathematics and science students.", null, "https://cf.shopee.ph/file/ph-11134207-81zto-meqmwxcxlt6o80", true, "Casio Scientific Calculator", 899m, 120 },
                    { 19, "Herschel", 4, new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc), "Durable school backpack with multiple compartments and laptop sleeve.", null, "https://i.ebayimg.com/images/g/RFQAAOSwbn1ePvgc/s-l1200.jpg", true, "Herschel Backpacks", 1299m, 95 },
                    { 20, "Modanu", 4, new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc), "Complete art kit with pencils, markers, and drawing paper.", null, "https://i5.walmartimages.com/seo/MODANU-150-Pcs-Art-Supplies-Kids-Deluxe-Kids-Art-Set-Drawing-Painting-Portable-Art-Box-Coloring-Supplies-Art-Kits-Great-Gift-Kids-Toddlers-Beginners_11b13511-69e8-401d-95e7-fe79a5699ad0.0a957a8d6a6cb117afa5b05348dde4e7.jpeg", true, "Modanu Art Supplies Kit", 899m, 75 },
                    { 21, "Generic", 3, new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc), "Comfortable office chair with lumbar support and adjustable height.", null, "https://down-ph.img.susercontent.com/file/ph-11134207-7rasl-m794h3uglgt198", true, "Office Gaming Chair", 5999m, 45 },
                    { 22, "Generic", 3, new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc), "Keep your workspace tidy with this comprehensive organizer set.", null, "https://down-ph.img.susercontent.com/file/780b78eb597044a02af4f38bedcd0254", true, "Wooden Office Desk Organizers", 599m, 150 },
                    { 23, "HP", 3, new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc), "Fast and reliable laser printer for office use with wireless connectivity.", null, "https://elnstore.com/cdn/shop/files/c08340517.png?v=1749465631&width=493", true, "HP LaserJet Pro MFP 3103fdw", 8999m, 32 },
                    { 24, "Generic", 3, new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc), "Secure file storage cabinet with lock for important documents.", null, "https://down-ph.img.susercontent.com/file/ph-11134207-7r991-lloj6psow6mn4d", true, "File Cabinet 4-Drawer", 4999m, 28 },
                    { 25, "Generic", 3, new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc), "Large whiteboard for presentations and brainstorming sessions.", null, "https://smstationery.com.ph/cdn/shop/files/10090931-MAGNETICWHITEBOARDWPEN20X30ALUMINUMFRAME.jpg?v=1735806933", true, "Whiteboard Magnetic", 1299m, 60 },
                    { 26, "Microsoft", 6, new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc), "Complete productivity suite with Word, Excel, PowerPoint, and more.", null, "https://down-ph.img.susercontent.com/file/ph-11134275-7ra0r-mbs8xyq14r3v3d_tn.webp", true, "Microsoft Office 2021", 6999m, 500 },
                    { 27, "Adobe", 6, new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc), "Access to Photoshop, Illustrator, Premiere Pro and more. Monthly subscription.", null, "https://upload.wikimedia.org/wikipedia/commons/thumb/4/4c/Adobe_Creative_Cloud_rainbow_icon.svg/512px-Adobe_Creative_Cloud_rainbow_icon.svg.png", true, "Adobe Creative Cloud", 2999m, 999 },
                    { 28, "Microsoft", 6, new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc), "Latest Windows operating system with advanced features for professionals.", null, "https://down-id.img.susercontent.com/file/id-11134207-7rasl-m3rdu74g6amwaa", true, "Windows 11 Pro", 8999m, 300 },
                    { 29, "Norton", 6, new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc), "Comprehensive security suite to protect your devices from threats.", null, "https://cf.shopee.ph/file/sg-11134202-7rdwl-mcbk7c2itelz5c", true, "Antivirus Norton 360", 1499m, 450 },
                    { 30, "Autodesk", 6, new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc), "Professional CAD software for 2D and 3D design. Annual subscription.", null, "https://cf.shopee.ph/file/ph-11134207-81ztk-mhy8xzrn2j2da6", true, "AutoCAD 2024", 12999m, 200 },
                    { 31, "Intel", 7, new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc), "13th Gen Intel processor with 16 cores for gaming and content creation.", null, "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQj5WKK0gpAh8suNLv1r02YDvjDfADQGl2x5w&s", true, "Intel Core i7-13700K", 18999m, 55 },
                    { 32, "NVIDIA", 7, new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc), "High-performance graphics card for 4K gaming and ray tracing.", null, "https://down-ph.img.susercontent.com/file/ph-11134207-7rase-m7c48lpgewkrd4_tn.webp", true, "NVIDIA RTX 4070", 32999m, 32 },
                    { 33, "Corsair", 7, new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc), "High-speed DDR5 RAM with RGB lighting for gaming PCs.", null, "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTk4lDR8GhJjMzQMGJzlDuIwQgMkDwxBCHv-g&s", true, "Corsair Vengeance RGB 32GB", 5999m, 88 },
                    { 34, "Samsung", 7, new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc), "Ultra-fast NVMe SSD with PCIe 4.0 for lightning-quick load times.", null, "https://cf.shopee.ph/file/4cff930e948afe87f52012cd1569c5f9", true, "Samsung 980 PRO 2TB SSD", 8999m, 65 },
                    { 35, "ASUS", 7, new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc), "Premium AMD motherboard with WiFi 6E and PCIe 5.0 support.", null, "https://ecommerce.datablitz.com.ph/cdn/shop/files/g5s6dg45sdg.jpg?v=1760254901", true, "ASUS ROG Strix B650 Motherboard", 12999m, 42 },
                    { 36, "Canon", 8, new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc), "All-in-one wireless ink tank printer with high page yield for home and office.", null, "https://down-ph.img.susercontent.com/file/sg-11134201-23010-gzbwi62p80lv29", true, "Canon PIXMA G3020", 8999m, 45 },
                    { 37, "Epson", 8, new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc), "Ink tank printer with WiFi connectivity and low cost per page.", null, "https://down-ph.img.susercontent.com/file/ph-11134207-7rash-m9tnocfbnj8z6a", true, "Epson EcoTank L3250", 9999m, 38 },
                    { 38, "Brother", 8, new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc), "Compact 3-in-1 ink tank printer with automatic duplex printing.", null, "https://down-ph.img.susercontent.com/file/ph-11134207-7ra0t-mbov2l15ivla75", true, "Brother DCP-T720DW", 10999m, 32 },
                    { 39, "HP", 8, new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc), "All-in-one wireless printer with Smart app connectivity and high capacity tanks.", null, "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRzecVEs6pd77RNbCh9J_EYeJwx9uPp40P8eQ&s", true, "HP Smart Tank 585", 11999m, 28 },
                    { 40, "Canon", 8, new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc), "Monochrome laser multifunction printer for business with duplex scanning.", null, "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRveIAxLfAx5A_IhU3_BV9HqRZ8eKlQInA7Tg&s", true, "Canon imageCLASS MF445dw", 18999m, 25 },
                    { 41, "Epson", 8, new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc), "WiFi all-in-one ink tank printer with ADF and fax capability.", null, "https://down-ph.img.susercontent.com/file/ph-11134207-7r98q-lw54tsqn6vdt0a", true, "Epson L5290", 13999m, 35 },
                    { 42, "HP", 8, new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc), "Fast monochrome laser printer with network connectivity for offices.", null, "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS4eDQojLAsUxqhD0faZiiV_26OcbDnu5NgpA&s", true, "HP LaserJet Pro M404dn", 15999m, 22 },
                    { 43, "Brother", 8, new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc), "Compact wireless monochrome laser printer perfect for home offices.", null, "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT4h1vTmIdgz-xVWPWkeSkjJfeJyV46Tz93XQ&s", true, "Brother HL-L2375DW", 7999m, 48 },
                    { 44, "Canon", 8, new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc), "Wireless all-in-one inkjet printer with borderless photo printing.", null, "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR1gOPM80VMC4u_NvApTDluVo1JODsCzNQYEg&s", true, "Canon PIXMA TS5350a", 6999m, 55 },
                    { 45, "Epson", 8, new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc), "All-in-one color inkjet printer with ADF and WiFi Direct.", null, "https://i8.amplience.net/i/epsonemear/a17761-productpicture-hires-en-int-workforce_wf-2935dwf_02_attribute_rp_flex_2000x2000px", true, "Epson WorkForce WF-2935", 8999m, 40 }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Admins_Email",
                table: "Admins",
                column: "Email",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Admins_Username",
                table: "Admins",
                column: "Username",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_CartItems_CustomerId_ProductId",
                table: "CartItems",
                columns: new[] { "CustomerId", "ProductId" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_CartItems_ProductId",
                table: "CartItems",
                column: "ProductId");

            migrationBuilder.CreateIndex(
                name: "IX_CustomerAddresses_CustomerId",
                table: "CustomerAddresses",
                column: "CustomerId");

            migrationBuilder.CreateIndex(
                name: "IX_Customers_Email",
                table: "Customers",
                column: "Email",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_DeliveryTrackings_OrderId",
                table: "DeliveryTrackings",
                column: "OrderId");

            migrationBuilder.CreateIndex(
                name: "IX_OrderItems_OrderId",
                table: "OrderItems",
                column: "OrderId");

            migrationBuilder.CreateIndex(
                name: "IX_OrderItems_ProductId",
                table: "OrderItems",
                column: "ProductId");

            migrationBuilder.CreateIndex(
                name: "IX_OrderItems_ProductId1",
                table: "OrderItems",
                column: "ProductId1");

            migrationBuilder.CreateIndex(
                name: "IX_Orders_CustomerId",
                table: "Orders",
                column: "CustomerId");

            migrationBuilder.CreateIndex(
                name: "IX_Products_CategoryId",
                table: "Products",
                column: "CategoryId");

            migrationBuilder.CreateIndex(
                name: "IX_Receipts_OrderId",
                table: "Receipts",
                column: "OrderId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_ReturnRequests_CustomerId",
                table: "ReturnRequests",
                column: "CustomerId");

            migrationBuilder.CreateIndex(
                name: "IX_ReturnRequests_OrderId",
                table: "ReturnRequests",
                column: "OrderId");

            migrationBuilder.CreateIndex(
                name: "IX_Reviews_CustomerId",
                table: "Reviews",
                column: "CustomerId");

            migrationBuilder.CreateIndex(
                name: "IX_Reviews_ProductId",
                table: "Reviews",
                column: "ProductId");

            migrationBuilder.CreateIndex(
                name: "IX_WishListItems_CustomerId_ProductId",
                table: "WishListItems",
                columns: new[] { "CustomerId", "ProductId" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_WishListItems_ProductId",
                table: "WishListItems",
                column: "ProductId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Admins");

            migrationBuilder.DropTable(
                name: "CartItems");

            migrationBuilder.DropTable(
                name: "CustomerAddresses");

            migrationBuilder.DropTable(
                name: "DeliveryTrackings");

            migrationBuilder.DropTable(
                name: "OrderItems");

            migrationBuilder.DropTable(
                name: "Receipts");

            migrationBuilder.DropTable(
                name: "ReturnRequests");

            migrationBuilder.DropTable(
                name: "Reviews");

            migrationBuilder.DropTable(
                name: "WishListItems");

            migrationBuilder.DropTable(
                name: "Orders");

            migrationBuilder.DropTable(
                name: "Products");

            migrationBuilder.DropTable(
                name: "Customers");

            migrationBuilder.DropTable(
                name: "Categories");
        }
    }
}
