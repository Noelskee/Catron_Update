using Catron_Computer_Technology_PROEL4W_FINALS_.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Catron_Computer_Technology_PROEL4W_FINALS_.Controllers
{
    /// <summary>JSON API for admin header notifications (HotelEase-style).</summary>
    public class NotificationController : Controller
    {
        private readonly ApplicationDbContext _db;
        public NotificationController(ApplicationDbContext db) => _db = db;

        // Session stores AdminId as string (SetString), not SetInt32
        private bool IsAdmin() => !string.IsNullOrEmpty(HttpContext.Session.GetString("AdminId"));

        [HttpGet]
        public async Task<IActionResult> Recent(int take = 20)
        {
            if (!IsAdmin()) return Unauthorized();
            take = Math.Clamp(take, 1, 50);
            var items = await _db.AdminNotifications
                .AsNoTracking()
                .OrderByDescending(n => n.CreatedAt)
                .Take(take)
                .Select(n => new
                {
                    id = n.Id,
                    title = n.Title,
                    message = n.Message,
                    linkUrl = n.LinkUrl,
                    category = n.Category,
                    isRead = n.IsRead,
                    createdAt = n.CreatedAt
                })
                .ToListAsync();
            var unread = await _db.AdminNotifications.CountAsync(n => !n.IsRead);
            return Json(new { items, unread });
        }

        [HttpPost]
        [IgnoreAntiforgeryToken]
        public async Task<IActionResult> MarkRead([FromForm] int id)
        {
            if (!IsAdmin()) return Unauthorized();
            var n = await _db.AdminNotifications.FindAsync(id);
            if (n == null) return NotFound();
            n.IsRead = true;
            await _db.SaveChangesAsync();
            return Ok();
        }

        [HttpPost]
        [IgnoreAntiforgeryToken]
        public async Task<IActionResult> MarkAllRead()
        {
            if (!IsAdmin()) return Unauthorized();
            var list = await _db.AdminNotifications.Where(n => !n.IsRead).ToListAsync();
            foreach (var n in list) n.IsRead = true;
            await _db.SaveChangesAsync();
            return Ok();
        }
    }
}
