# Catron – Full Updated Project

## Included
- Catron logo (header, login, admin login, register)
- Clean login (no Google/Facebook)
- Sidebar: white + black text
- Compact Products table + inline action buttons
- Live search on all management pages
- Forgot password fixed (customer + admin) with visible reset link
- Notifications, roles, staff (no password fields)
- Program.cs db scope fixed
- Table gaps fixed

## Run
1. Extract ZIP
2. Open Catron.sln
3. F5
4. Ctrl+Shift+R in browser
