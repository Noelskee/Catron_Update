// ============================================================
//  AdminOrderService.cs – dashboard + order management
// ============================================================
using Catron_Computer_Technology_PROEL4W_FINALS_.Data;
using Catron_Computer_Technology_PROEL4W_FINALS_.Models;
using Catron_Computer_Technology_PROEL4W_FINALS_.Models.ViewModels;
using Microsoft.EntityFrameworkCore;

namespace Catron_Computer_Technology_PROEL4W_FINALS_.Services
{
    public class AdminOrderService : IAdminOrderService
    {
        private readonly ApplicationDbContext _db;

        public AdminOrderService(ApplicationDbContext db)
        {
            _db = db;
        }

        public async Task<AdminDashboardViewModel> GetDashboardAsync()
        {
            return new AdminDashboardViewModel
            {
                TotalCustomers = await _db.Customers.CountAsync(c => c.IsActive),
                TotalOrders = await _db.Orders.CountAsync(),
                TotalProducts = await _db.Products.CountAsync(p => p.IsActive),
                TotalRevenue = await _db.Orders
                    .Where(o => o.PaymentStatus == PaymentStatus.Paid)
                    .SumAsync(o => (decimal?)o.TotalAmount) ?? 0m,
                RecentOrders = await _db.Orders.AsNoTracking()
                    .Include(o => o.Customer).Include(o => o.OrderItems)
                    .OrderByDescending(o => o.CreatedAt).Take(10).ToListAsync(),
                LowStockProducts = await _db.Products.AsNoTracking()
                    .Where(p => p.Stock < 5 && p.IsActive).ToListAsync(),
                PendingReturns = await _db.ReturnRequests.AsNoTracking()
                    .Include(r => r.Customer).Include(r => r.Order)
                    .Where(r => r.Status == ReturnStatus.Pending).ToListAsync(),
                RecentCustomers = await _db.Customers.AsNoTracking()
                    .Include(c => c.Orders)
                    .OrderByDescending(c => c.CreatedAt).Take(8).ToListAsync()
            };
        }

        public async Task<List<Order>> GetOrdersAsync(string filter = "All")
        {
            var q = _db.Orders.AsNoTracking()
                .Include(o => o.Customer)
                .Include(o => o.OrderItems)
                .AsQueryable();

            if (!string.IsNullOrWhiteSpace(filter) && filter != "All"
                && Enum.TryParse<OrderStatus>(filter, true, out var status))
            {
                q = q.Where(o => o.Status == status);
            }

            return await q.OrderByDescending(o => o.CreatedAt).ToListAsync();
        }

        public async Task<Order?> GetOrderDetailAsync(int id)
        {
            return await _db.Orders
                .Include(o => o.Customer)
                .Include(o => o.OrderItems).ThenInclude(i => i.Product)
                .Include(o => o.Receipt)
                .Include(o => o.DeliveryTrackings)
                .FirstOrDefaultAsync(o => o.Id == id);
        }

        public async Task<bool> UpdateStatusAsync(int orderId, OrderStatus status)
        {
            var o = await _db.Orders.FindAsync(orderId);
            if (o == null) return false;
            o.Status = status;

            // COD: collect cash on delivery — mark Paid when order is Completed
            if (status == OrderStatus.Completed
                && o.PaymentMethod == PaymentMethod.Cash
                && o.PaymentStatus != PaymentStatus.Paid)
            {
                o.PaymentStatus = PaymentStatus.Paid;
                o.PaidAt = DateTime.UtcNow;
                if (!await _db.Receipts.AnyAsync(r => r.OrderId == o.Id))
                {
                    _db.Receipts.Add(new Receipt
                    {
                        OrderId = o.Id,
                        AmountPaid = o.TotalAmount
                    });
                }
            }

            await _db.SaveChangesAsync();
            return true;
        }
    }
}
