// ============================================================
//  InventoryMovement — one ledger row per stock change.
//  Used to make DeductSaleStock / Restore idempotent per OrderItem.
// ============================================================
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Catron_Computer_Technology_PROEL4W_FINALS_.Models
{
    public class InventoryMovement
    {
        public int Id { get; set; }

        public int ProductId { get; set; }

        /// <summary>Negative = stock out, positive = stock in.</summary>
        public int QuantityDelta { get; set; }

        public InventoryReason Reason { get; set; }

        /// <summary>Optional link to order (sale / cancel / return).</summary>
        public int? OrderId { get; set; }

        /// <summary>Optional link to order line — key for idempotency.</summary>
        public int? OrderItemId { get; set; }

        [StringLength(200)]
        public string? Note { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        public int? CreatedByAdminId { get; set; }

        public Product Product { get; set; } = null!;
        public Order? Order { get; set; }
        public OrderItem? OrderItem { get; set; }
    }
}
