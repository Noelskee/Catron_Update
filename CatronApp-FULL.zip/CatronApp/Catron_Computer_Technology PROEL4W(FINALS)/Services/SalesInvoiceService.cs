// ============================================================
//  SalesInvoiceService.cs – personal Sales Invoice for Catron
// ============================================================
using Catron_Computer_Technology_PROEL4W_FINALS_.Data;
using Catron_Computer_Technology_PROEL4W_FINALS_.Models;
using Microsoft.EntityFrameworkCore;

namespace Catron_Computer_Technology_PROEL4W_FINALS_.Services
{
    public class SalesInvoiceService : ISalesInvoiceService
    {
        private readonly ApplicationDbContext _db;

        public SalesInvoiceService(ApplicationDbContext db)
        {
            _db = db;
        }

        public string FormatInvoiceNumber(int orderId, DateTime issuedAt)
        {
            // Personal SI number: SI-YYYYMMDD-#### (order id padded)
            return $"SI-{issuedAt:yyyyMMdd}-{orderId:D4}";
        }

        public async Task<SalesInvoiceDocument?> GetOrCreateInvoiceAsync(int orderId)
        {
            var order = await _db.Orders
                .Include(o => o.Customer)
                .Include(o => o.OrderItems).ThenInclude(i => i.Product)
                .Include(o => o.Receipt)
                .FirstOrDefaultAsync(o => o.Id == orderId);

            if (order == null) return null;

            // Ensure a Receipt row exists (links SI to order)
            if (order.Receipt == null)
            {
                var receipt = new Receipt
                {
                    OrderId = order.Id,
                    AmountPaid = order.TotalAmount,
                    IssuedAt = DateTime.UtcNow,
                    ReceiptNumber = FormatInvoiceNumber(order.Id, DateTime.UtcNow)
                };
                _db.Receipts.Add(receipt);
                await _db.SaveChangesAsync();
                order.Receipt = receipt;
            }
            else if (string.IsNullOrWhiteSpace(order.Receipt.ReceiptNumber)
                     || !order.Receipt.ReceiptNumber.StartsWith("SI-", StringComparison.OrdinalIgnoreCase))
            {
                // Upgrade old hex receipt numbers to SI format for personal invoices
                order.Receipt.ReceiptNumber = FormatInvoiceNumber(order.Id, order.Receipt.IssuedAt);
                await _db.SaveChangesAsync();
            }

            var issued = order.Receipt.IssuedAt;
            var lines = order.OrderItems.Select((item, idx) => new SalesInvoiceLine
            {
                LineNo = idx + 1,
                Description = item.Product?.Name ?? $"Item #{item.ProductId}",
                Brand = item.Product?.Brand,
                Quantity = item.Quantity,
                UnitPrice = item.UnitPrice
            }).ToList();

            var subtotal = lines.Sum(l => l.Amount);

            return new SalesInvoiceDocument
            {
                InvoiceNumber = order.Receipt.ReceiptNumber,
                IssuedAt = issued,
                OrderNumber = order.OrderNumber,
                OrderId = order.Id,
                BuyerName = order.ShippingFullName,
                BuyerAddress = order.ShippingAddress,
                BuyerPhone = order.ShippingPhone,
                Lines = lines,
                Subtotal = subtotal,
                TotalAmount = order.TotalAmount,
                PaymentMethod = order.PaymentMethod.ToString(),
                PaymentStatus = order.PaymentStatus.ToString(),
                PaymentReference = order.GCashReference
            };
        }
    }
}
