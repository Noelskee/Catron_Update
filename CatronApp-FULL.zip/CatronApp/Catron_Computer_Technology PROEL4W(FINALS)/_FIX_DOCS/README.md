# Catron Computer Technology — Final Package

This zip contains **business-rule fixes** + **design polish** for the Catron e-commerce project.

## Contents

### Models (replace / merge)
- `Models/Enums.cs` — PaymentStatus includes **Unpaid**; InventoryReason added
- `Models/InventoryMovement.cs` — idempotent stock ledger

### Services (add new)
- `Services/OrderLifecycleService.cs` — authoritative payment, stock, status transitions

### Patches (apply to existing controllers)
- `PATCHES/CustomerController_PaymentStock.patch.cs`
- `PATCHES/AdminController_PaymentStatus.patch.cs`
- `PATCHES/ApplicationDbContext_Inventory.patch.cs`
- `PATCHES/Program_DI.cs`

### Views (replace)
- `Views/Shared/_Layout.cshtml` — customer header/nav/footer
- `Views/Shared/_AdminLayout.cshtml` — admin sidebar polish
- `Views/Customer/_AccountSidebar.cshtml` — **fixed** broken wishlist/vouchers nav
- `Views/Admin/UserManagement.cshtml` — improved staff UI

### CSS
- `wwwroot/css/site-improvements.css` — append or link after site.css
- `wwwroot/css/admin.css` — full admin styles (User Management included)

### Docs
- `docs/AUTHORITATIVE_RULES.md` — locked payment/stock/order matrix
- `docs/DESIGN_HOW_TO_APPLY.md`

### Preview
- `UserManagement_Design_Mockup.html` — open in browser

---

## Quick apply order

1. Copy `Models/Enums.cs`, `Models/InventoryMovement.cs`
2. Copy `Services/OrderLifecycleService.cs`
3. Register in Program.cs:  
   `builder.Services.AddScoped<IOrderLifecycleService, OrderLifecycleService>();`
4. Add DbSet + migration (see PATCHES/ApplicationDbContext_Inventory.patch.cs)
5. Apply controller patches (PlaceOrder, ConfirmPayment, VerifyPayment, UpdateOrderStatus, CancelOrder)
6. Replace the 4 Views listed above
7. Link or merge CSS

## Authoritative rules (short)

| Event | Payment | Order | Stock |
|-------|---------|-------|-------|
| GCash submit | Pending | ToPay | No |
| GCash approved | Paid | ToShip | Deduct once |
| GCash rejected | Failed | ToPay | No |
| COD confirmed | Unpaid | ToShip | Deduct once |
| COD cash collected | Paid | (unchanged) | No |
| Cancel after deduct | — | Cancelled | Restore once |
| Return approve | — | ReturnRefund | No |
| Return completed resalable | Refunded if Paid | Completed | Add |

**Never:** Customer GCash submit → Paid.  
**Never:** Deduct stock on every status change.
