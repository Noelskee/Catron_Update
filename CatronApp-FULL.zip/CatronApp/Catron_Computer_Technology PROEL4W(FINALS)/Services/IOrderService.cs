// ============================================================
//  IOrderService.cs – order lookups (HotelEase-style service)
// ============================================================
using Catron_Computer_Technology_PROEL4W_FINALS_.Models;

namespace Catron_Computer_Technology_PROEL4W_FINALS_.Services
{
    public interface IOrderService
    {
        Task<Order?> GetOrderForCustomerAsync(int orderId, int customerId);
        Task<List<Order>> GetCustomerOrdersAsync(int customerId);
    }
}
