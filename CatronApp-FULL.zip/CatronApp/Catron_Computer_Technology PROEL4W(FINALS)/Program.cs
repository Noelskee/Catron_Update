﻿using Microsoft.EntityFrameworkCore;
using Catron_Computer_Technology_PROEL4W_FINALS_.Data;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllersWithViews();
builder.Services.Configure<Catron_Computer_Technology_PROEL4W_FINALS_.Models.ChatbotSettings>(
    builder.Configuration.GetSection("Chatbot"));
builder.Services.AddHttpClient("Chatbot");
builder.Services.AddAntiforgery(o => o.HeaderName = "X-CSRF-TOKEN");

builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromHours(2);
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
    options.Cookie.Name = ".CatronSession";
});

builder.Services.AddHttpContextAccessor();

// Service layer (same pattern as HotelEase Services/)
builder.Services.AddScoped<Catron_Computer_Technology_PROEL4W_FINALS_.Services.IProductService,
    Catron_Computer_Technology_PROEL4W_FINALS_.Services.ProductService>();
builder.Services.AddScoped<Catron_Computer_Technology_PROEL4W_FINALS_.Services.ICartService,
    Catron_Computer_Technology_PROEL4W_FINALS_.Services.CartService>();
builder.Services.AddScoped<Catron_Computer_Technology_PROEL4W_FINALS_.Services.IOrderService,
    Catron_Computer_Technology_PROEL4W_FINALS_.Services.OrderService>();
builder.Services.AddScoped<Catron_Computer_Technology_PROEL4W_FINALS_.Services.IOrderLifecycleService,
    Catron_Computer_Technology_PROEL4W_FINALS_.Services.OrderLifecycleService>();
builder.Services.AddScoped<Catron_Computer_Technology_PROEL4W_FINALS_.Services.IAdminOrderService,
    Catron_Computer_Technology_PROEL4W_FINALS_.Services.AdminOrderService>();
builder.Services.AddScoped<Catron_Computer_Technology_PROEL4W_FINALS_.Services.ISalesInvoiceService,
    Catron_Computer_Technology_PROEL4W_FINALS_.Services.SalesInvoiceService>();

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Customer/Index");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseSession();
app.UseAuthorization();

// Admin area  →  /Admin/Login  (Login is shown first)
app.MapControllerRoute(
    name: "admin",
    pattern: "Admin/{action=Login}/{id?}",
    defaults: new { controller = "Admin" });

// Customer + everything else  →  /Customer/...
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Admin}/{action=Login}/{id?}");


// ── Database initialisation ──────────────────────────────────────────────────
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
    var logger = scope.ServiceProvider.GetService<ILoggerFactory>()?.CreateLogger("DbInit");

    // Apply EF migrations. If migrate fails (e.g. empty DB / history mismatch),
    // fall back to EnsureCreated so tables like Admins always exist.
    try
    {
        db.Database.Migrate();
        logger?.LogInformation("Database migrations applied successfully.");
    }
    catch (Exception ex)
    {
        logger?.LogWarning(ex, "Migrate() failed — trying EnsureCreated fallback.");
        try
        {
            db.Database.EnsureCreated();
            logger?.LogInformation("EnsureCreated completed.");
        }
        catch (Exception ex2)
        {
            logger?.LogError(ex2, "EnsureCreated also failed. Check SQL Server / LocalDB and connection string.");
            throw; // fail fast so the error is visible
        }
    }

    try
    {
        db.Database.ExecuteSqlRaw(@"
IF COL_LENGTH('CartItems','SelectedOptions') IS NULL
    ALTER TABLE CartItems ADD SelectedOptions nvarchar(500) NULL;
IF COL_LENGTH('OrderItems','SelectedOptions') IS NULL
    ALTER TABLE OrderItems ADD SelectedOptions nvarchar(500) NULL;");
    }
    catch { }

    try
    {
        db.Database.ExecuteSqlRaw(@"
IF OBJECT_ID(N'[dbo].[AdminNotifications]', N'U') IS NULL
BEGIN
    CREATE TABLE [AdminNotifications] (
        [Id] INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
        [Title] NVARCHAR(200) NOT NULL,
        [Message] NVARCHAR(500) NULL,
        [LinkUrl] NVARCHAR(300) NULL,
        [Category] NVARCHAR(40) NOT NULL DEFAULT 'system',
        [IsRead] BIT NOT NULL DEFAULT 0,
        [CreatedAt] DATETIME2 NOT NULL
    );
END");
    }
    catch { }

    try
    {
        db.Database.ExecuteSqlRaw(@"
IF OBJECT_ID(N'[dbo].[Vouchers]', N'U') IS NULL
BEGIN
    CREATE TABLE [Vouchers] (
        [Id] INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
        [Code] NVARCHAR(40) NOT NULL,
        [Title] NVARCHAR(120) NOT NULL,
        [Description] NVARCHAR(300) NULL,
        [DiscountType] INT NOT NULL DEFAULT 0,
        [DiscountValue] DECIMAL(18,2) NOT NULL,
        [MinSpend] DECIMAL(18,2) NOT NULL DEFAULT 0,
        [MaxUses] INT NULL,
        [UsedCount] INT NOT NULL DEFAULT 0,
        [ExpiresAt] DATETIME2 NULL,
        [IsActive] BIT NOT NULL DEFAULT 1,
        [CreatedAt] DATETIME2 NOT NULL
    );
    CREATE UNIQUE INDEX IX_Vouchers_Code ON [Vouchers]([Code]);
END
IF OBJECT_ID(N'[dbo].[CustomerVouchers]', N'U') IS NULL
BEGIN
    CREATE TABLE [CustomerVouchers] (
        [Id] INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
        [CustomerId] INT NOT NULL,
        [VoucherId] INT NOT NULL,
        [CollectedAt] DATETIME2 NOT NULL,
        [UsedAt] DATETIME2 NULL,
        [UsedOnOrderId] INT NULL
    );
    CREATE UNIQUE INDEX IX_CustomerVouchers_Cust_Vouch ON [CustomerVouchers]([CustomerId],[VoucherId]);
END
IF COL_LENGTH('Orders','DiscountAmount') IS NULL
    ALTER TABLE Orders ADD DiscountAmount DECIMAL(18,2) NOT NULL CONSTRAINT DF_Orders_DiscountAmount DEFAULT 0;
IF COL_LENGTH('Orders','VoucherCode') IS NULL
    ALTER TABLE Orders ADD VoucherCode NVARCHAR(40) NULL;
IF COL_LENGTH('Admins','Role') IS NULL
    ALTER TABLE Admins ADD [Role] INT NOT NULL CONSTRAINT DF_Admins_Role DEFAULT 0;");
    }
    catch { }


    try
    {
        db.Database.ExecuteSqlRaw(@"
IF OBJECT_ID(N'[dbo].[InventoryMovements]', N'U') IS NULL
BEGIN
    CREATE TABLE [InventoryMovements] (
        [Id] INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
        [ProductId] INT NOT NULL,
        [QuantityDelta] INT NOT NULL,
        [Reason] INT NOT NULL,
        [OrderId] INT NULL,
        [OrderItemId] INT NULL,
        [Note] NVARCHAR(200) NULL,
        [CreatedAt] DATETIME2 NOT NULL,
        [CreatedByAdminId] INT NULL
    );
    CREATE INDEX IX_InventoryMovements_OrderItem_Reason ON [InventoryMovements]([OrderItemId], [Reason]);
END");
    }
    catch { }

    // Ensure default admin: admin / Admin@123
    try
    {
        var admin = db.Admins.FirstOrDefault(a => a.Username == "admin");
        var hash = Catron_Computer_Technology_PROEL4W_FINALS_.Helpers.AdminPasswordHasher.Hash("Admin@123");
        if (admin == null)
        {
            db.Admins.Add(new Catron_Computer_Technology_PROEL4W_FINALS_.Models.Admin
            {
                Username = "admin",
                Email = "admin@catrontech.ph",
                PasswordHash = hash,
                IsActive = true,
                CreatedAt = DateTime.UtcNow,
                Role = Catron_Computer_Technology_PROEL4W_FINALS_.Models.AdminRole.Admin
            });
            db.SaveChanges();
            logger?.LogInformation("Default admin seeded (admin / Admin@123).");
        }
        else if (!Catron_Computer_Technology_PROEL4W_FINALS_.Helpers.AdminPasswordHasher.Verify("Admin@123", admin.PasswordHash)
                 || !admin.IsActive)
        {
            admin.PasswordHash = hash;
            admin.IsActive = true;
            db.SaveChanges();
        }
    }
    catch (Exception seedEx)
    {
        logger?.LogError(seedEx, "Admin seed failed. Run Drop-Database then Update-Database in PMC.");
    }

    try
    {
        db.Database.ExecuteSqlRaw(@"
IF COL_LENGTH('Customers', 'AuthProvider') IS NULL
    ALTER TABLE [Customers] ADD [AuthProvider] NVARCHAR(20) NOT NULL CONSTRAINT DF_Customers_AuthProvider DEFAULT 'local';
IF COL_LENGTH('Customers', 'GoogleId') IS NULL
    ALTER TABLE [Customers] ADD [GoogleId] NVARCHAR(100) NULL;
IF COL_LENGTH('Customers', 'FacebookId') IS NULL
    ALTER TABLE [Customers] ADD [FacebookId] NVARCHAR(100) NULL;
");
    }
    catch { }
}
app.Run();
