# Catron — Authoritative Payment, Stock & Order Rules

**Do not reinterpret these rules.**

## Payment

### GCash
```
Customer submits reference
→ PaymentStatus = Pending
→ OrderStatus = ToPay
→ NO stock deduction

Admin approves (Back Office → Payments)
→ PaymentStatus = Paid
→ OrderStatus = ToShip
→ Stock deducted ONCE (InventoryMovement Reason=Sale)

Admin rejects
→ PaymentStatus = Failed (UI: Rejected)
→ OrderStatus = ToPay
→ NO stock change
```

**Never:** Customer submit → Paid.

### COD (PaymentMethod.Cash)
```
Customer confirms COD
→ PaymentStatus = Unpaid
→ OrderStatus = ToShip
→ Stock deducted ONCE

Cash collected (e.g. mark Delivered / ToReview or MarkCodPaid)
→ PaymentStatus = Paid
```

**Never:** COD created → Paid.

## Stock

| Event | Stock |
|-------|-------|
| Add to cart | No change |
| GCash submit | No change |
| GCash verified | Deduct once |
| COD confirmed | Deduct once |
| Ship / Deliver / Complete | No change |
| Cancel before deduct | No change |
| Cancel after deduct | Restore once |
| Return request / approve | No change |
| Return completed resalable | Add stock |
| Return completed damaged | No add |

Idempotency: `InventoryMovement` per `OrderItemId` + `Reason`. Second call is a no-op.

## Order transitions (allowed)

```
ToPay → ToShip | Cancelled
ToShip → ToReceive | Cancelled
ToReceive → ToReview
ToReview → Completed | ReturnRefund
Completed → ReturnRefund
ReturnRefund → Completed
Cancelled → (none)
```

GCash ToPay→ToShip only via **VerifyPayment**, not free dropdown.

## Returns / Refunds

- Request only from **ToReview** or **Completed** (after delivery).
- Approve ≠ refund complete; Approve ≠ stock restore.
- Complete return + inspection → stock decision + Refunded if was Paid.

## Matrix (summary)

| Situation | Payment | Order | Stock |
|-----------|---------|-------|-------|
| Cart | — | — | No |
| GCash submitted | Pending | ToPay | No |
| GCash rejected | Failed | ToPay | No |
| GCash verified | Paid | ToShip | Deduct |
| COD confirmed | Unpaid | ToShip | Deduct |
| Shipped | Paid/Unpaid | ToReceive | No |
| Delivered | Paid (COD may collect) | ToReview | No |
| Cancel pre-deduct | — | Cancelled | No |
| Cancel post-deduct | — | Cancelled | Restore |
| Return completed resalable | Refunded if was Paid | Completed | Add |

## Implementation files in this package

- `Models/Enums.cs` — Unpaid + InventoryReason
- `Models/InventoryMovement.cs`
- `Services/OrderLifecycleService.cs` — single source of truth
- `PATCHES/*` — controller method replacements
- Account sidebar fix (from design package) for H5
