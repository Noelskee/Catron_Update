// ============================================================
//  Enums.cs — AUTHORITATIVE business meanings (do not reinterpret)
// ============================================================
namespace Catron_Computer_Technology_PROEL4W_FINALS_.Models
{
    /// <summary>
    /// Order lifecycle. Transitions are restricted (see OrderLifecycleService).
    /// </summary>
    public enum OrderStatus
    {
        ToPay,          // Awaiting payment verification (GCash) or not yet confirmed
        ToShip,         // Confirmed for fulfillment (stock deducted)
        ToReceive,      // Shipped / in transit
        ToReview,       // Delivered; customer may review
        Completed,      // Fully done
        ReturnRefund,   // Return request in progress
        Cancelled       // Cancelled
    }

    public enum PaymentMethod
    {
        Cash,           // COD — treat as Cash on Delivery in UI
        DebitCard,
        CreditCard,
        GCash
    }

    /// <summary>
    /// Payment meanings (strict):
    /// Pending  = info submitted, not verified (GCash)
    /// Paid     = money confirmed/collected
    /// Failed   = rejected (use as Rejected in UI)
    /// Unpaid   = COD / not yet collected
    /// Refunded = money returned
    /// </summary>
    public enum PaymentStatus
    {
        Pending,
        Paid,
        Failed,     // Rejected
        Unpaid,     // COD before collection
        Refunded
    }

    public enum ReturnStatus
    {
        Pending,
        Approved,
        Rejected,
        Completed
    }

    /// <summary>Idempotent inventory ledger reason codes.</summary>
    public enum InventoryReason
    {
        Sale,               // Stock out for confirmed order
        CancelRestore,      // Stock back after cancel post-deduction
        ReturnResalable,    // Stock in after physical return + inspection
        Damaged,            // Physical return not resalable
        AdjustmentIn,
        AdjustmentOut,
        Correction
    }
}
