using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Catron_Computer_Technology_PROEL4W_FINALS_.Models
{
    public enum VoucherDiscountType
    {
        Percent = 0,
        Fixed = 1
    }

    /// <summary>Admin-created promo voucher (Shopee-style collectible discount).</summary>
    public class Voucher
    {
        public int Id { get; set; }

        [Required, StringLength(40)]
        public string Code { get; set; } = "";

        [Required, StringLength(120)]
        public string Title { get; set; } = "";

        [StringLength(300)]
        public string? Description { get; set; }

        public VoucherDiscountType DiscountType { get; set; } = VoucherDiscountType.Percent;

        /// <summary>Percent 1–100 or fixed PHP amount.</summary>
        [Column(TypeName = "decimal(18,2)")]
        public decimal DiscountValue { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal MinSpend { get; set; }

        public int? MaxUses { get; set; }
        public int UsedCount { get; set; }

        public DateTime? ExpiresAt { get; set; }
        public bool IsActive { get; set; } = true;
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        public ICollection<CustomerVoucher> CustomerVouchers { get; set; } = new List<CustomerVoucher>();
    }

    public class CustomerVoucher
    {
        public int Id { get; set; }
        public int CustomerId { get; set; }
        public int VoucherId { get; set; }
        public DateTime CollectedAt { get; set; } = DateTime.UtcNow;
        public DateTime? UsedAt { get; set; }
        public int? UsedOnOrderId { get; set; }

        public Customer? Customer { get; set; }
        public Voucher? Voucher { get; set; }
    }
}
