// ============================================================
//  ProductService.cs – catalog queries (HotelEase-style service)
// ============================================================
using Catron_Computer_Technology_PROEL4W_FINALS_.Data;
using Catron_Computer_Technology_PROEL4W_FINALS_.Models;
using Catron_Computer_Technology_PROEL4W_FINALS_.Models.ViewModels;
using Microsoft.EntityFrameworkCore;

namespace Catron_Computer_Technology_PROEL4W_FINALS_.Services
{
    public class ProductService : IProductService
    {
        private readonly ApplicationDbContext _db;

        public ProductService(ApplicationDbContext db)
        {
            _db = db;
        }

        public async Task<HomeViewModel> GetHomeAsync()
        {
            return new HomeViewModel
            {
                FeaturedProducts = await _db.Products.AsNoTracking()
                    .Include(p => p.Category)
                    .Where(p => p.IsActive)
                    .OrderByDescending(p => p.CreatedAt)
                    .Take(8)
                    .ToListAsync(),
                Categories = await _db.Categories.AsNoTracking()
                    .Where(c => c.IsActive)
                    .ToListAsync()
            };
        }

        public async Task<ProductListViewModel> GetProductsAsync(int? categoryId, string? search, int page = 1, int pageSize = 12)
        {
            if (page < 1) page = 1;

            var q = _db.Products.AsNoTracking()
                .Include(p => p.Category)
                .Where(p => p.IsActive);

            if (categoryId.HasValue)
                q = q.Where(p => p.CategoryId == categoryId);

            if (!string.IsNullOrWhiteSpace(search))
                q = q.Where(p =>
                    p.Name.Contains(search) ||
                    (p.Description != null && p.Description.Contains(search)) ||
                    (p.Brand != null && p.Brand.Contains(search)));

            int total = await q.CountAsync();

            var products = await q.OrderBy(p => p.Name)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            // Attach sold units for card display
            if (products.Count > 0)
            {
                var ids = products.Select(x => x.Id).ToList();
                var soldMap = await _db.Set<OrderItem>()
                    .Where(oi => ids.Contains(oi.ProductId))
                    .GroupBy(oi => oi.ProductId)
                    .Select(g => new { ProductId = g.Key, Qty = g.Sum(x => x.Quantity) })
                    .ToDictionaryAsync(x => x.ProductId, x => x.Qty);
                foreach (var p in products)
                    p.SoldCount = soldMap.TryGetValue(p.Id, out var s) ? s : 0;
            }

            return new ProductListViewModel
            {
                Products = products,
                Categories = await GetActiveCategoriesAsync(),
                SelectedCategoryId = categoryId,
                SearchQuery = search,
                CurrentPage = page,
                TotalPages = Math.Max(1, (int)Math.Ceiling(total / (double)pageSize)),
                TotalItems = total
            };
        }

        public async Task<Product?> GetByIdAsync(int id, bool activeOnly = true)
        {
            var q = _db.Products.Include(p => p.Category).AsQueryable();
            if (activeOnly)
                q = q.Where(p => p.IsActive);
            return await q.FirstOrDefaultAsync(p => p.Id == id);
        }

        public async Task<List<Product>> GetRelatedAsync(int productId, int categoryId, int take = 4)
        {
            return await _db.Products.AsNoTracking()
                .Include(p => p.Category)
                .Where(p => p.IsActive && p.CategoryId == categoryId && p.Id != productId)
                .OrderByDescending(p => p.CreatedAt)
                .Take(take)
                .ToListAsync();
        }

        public async Task<List<Category>> GetActiveCategoriesAsync()
        {
            return await _db.Categories.AsNoTracking()
                .Where(c => c.IsActive)
                .OrderBy(c => c.Name)
                .ToListAsync();
        }
    }
}
