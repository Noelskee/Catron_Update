﻿// ============================================================
//  AdminController.cs
//  Namespace: Catron_Computer_Technology_PROEL4W_FINALS_.Controllers
//
//  Purpose:
//    Handles ALL admin-panel pages. The first page shown is the
//    login screen (/Admin/Login).
//
//  Views live in:  Views/Admin/
//    Auth            : Login, Register, ForgotPassword, ResetPassword
//    Core            : Dashboard
//    Orders          : Orders, OrderDetail
//    Products        : Products, ProductForm
//    Customers       : Customers, CustomerDetail
//    Returns         : Returns
//    Categories      : Categories, CategoryForm        ← NEW
//    User Management : UserManagement, UserForm        ← NEW
//
//  Session keys used:
//    "AdminId"       – int   : ID of the logged-in admin
//    "AdminUsername" – string: username of the logged-in admin
//
//  Auth guard:
//    Every action that requires login calls IsAdmin.
//    If false it redirects to Login via Guard().
// ============================================================

using Catron_Computer_Technology_PROEL4W_FINALS_.Data;
using Catron_Computer_Technology_PROEL4W_FINALS_.Helpers;
using Catron_Computer_Technology_PROEL4W_FINALS_.Models;
using Catron_Computer_Technology_PROEL4W_FINALS_.Models.ViewModels;
using Catron_Computer_Technology_PROEL4W_FINALS_.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Catron_Computer_Technology_PROEL4W_FINALS_.Controllers
{
    public class AdminController : Controller
    {
        // ── Injected database context (registered in Program.cs) ─────────
        private readonly IOrderLifecycleService _lifecycle;
        private readonly ApplicationDbContext _db;
        private readonly IWebHostEnvironment _env;
        private readonly IAdminOrderService _adminOrders;
        private readonly ISalesInvoiceService _invoices;

        /// <summary>Constructor – DbContext + back-office services (HotelEase-style Services folder).</summary>
        public AdminController(IOrderLifecycleService lifecycle, 
            ApplicationDbContext db,
            IWebHostEnvironment env,
            IAdminOrderService adminOrders,
            ISalesInvoiceService invoices)
        {
            _lifecycle = lifecycle;
            _db = db;
            _env = env;
            _adminOrders = adminOrders;
            _invoices = invoices;
        }

        // ── Helper: save an uploaded image to wwwroot/uploads/<folder> ──
        private async Task<string?> SaveUploadAsync(IFormFile? file, string folder, string? oldPath = null)
        {
            if (file == null || file.Length == 0) return null;
            var ext = Path.GetExtension(file.FileName).ToLower();
            var allowed = new[] { ".jpg", ".jpeg", ".png", ".gif", ".webp" };
            if (!allowed.Contains(ext)) return null;
            var dir = Path.Combine(_env.WebRootPath, "uploads", folder);
            Directory.CreateDirectory(dir);
            var fileName = Guid.NewGuid().ToString("N") + ext;
            var fullPath = Path.Combine(dir, fileName);
            using var stream = new FileStream(fullPath, FileMode.Create);
            await file.CopyToAsync(stream);
            // Delete old file if replacing
            if (!string.IsNullOrEmpty(oldPath))
            {
                var oldFull = Path.Combine(_env.WebRootPath, oldPath.TrimStart('/'));
                if (System.IO.File.Exists(oldFull)) System.IO.File.Delete(oldFull);
            }
            return "/uploads/" + folder + "/" + fileName;
        }

        // ── Session-based authentication helpers ─────────────────────────

        /// <summary>
        /// True when an admin is logged in (session contains "AdminId").
        /// Used as a quick guard check at the top of every protected action.
        /// </summary>

        private bool IsAdmin => HttpContext.Session.GetString("AdminId") != null;

        private IActionResult Guard() => RedirectToAction("Login");

        /// <summary>Current staff role from session (defaults to Admin if missing).</summary>
        private AdminRole CurrentRole
        {
            get
            {
                var s = HttpContext.Session.GetString("AdminRole");
                if (Enum.TryParse<AdminRole>(s, out var r)) return r;
                return AdminRole.Admin;
            }
        }

        /// <summary>
        /// Role permissions:
        /// Admin — full access
        /// Sales — Dashboard, Orders, Deliveries, Payments, Customers, SalesInvoice
        /// Inventory — Dashboard, Products, Inventory, Categories, Vouchers
        /// Support — Dashboard, Returns, Reviews, Customers
        /// Delivery — Dashboard, Deliveries, Orders (view)
        /// </summary>
        private bool RoleCan(params string[] areas)
        {
            if (CurrentRole == AdminRole.Admin) return true;
            var set = new HashSet<string>(areas, StringComparer.OrdinalIgnoreCase);
            return CurrentRole switch
            {
                AdminRole.Sales => set.Overlaps(new[] { "Dashboard", "Orders", "Deliveries", "Payments", "Customers", "SalesInvoice", "Profile" }),
                // Staff management is Admin-only
                AdminRole.Inventory => set.Overlaps(new[] { "Dashboard", "Products", "Inventory", "Categories", "Vouchers", "Profile" }),
                AdminRole.Support => set.Overlaps(new[] { "Dashboard", "Returns", "Reviews", "Customers", "Profile" }),
                AdminRole.Delivery => set.Overlaps(new[] { "Dashboard", "Deliveries", "Orders", "Profile" }),
                _ => false
            };
        }

        private IActionResult DenyRole()
        {
            TempData["Error"] = "You do not have permission to access that page.";
            return RedirectToAction("Dashboard");
        }

        // ══════════════════════════════════════════════════════════════
        //  AUTH – LOGIN
        //  Default action: the first page shown when visiting /Admin/
        // ══════════════════════════════════════════════════════════════

        /// <summary>
        /// GET /Admin/Login
        /// Shows the login form. Redirects to Dashboard if already logged in.
        /// </summary>
        [HttpGet]
        public IActionResult Login()
        {
            if (IsAdmin) return RedirectToAction("Dashboard");
            return View();
        }

        /// <summary>
        /// POST /Admin/Login
        /// Validates credentials, sets session keys, and redirects to Dashboard.
        /// On failure, redisplays the form with a generic error message.
        /// </summary>
        [HttpPost]
        public async Task<IActionResult> Login(AdminLoginViewModel model)
        {
            // Server-side model validation (Required fields, etc.)
            if (!ModelState.IsValid) return View(model);

            // Look up the admin by username
            var user = (model.Username ?? "").Trim();
            var admin = await _db.Admins.FirstOrDefaultAsync(a =>
                a.IsActive && a.Username.ToLower() == user.ToLower());

            // Verify password – use the dedicated AdminPasswordHasher (work factor 13)
            if (admin == null || !AdminPasswordHasher.Verify(model.Password, admin.PasswordHash))
            {
                // Generic message to avoid leaking whether the username or password is wrong
                ModelState.AddModelError("", "Invalid username or password.");
                return View(model);
            }

            // Store admin identity in session
            HttpContext.Session.SetString("AdminId", admin.Id.ToString());
            HttpContext.Session.SetString("AdminUsername", admin.Username);
            HttpContext.Session.SetString("AdminProfilePic", admin.ProfilePicture ?? "");
            HttpContext.Session.SetString("AdminRole", admin.Role.ToString());
            HttpContext.Session.SetString("AdminEmail", admin.Email ?? "");

            return RedirectToAction("Dashboard");
        }

        // ══════════════════════════════════════════════════════════════
        //  AUTH – REGISTER
        //  Creates a new admin account. Accessible without login so the
        //  first admin can be set up, but in production this should be
        //  protected (e.g. require an invitation code).
        // ══════════════════════════════════════════════════════════════

        /// <summary>GET /Admin/Register – shows the registration form.</summary>
        [HttpGet] public IActionResult Register() => RedirectToAction("Login"); // Registration disabled — use User Management

        /// <summary>
        /// POST /Admin/Register
        /// Validates the form, checks for duplicate username/email,
        /// creates the admin account with a BCrypt-hashed password.
        /// </summary>
        [HttpPost]
        public async Task<IActionResult> Register(AdminRegisterViewModel model)
        {
            return RedirectToAction("Login"); // Registration disabled — use User Management
        }

        // ══════════════════════════════════════════════════════════════
        //  AUTH – FORGOT / RESET PASSWORD
        //  Generates a reset token and (TODO) emails it to the admin.
        // ══════════════════════════════════════════════════════════════

        /// <summary>GET /Admin/ForgotPassword – shows the email-input form.</summary>
        [HttpGet] public IActionResult ForgotPassword() => View();

        /// <summary>
        /// POST /Admin/ForgotPassword
        /// Stores a reset token on the admin record if the email is found.
        /// The response is the same whether the email exists or not
        /// (prevents user enumeration attacks).
        /// </summary>
        [HttpPost]
        public async Task<IActionResult> ForgotPassword(ForgotPasswordViewModel model)
        {
            if (!ModelState.IsValid) return View(model);

            var emailNorm = (model.Email ?? "").Trim().ToLowerInvariant();
            var a = await _db.Admins.FirstOrDefaultAsync(x => x.Email.ToLower() == emailNorm);
            if (a != null)
            {
                a.ResetToken = AdminPasswordHasher.GenerateResetToken();
                a.ResetTokenExpiry = DateTime.UtcNow.AddHours(1);
                await _db.SaveChangesAsync();

                var baseUrl = $"{Request.Scheme}://{Request.Host}";
                var resetLink = $"{baseUrl}/Admin/ResetPassword?token={Uri.EscapeDataString(a.ResetToken)}&email={Uri.EscapeDataString(a.Email)}";

                // Notify all Admin-role staff in the bell
                _db.AdminNotifications.Add(new AdminNotification
                {
                    Title = "Password reset requested",
                    Message = $"Reset requested for {a.Username} ({a.Email}). Link valid 1 hour.",
                    LinkUrl = "/Admin/UserManagement",
                    Category = "security",
                    CreatedAt = DateTime.UtcNow
                });
                await _db.SaveChangesAsync();

                await EmailHelper.SendAdminPasswordResetAsync(
                    a.Email, a.Username, resetLink, HttpContext.RequestServices);

                TempData["Success"] = "Password reset link is ready. Use the link below (also emailed if SMTP is configured).";
                TempData["ResetLink"] = resetLink;
                return View(model);
            }

            TempData["Info"] = "If that email is registered, a reset link has been prepared.";
            return View(model);
        }

        /// <summary>
        /// GET /Admin/ResetPassword?token=...&email=...
        /// Builds and shows the new-password form with token and email pre-filled.
        /// </summary>
        [HttpGet]
        public IActionResult ResetPassword(string token, string email) =>
            View(new ResetPasswordViewModel { Token = token, Email = email });

        /// <summary>
        /// POST /Admin/ResetPassword
        /// Validates the token, updates the password hash, and invalidates the token.
        /// </summary>
        [HttpPost]
        public async Task<IActionResult> ResetPassword(ResetPasswordViewModel model)
        {
            if (!ModelState.IsValid) return View(model);

            // Find the admin whose token matches and has not expired
            var a = await _db.Admins.FirstOrDefaultAsync(x =>
                x.Email == model.Email &&
                x.ResetToken == model.Token &&
                x.ResetTokenExpiry > DateTime.UtcNow);

            if (a == null)
            {
                ModelState.AddModelError("", "Invalid or expired reset link.");
                return View(model);
            }

            // Apply the new password and clear the reset token
            a.PasswordHash = AdminPasswordHasher.Hash(model.NewPassword);
            a.ResetToken = null;
            a.ResetTokenExpiry = null;
            await _db.SaveChangesAsync();

            TempData["Success"] = "Password has been reset. Please log in.";
            return RedirectToAction("Login");
        }

        // ══════════════════════════════════════════════════════════════
        //  AUTH – LOGOUT
        // ══════════════════════════════════════════════════════════════

        /// <summary>
        /// GET /Admin/Logout
        /// Clears the admin session keys and redirects to the Login page.
        /// </summary>
        public IActionResult Logout()
        {
            HttpContext.Session.Remove("AdminId");
            HttpContext.Session.Remove("AdminUsername");
            return RedirectToAction("Login");
        }

        // ══════════════════════════════════════════════════════════════
        //  DASHBOARD
        //  Shows KPI summary cards and recent activity tables.
        // ══════════════════════════════════════════════════════════════

        /// <summary>
        /// GET /Admin/Dashboard
        /// Aggregates stats (customers, orders, revenue, low stock) and
        /// passes them to the AdminDashboardViewModel for the view.
        /// </summary>
        public async Task<IActionResult> Dashboard()
        {
            if (!IsAdmin) return Guard();
            // Stats + recent lists live in Services/AdminOrderService
            var vm = await _adminOrders.GetDashboardAsync();
            return View(vm);
        }

        // ══════════════════════════════════════════════════════════════
        //  ORDERS
        //  List view with status filter tabs + detail view with
        //  status updates and delivery tracking.
        // ══════════════════════════════════════════════════════════════

        /// <summary>
        /// GET /Admin/Orders?filter=All|ToPay|ToShip|ToReceive|Completed|Cancelled
        /// Returns a filtered list of orders ordered by most recent first.
        /// ViewBag.Filter is passed to the view to highlight the active tab.
        /// </summary>
        public async Task<IActionResult> Orders(string filter = "All", string? q = null)
        {
            if (!IsAdmin) return Guard();
            if (!RoleCan("Orders")) return DenyRole();
            ViewBag.Filter = filter;
            ViewBag.Search = q;
            var list = await _adminOrders.GetOrdersAsync(filter);
            if (!string.IsNullOrWhiteSpace(q))
            {
                var term = q.Trim().ToLowerInvariant();
                // If q looks like a date (YYYY-MM-DD), filter orders created on that day
                if (DateTime.TryParse(q.Trim(), out var day))
                {
                    var start = day.Date;
                    var end = start.AddDays(1);
                    list = list.Where(o => o.CreatedAt >= start && o.CreatedAt < end).ToList();
                }
                else
                {
                    list = list.Where(o =>
                        (o.OrderNumber ?? "").ToLowerInvariant().Contains(term)
                        || (o.ShippingFullName ?? "").ToLowerInvariant().Contains(term)
                        || (o.Customer?.Email ?? "").ToLowerInvariant().Contains(term)
                        || (o.Customer?.FullName ?? "").ToLowerInvariant().Contains(term)
                        || o.Id.ToString() == term
                    ).ToList();
                }
            }
            return View(list);
        }

        /// <summary>
        /// GET /Admin/OrderDetail/{id}
        /// Full detail page for a single order: customer info, line items,
        /// delivery tracking timeline, and receipt.
        /// </summary>
        public async Task<IActionResult> OrderDetail(int id)
        {
            if (!IsAdmin) return Guard();
            if (!RoleCan("Orders")) return DenyRole();
            var order = await _adminOrders.GetOrderDetailAsync(id);
            if (order == null) return NotFound();
            return View(order);
        }

        /// <summary>
        /// POST /Admin/UpdateOrderStatus
        /// Changes the lifecycle status of an order (e.g. ToShip → ToReceive).
        /// Redirects back to OrderDetail after saving.
        /// </summary>
        [HttpPost]
        public async Task<IActionResult> UpdateOrderStatus(int orderId, OrderStatus status)
        {
            if (!IsAdmin) return Guard();
            if (!RoleCan("Orders")) return DenyRole();
            await _adminOrders.UpdateStatusAsync(orderId, status);
            TempData["Success"] = "Order status updated.";
            return RedirectToAction("OrderDetail", new { id = orderId });
        }

        /// <summary>
        /// GET /Admin/SalesInvoice/{id}
        /// Personal Sales Invoice (SI) for the order – printable back-office document.
        /// </summary>
        [HttpGet]
        public async Task<IActionResult> SalesInvoice(int id)
        {
            if (!IsAdmin) return Guard();
            if (!RoleCan("SalesInvoice")) return DenyRole();
            var doc = await _invoices.GetOrCreateInvoiceAsync(id);
            if (doc == null) return NotFound();
            return View(doc);
        }

        /// <summary>
        /// POST /Admin/AddDeliveryTracking
        /// Creates a new DeliveryTracking milestone for an order.
        /// Used by the "Add Tracking Update" form on OrderDetail.
        /// </summary>
        [HttpPost]
        public async Task<IActionResult> AddDeliveryTracking(AddDeliveryTrackingViewModel model)
        {
            if (!IsAdmin) return Guard();

            if (!ModelState.IsValid)
            {
                TempData["Error"] = "Please fill in all required tracking fields.";
                return RedirectToAction("OrderDetail", new { id = model.OrderId });
            }

            // Create the tracking entry from the form data
            _db.DeliveryTrackings.Add(new DeliveryTracking
            {
                OrderId = model.OrderId,
                Status = model.Status,
                Location = model.Location,
                Notes = model.Notes,
                TrackingTime = model.TrackingTime
            });
            await _db.SaveChangesAsync();

            TempData["Success"] = "Tracking update added successfully.";
            return RedirectToAction("OrderDetail", new { id = model.OrderId });
        }

        // ══════════════════════════════════════════════════════════════
        //  PRODUCTS
        //  List view + add/edit form + soft-delete toggle.
        // ══════════════════════════════════════════════════════════════

        /// <summary>
        /// GET /Admin/Products
        /// Lists all products grouped by category then alphabetically by name.
        /// Includes Category navigation for the category name column.
        /// </summary>
        public async Task<IActionResult> Products(string? stock = null)
        {
            if (!IsAdmin) return Guard();
            if (!RoleCan("Products")) return DenyRole();
            ViewBag.StockFilter = stock;

            var products = await _db.Products.AsNoTracking()
                .Include(p => p.Category)
                .OrderBy(p => p.Category.Name).ThenBy(p => p.Name)
                .ToListAsync();

            return View(products);
        }

        /// <summary>
        /// GET /Admin/ProductForm/{id?}
        /// Shows a blank form for adding a new product (id is null),
        /// or a pre-filled form for editing an existing product (id provided).
        /// </summary>
        [HttpGet]
        public async Task<IActionResult> ProductForm(int? id)
        {
            if (!IsAdmin) return Guard();
            if (!RoleCan("Products")) return DenyRole();

            // Fetch all categories for the dropdown select list
            var cats = await _db.Categories.Where(c => c.IsActive).ToListAsync();

            if (id.HasValue)
            {
                // Edit mode: load the existing product and map to the form view model
                var p = await _db.Products.FindAsync(id);
                if (p == null) return NotFound();

                return View(new ProductFormViewModel
                {
                    Id = p.Id,
                    Name = p.Name,
                    Description = p.Description,
                    Price = p.Price,
                    DiscountPrice = p.DiscountPrice,
                    Stock = p.Stock,
                    ImageUrl = p.ImageUrl,
                    Brand = p.Brand,
                    IsActive = p.IsActive,
                    CategoryId = p.CategoryId,
                    Categories = cats
                });
            }

            // Add mode: return an empty form with IsActive defaulting to true
            return View(new ProductFormViewModel { IsActive = true, Categories = cats, IsCreateMode = true });
        }

        /// <summary>
        /// POST /Admin/ProductForm
        /// Handles both Add (model.Id == 0) and Edit (model.Id > 0) in one action.
        /// Validates the form, then inserts or updates the Product record.
        /// </summary>
        [HttpPost]
        public async Task<IActionResult> ProductForm(ProductFormViewModel model, IFormFile? ImageFile)
        {
            if (!IsAdmin) return Guard();

            // Re-populate categories for the dropdown in case we return the view on error
            model.Categories = await _db.Categories.Where(c => c.IsActive).ToListAsync();

            if (!ModelState.IsValid) return View(model);

            if (model.Id == 0)
            {
                // INSERT – create a new product record
                var imgUrl = await SaveUploadAsync(ImageFile, "products") ?? model.ImageUrl;
                _db.Products.Add(new Product
                {
                    Name = model.Name,
                    Description = model.Description,
                    Price = model.Price,
                    DiscountPrice = model.DiscountPrice,
                    Stock = model.Stock,
                    ImageUrl = imgUrl,
                    Brand = model.Brand,
                    IsActive = true,
                    CategoryId = model.CategoryId
                });
            }
            else
            {
                // UPDATE – find the existing record and apply changes
                var p = await _db.Products.FindAsync(model.Id);
                if (p == null) return NotFound();

                var imgUrl = await SaveUploadAsync(ImageFile, "products", p.ImageUrl) ?? p.ImageUrl;
                p.Name = model.Name;
                p.Description = model.Description;
                p.Price = model.Price;
                p.DiscountPrice = model.DiscountPrice;
                p.Stock = model.Stock;
                p.ImageUrl = imgUrl;
                p.Brand = model.Brand;
                p.IsActive = model.IsActive; // preserve explicit admin choice; never force true on edit
                p.CategoryId = model.CategoryId;
            }

            await _db.SaveChangesAsync();
            TempData["Success"] = model.Id == 0 ? "Product added successfully." : "Product updated successfully.";
            return RedirectToAction("Products");
        }

        /// <summary>POST /Admin/DeleteProduct/{id} – permanently deletes a product.</summary>
        [HttpPost]
        public async Task<IActionResult> DeleteProduct(int id)
        {
            if (!IsAdmin) return Guard();
            if (!RoleCan("Products")) return DenyRole();
            var p = await _db.Products.FindAsync(id);
            if (p != null)
            {
                if (!string.IsNullOrEmpty(p.ImageUrl))
                {
                    var fullPath = Path.Combine(_env.WebRootPath, p.ImageUrl.TrimStart('/'));
                    if (System.IO.File.Exists(fullPath)) System.IO.File.Delete(fullPath);
                }
                _db.Products.Remove(p);
                await _db.SaveChangesAsync();
                TempData["Success"] = $"Product '{p.Name}' deleted.";
            }
            return RedirectToAction("Products");
        }

        /// <summary>
        /// POST /Admin/ToggleProductStatus/{id}
        /// Flips the IsActive flag on a product (soft activate/deactivate).
        /// Deactivated products are hidden from customers but preserved in orders.
        /// </summary>
        [HttpPost]
        public async Task<IActionResult> ToggleProductStatus(int id)
        {
            if (!IsAdmin) return Guard();

            var p = await _db.Products.FindAsync(id);
            if (p != null)
            {
                p.IsActive = !p.IsActive;
                await _db.SaveChangesAsync();
                TempData["Success"] = p.IsActive ? "Product activated." : "Product deactivated.";
            }
            return RedirectToAction("Products");
        }

        // ══════════════════════════════════════════════════════════════
        //  CUSTOMERS
        //  List and detail views for viewing / managing customer accounts.
        // ══════════════════════════════════════════════════════════════

        /// <summary>
        /// GET /Admin/Customers
        /// Lists all registered customers, newest first, with order counts.
        /// </summary>
        public async Task<IActionResult> Customers()
        {
            if (!IsAdmin) return Guard();
            if (!RoleCan("Customers")) return DenyRole();

            var customers = await _db.Customers.AsNoTracking()
                .Include(c => c.Orders)
                .OrderByDescending(c => c.CreatedAt)
                .ToListAsync();

            return View(customers);
        }

        /// <summary>
        /// GET /Admin/CustomerDetail/{id}
        /// Full profile view for one customer: personal info, saved addresses,
        /// and complete order history with line items.
        /// </summary>
        public async Task<IActionResult> CustomerDetail(int id)
        {
            if (!IsAdmin) return Guard();
            if (!RoleCan("Customers")) return DenyRole();

            var customer = await _db.Customers
                .Include(c => c.Orders).ThenInclude(o => o.OrderItems).ThenInclude(i => i.Product)
                .Include(c => c.Addresses)
                .FirstOrDefaultAsync(c => c.Id == id);

            if (customer == null) return NotFound();

            return View(new CustomerDetailViewModel
            {
                Customer = customer,
                Addresses = customer.Addresses.ToList(),
                Orders = customer.Orders.OrderByDescending(o => o.CreatedAt).ToList()
            });
        }

        /// <summary>
        /// POST /Admin/ToggleCustomerStatus/{id}
        /// Activates or deactivates a customer account.
        /// Deactivated customers cannot log in but their orders are preserved.
        /// </summary>
        [HttpPost]
        
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ArchiveCustomer(int id)
        {
            if (!IsAdmin) return Guard();
            var c = await _db.Customers.FindAsync(id);
            if (c != null)
            {
                c.IsActive = false;
                await _db.SaveChangesAsync();
                TempData["Success"] = "Customer archived (soft delete). They cannot log in; orders kept.";
            }
            return RedirectToAction("Customers");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> RestoreCustomer(int id)
        {
            if (!IsAdmin) return Guard();
            var c = await _db.Customers.FindAsync(id);
            if (c != null)
            {
                c.IsActive = true;
                await _db.SaveChangesAsync();
                TempData["Success"] = "Customer restored.";
            }
            return RedirectToAction("Customers");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteCustomerPermanent(int id)
        {
            if (!IsAdmin) return Guard();
            var c = await _db.Customers
                .Include(x => x.Orders)
                .FirstOrDefaultAsync(x => x.Id == id);
            if (c == null) return RedirectToAction("Customers");
            if (c.Orders != null && c.Orders.Any())
            {
                TempData["Error"] = "Cannot permanently delete: customer has orders. Archive instead.";
                return RedirectToAction("Customers");
            }
            // cleanup related without orders
            var carts = _db.CartItems.Where(x => x.CustomerId == id);
            _db.CartItems.RemoveRange(carts);
            var addrs = _db.CustomerAddresses.Where(x => x.CustomerId == id);
            _db.CustomerAddresses.RemoveRange(addrs);
            var cvs = _db.CustomerVouchers.Where(x => x.CustomerId == id);
            _db.CustomerVouchers.RemoveRange(cvs);
            _db.Customers.Remove(c);
            await _db.SaveChangesAsync();
            TempData["Success"] = "Customer permanently deleted.";
            return RedirectToAction("Customers");
        }


        public async Task<IActionResult> ToggleCustomerStatus(int id)
        {
            if (!IsAdmin) return Guard();

            var c = await _db.Customers.FindAsync(id);
            if (c != null)
            {
                c.IsActive = !c.IsActive;
                await _db.SaveChangesAsync();
                TempData["Success"] = c.IsActive ? "Customer activated." : "Customer deactivated.";
            }
            return RedirectToAction("Customers");
        }



        // ══════════════════════════════════════════════════════════════
        //  DELIVERIES — ship / track fulfillment queue
        // ══════════════════════════════════════════════════════════════
        public async Task<IActionResult> Deliveries(string tab = "ToShip")
        {
            if (!IsAdmin) return Guard();
            if (!RoleCan("Deliveries")) return DenyRole();
            ViewBag.Tab = tab;
            var q = _db.Orders.AsNoTracking()
                .Include(o => o.Customer)
                .Include(o => o.OrderItems)
                .Include(o => o.DeliveryTrackings)
                .AsQueryable();

            q = (tab ?? "ToShip") switch
            {
                "ToReceive" => q.Where(o => o.Status == OrderStatus.ToReceive),
                "Completed" => q.Where(o => o.Status == OrderStatus.Completed),
                "All" => q.Where(o => o.Status == OrderStatus.ToShip || o.Status == OrderStatus.ToReceive || o.Status == OrderStatus.Completed),
                _ => q.Where(o => o.Status == OrderStatus.ToShip)
            };

            var list = await q.OrderByDescending(o => o.CreatedAt).ToListAsync();
            return View(list);
        }

        [HttpPost]
        public async Task<IActionResult> MarkShipped(int orderId, string? trackingNote)
        {
            if (!IsAdmin) return Guard();
            var o = await _db.Orders.FindAsync(orderId);
            if (o == null) return NotFound();
            o.Status = OrderStatus.ToReceive;
            _db.DeliveryTrackings.Add(new DeliveryTracking
            {
                OrderId = o.Id,
                Status = "Shipped",
                Location = "Catron Warehouse, Cebu City",
                Notes = string.IsNullOrWhiteSpace(trackingNote) ? "Package handed to courier." : trackingNote.Trim(),
                TrackingTime = DateTime.UtcNow
            });
            await _db.SaveChangesAsync();
            TempData["Success"] = $"Order #{o.OrderNumber} marked as shipped.";
            return RedirectToAction("Deliveries", new { tab = "ToReceive" });
        }

        [HttpPost]
        public async Task<IActionResult> MarkDelivered(int orderId)
        {
            if (!IsAdmin) return Guard();
            var o = await _db.Orders.FindAsync(orderId);
            if (o == null) return NotFound();

            // Delivered → ToReview (customer can rate). COD collected on delivery.
            o.Status = OrderStatus.ToReview;
            if (o.PaymentMethod == PaymentMethod.Cash && o.PaymentStatus != PaymentStatus.Paid)
            {
                o.PaymentStatus = PaymentStatus.Paid;
                o.PaidAt = DateTime.UtcNow;
            }
            _db.DeliveryTrackings.Add(new DeliveryTracking
            {
                OrderId = o.Id,
                Status = "Delivered",
                Location = o.ShippingAddress,
                Notes = "Package delivered to customer." + (o.PaymentMethod == PaymentMethod.Cash ? " COD payment collected." : ""),
                TrackingTime = DateTime.UtcNow
            });
            await _db.SaveChangesAsync();
            TempData["Success"] = $"Order #{o.OrderNumber} delivered. Customer can now rate products.";
            return RedirectToAction("Deliveries", new { tab = "ToReceive" });
        }

        // ══════════════════════════════════════════════════════════════
        //  PAYMENTS — verification queue (GCash pending + COD unpaid)
        // ══════════════════════════════════════════════════════════════
        public async Task<IActionResult> Payments(string tab = "Pending")
        {
            if (!IsAdmin) return Guard();
            if (!RoleCan("Payments")) return DenyRole();
            ViewBag.Tab = tab;
            var q = _db.Orders.AsNoTracking()
                .Include(o => o.Customer)
                .Include(o => o.OrderItems)
                .AsQueryable();

            q = (tab ?? "Pending") switch
            {
                "Verified" => q.Where(o => o.PaymentStatus == PaymentStatus.Paid),
                "Rejected" => q.Where(o => o.PaymentStatus == PaymentStatus.Failed),
                _ => q.Where(o => o.PaymentStatus == PaymentStatus.Pending)
            };

            var list = await q.OrderByDescending(o => o.CreatedAt).ToListAsync();
            return View(list);
        }

        [HttpPost]
        public async Task<IActionResult> VerifyPayment(int orderId, bool approve = true)
        {
            if (!IsAdmin) return Guard();
            var o = await _db.Orders.FindAsync(orderId);
            if (o == null) return NotFound();

            // Load items for stock deduction on approve
            o = await _db.Orders
                .Include(x => x.OrderItems).ThenInclude(i => i.Product)
                .FirstAsync(x => x.Id == orderId);

            var (ok, err) = await _lifecycle.VerifyGCashPaymentAsync(o, approve);
            if (!ok)
            {
                TempData["Error"] = err ?? "Verification failed.";
                return RedirectToAction("Payments");
            }
            await _db.SaveChangesAsync();
            TempData["Success"] = approve
                ? $"Payment verified for order #{o.OrderNumber}. Stock deducted. Status → ToShip."
                : $"Payment rejected for order #{o.OrderNumber}. Customer may resubmit.";
            return RedirectToAction("Payments");
        }

        // ══════════════════════════════════════════════════════════════
        //  INVENTORY — stock command center
        // ══════════════════════════════════════════════════════════════
        public async Task<IActionResult> Inventory(string? status = null)
        {
            if (!IsAdmin) return Guard();
            if (!RoleCan("Inventory")) return DenyRole();
            ViewBag.Status = status;
            var products = await _db.Products.AsNoTracking()
                .Include(p => p.Category)
                .Where(p => p.IsActive)
                .OrderBy(p => p.Stock)
                .ThenBy(p => p.Name)
                .ToListAsync();

            if (status == "out") products = products.Where(p => p.Stock <= 0).ToList();
            else if (status == "critical") products = products.Where(p => p.Stock > 0 && p.Stock < 3).ToList();
            else if (status == "low") products = products.Where(p => p.Stock > 0 && p.Stock < 5).ToList();
            else if (status == "healthy") products = products.Where(p => p.Stock >= 5).ToList();

            ViewBag.Total = await _db.Products.CountAsync(p => p.IsActive);
            ViewBag.Low = await _db.Products.CountAsync(p => p.IsActive && p.Stock > 0 && p.Stock < 5);
            ViewBag.Critical = await _db.Products.CountAsync(p => p.IsActive && p.Stock > 0 && p.Stock < 3);
            ViewBag.Out = await _db.Products.CountAsync(p => p.IsActive && p.Stock <= 0);

            return View(products);
        }

        [HttpPost]
        public async Task<IActionResult> AdjustStock(int productId, string adjustType, int quantity, string? reason)
        {
            if (!IsAdmin) return Guard();
            if (!RoleCan("Inventory")) return DenyRole();
            var p = await _db.Products.FindAsync(productId);
            if (p == null) return NotFound();
            if (quantity < 0) quantity = 0;

            var before = p.Stock;
            switch ((adjustType ?? "in").ToLowerInvariant())
            {
                case "out":
                case "damaged":
                    p.Stock = Math.Max(0, p.Stock - quantity);
                    break;
                case "correction":
                    p.Stock = quantity;
                    break;
                default: // in / returned
                    p.Stock += quantity;
                    break;
            }
            await _db.SaveChangesAsync();
            TempData["Success"] = $"{p.Name}: stock {before} → {p.Stock}" + (string.IsNullOrWhiteSpace(reason) ? "" : $" ({reason})");
            return RedirectToAction("Inventory");
        }

        // ══════════════════════════════════════════════════════════════
        //  RETURNS & REFUNDS
        //  Admin reviews return requests and approves or rejects them.
        // ══════════════════════════════════════════════════════════════

        /// <summary>
        /// GET /Admin/Returns
        /// Lists all return requests ordered by most recent first.
        /// </summary>
        public async Task<IActionResult> Reviews()
        {
            if (!IsAdmin) return Guard();
            if (!RoleCan("Reviews")) return DenyRole();
            var list = await _db.Reviews.AsNoTracking()
                .Include(r => r.Customer)
                .Include(r => r.Product)
                .Include(r => r.Replies).ThenInclude(rp => rp.Customer)
                .Include(r => r.Replies).ThenInclude(rp => rp.Admin)
                .OrderByDescending(r => r.CreatedAt)
                .ToListAsync();
            return View(list);
        }

        /// <summary>Official Catron store reply under a customer review (visible on product page).</summary>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> OfficialReviewReply(int reviewId, string message)
        {
            if (!IsAdmin) return Guard();
            if (!RoleCan("Reviews")) return DenyRole();
            var text = (message ?? "").Trim();
            if (text.Length < 2)
            {
                TempData["Error"] = "Please write a reply.";
                return RedirectToAction("Reviews");
            }
            if (text.Length > 500) text = text[..500];

            var review = await _db.Reviews.FindAsync(reviewId);
            if (review == null) return NotFound();

            var adminIdStr = HttpContext.Session.GetString("AdminId");
            int? adminId = int.TryParse(adminIdStr, out var aid) ? aid : null;

            _db.ReviewReplies.Add(new ReviewReply
            {
                ReviewId = reviewId,
                CustomerId = null,
                AdminId = adminId,
                IsOfficialReply = true,
                IsReviewerReply = false,
                Message = text
            });
            await _db.SaveChangesAsync();
            TempData["Success"] = "Catron official reply posted. Customers will see it on the product page.";
            return RedirectToAction("Reviews");
        }

        public async Task<IActionResult> Returns()
        {
            if (!IsAdmin) return Guard();
            if (!RoleCan("Returns")) return DenyRole();

            var returns = await _db.ReturnRequests
                .Include(r => r.Customer)
                .Include(r => r.Order)
                .OrderByDescending(r => r.RequestedAt)
                .ToListAsync();

            return View(returns);
        }

        /// <summary>
        /// POST /Admin/ProcessReturn
        /// Updates a return request's status (Approved / Rejected / Completed)
        /// and saves an optional admin note visible to the customer.
        /// </summary>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ProcessReturn(int id, ReturnStatus status, string? adminNote)
        {
            if (!IsAdmin) return Guard();

            var r = await _db.ReturnRequests.FindAsync(id);
            if (r != null)
            {
                r.Status = status;
                r.AdminNote = adminNote;
                r.ResolvedAt = DateTime.UtcNow;
                await _db.SaveChangesAsync();
                TempData["Success"] = $"Return request {status}.";
            }
            return RedirectToAction("Returns");
        }

        /// <summary>
        /// POST /Admin/ApproveReturn — Approve a pending return request.
        /// </summary>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ApproveReturn(int id, string? adminNote)
        {
            if (!IsAdmin) return Guard();

            var r = await _db.ReturnRequests
                .Include(x => x.Order)
                .FirstOrDefaultAsync(x => x.Id == id);
            if (r == null) return NotFound();

            if (r.Status != ReturnStatus.Pending)
            {
                TempData["Error"] = "Only pending returns can be approved.";
                return RedirectToAction("Returns");
            }

            r.Status = ReturnStatus.Approved;
            r.AdminNote = adminNote ?? "Return approved by admin.";
            r.ResolvedAt = DateTime.UtcNow;

            if (r.Order != null)
            {
                r.Order.Status = OrderStatus.ReturnRefund;
            }

            await _db.SaveChangesAsync();
            TempData["Success"] = $"Return request #{id} approved.";
            return RedirectToAction("Returns");
        }

        /// <summary>
        /// POST /Admin/RejectReturn — Reject a pending return request.
        /// </summary>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> RejectReturn(int id, string? adminNote)
        {
            if (!IsAdmin) return Guard();

            var r = await _db.ReturnRequests
                .Include(x => x.Order)
                .FirstOrDefaultAsync(x => x.Id == id);
            if (r == null) return NotFound();

            if (r.Status != ReturnStatus.Pending)
            {
                TempData["Error"] = "Only pending returns can be rejected.";
                return RedirectToAction("Returns");
            }

            r.Status = ReturnStatus.Rejected;
            r.AdminNote = adminNote ?? "Return request rejected.";
            r.ResolvedAt = DateTime.UtcNow;

            await _db.SaveChangesAsync();
            TempData["Success"] = $"Return request #{id} rejected.";
            return RedirectToAction("Returns");
        }

        // ══════════════════════════════════════════════════════════════
        //  CATEGORY MANAGEMENT  ← NEW SECTION
        //  Allows admins to add, edit, and activate/deactivate categories
        //  that appear in the storefront navigation.
        // ══════════════════════════════════════════════════════════════

        /// <summary>
        /// GET /Admin/Categories
        /// Lists all categories (active and inactive) with product counts.
        /// </summary>
        public async Task<IActionResult> Categories()
        {
            if (!IsAdmin) return Guard();
            if (!RoleCan("Categories")) return DenyRole();

            // Include Products so the view can show how many products are in each category
            var categories = await _db.Categories.AsNoTracking()
                .Include(c => c.Products)
                .OrderBy(c => c.Name)
                .ToListAsync();

            return View(categories);
        }

        /// <summary>
        /// GET /Admin/CategoryForm/{id?}
        /// Shows a blank form to add a new category (id is null),
        /// or a pre-filled form to edit an existing one (id provided).
        /// </summary>
        [HttpGet]
        public async Task<IActionResult> CategoryForm(int? id)
        {
            if (!IsAdmin) return Guard();
            if (!RoleCan("Categories")) return DenyRole();

            if (id.HasValue)
            {
                // EDIT mode: load the existing category into the form view model
                var cat = await _db.Categories.FindAsync(id);
                if (cat == null) return NotFound();

                return View(new CategoryFormViewModel
                {
                    Id = cat.Id,
                    Name = cat.Name,
                    Description = cat.Description,
                    IconClass = cat.IconClass,
                    IsActive = cat.IsActive,
                    ImageUrl = cat.ImageUrl
                });
            }

            // ADD mode: return a blank form with IsActive defaulting to true
            return View(new CategoryFormViewModel { IsActive = true });
        }

        /// <summary>
        /// POST /Admin/CategoryForm
        /// Handles both Add (Id == 0) and Edit (Id > 0) in one action.
        /// On success redirects to the Categories list.
        /// </summary>
        [HttpPost]
        public async Task<IActionResult> CategoryForm(CategoryFormViewModel model, IFormFile? ImageFile)
        {
            if (!IsAdmin) return Guard();

            if (!ModelState.IsValid) return View(model);

            if (model.Id == 0)
            {
                // INSERT – create a new Category record
                var imgUrl = await SaveUploadAsync(ImageFile, "categories");
                _db.Categories.Add(new Category
                {
                    Name = model.Name.Trim(),
                    Description = model.Description?.Trim(),
                    IconClass = model.IconClass?.Trim(),
                    IsActive = true,
                    ImageUrl = imgUrl
                });
                TempData["Success"] = "Category added successfully.";
            }
            else
            {
                // UPDATE – find the existing record and update its fields
                var cat = await _db.Categories.FindAsync(model.Id);
                if (cat == null) return NotFound();

                var imgUrl = await SaveUploadAsync(ImageFile, "categories", cat.ImageUrl) ?? cat.ImageUrl;
                cat.Name = model.Name.Trim();
                cat.Description = model.Description?.Trim();
                cat.IconClass = model.IconClass?.Trim();
                cat.IsActive = model.IsActive;
                cat.ImageUrl = imgUrl;

                TempData["Success"] = "Category updated successfully.";
            }

            await _db.SaveChangesAsync();
            return RedirectToAction("Categories");
        }

        /// <summary>POST /Admin/DeleteCategory/{id} – permanently deletes a category.</summary>
        [HttpPost]
        public async Task<IActionResult> DeleteCategory(int id)
        {
            if (!IsAdmin) return Guard();
            if (!RoleCan("Categories")) return DenyRole();
            var cat = await _db.Categories.Include(c => c.Products).FirstOrDefaultAsync(c => c.Id == id);
            if (cat != null)
            {
                if (cat.Products.Any())
                {
                    TempData["Error"] = "Cannot delete a category that has products. Remove or reassign its products first.";
                    return RedirectToAction("Categories");
                }
                if (!string.IsNullOrEmpty(cat.ImageUrl))
                {
                    var fullPath = Path.Combine(_env.WebRootPath, cat.ImageUrl.TrimStart('/'));
                    if (System.IO.File.Exists(fullPath)) System.IO.File.Delete(fullPath);
                }
                _db.Categories.Remove(cat);
                await _db.SaveChangesAsync();
                TempData["Success"] = $"Category '{cat.Name}' deleted.";
            }
            return RedirectToAction("Categories");
        }

        /// <summary>
        /// POST /Admin/ToggleCategoryStatus/{id}
        /// Flips IsActive on a category.
        /// Inactive categories are hidden from the storefront navigation.
        /// Existing products in the category are not affected.
        /// </summary>
        [HttpPost]
        public async Task<IActionResult> ToggleCategoryStatus(int id)
        {
            if (!IsAdmin) return Guard();

            var cat = await _db.Categories.FindAsync(id);
            if (cat != null)
            {
                cat.IsActive = !cat.IsActive;
                await _db.SaveChangesAsync();
                TempData["Success"] = cat.IsActive ? "Category activated." : "Category deactivated.";
            }
            return RedirectToAction("Categories");
        }

        // ══════════════════════════════════════════════════════════════
        //  USER (ADMIN) MANAGEMENT  ← NEW SECTION
        //  Lets a logged-in admin view, add, edit, and
        //  activate/deactivate other admin accounts.
        //
        //  Safety rules enforced here:
        //    • An admin CANNOT deactivate their own account.
        //    • The seed admin (Id = 1) cannot be deactivated.
        //    • Password is only changed when a new one is provided.
        // ══════════════════════════════════════════════════════════════

        /// <summary>
        /// GET /Admin/UserManagement
        /// Lists all admin accounts (active and inactive) ordered newest-first.
        /// ViewBag.CurrentAdminId is passed so the view can disable the
        /// self-deactivation button.
        /// </summary>
        public async Task<IActionResult> UserManagement()
        {
            if (!IsAdmin) return Guard();
            if (!RoleCan("Staff")) return DenyRole();

            var admins = await _db.Admins.AsNoTracking()
                .OrderByDescending(a => a.CreatedAt)
                .ToListAsync();

            var customers = await _db.Customers.AsNoTracking()
                .Include(c => c.Orders)
                .OrderByDescending(c => c.CreatedAt)
                .ToListAsync();

            ViewBag.CurrentAdminId = int.Parse(HttpContext.Session.GetString("AdminId")!);
            ViewBag.Customers = customers;
            ViewBag.CreateModel = new UserFormViewModel { Role = AdminRole.Sales };

            return View(admins);
        }

        /// <summary>
        /// GET /Admin/UserForm/{id?}
        /// Shows a blank form to create a new admin account (id is null),
        /// or a pre-filled form to edit an existing one (id provided).
        /// When editing, password fields are left blank; fill them only to change the password.
        /// </summary>
        [HttpGet]
        public async Task<IActionResult> UserForm(int? id)
        {
            if (!IsAdmin) return Guard();
            if (!RoleCan("Staff")) return DenyRole();

            if (id.HasValue)
            {
                // EDIT mode – load the existing admin account
                var admin = await _db.Admins.FindAsync(id);
                if (admin == null) return NotFound();

                return View(new UserFormViewModel
                {
                    Id = admin.Id,
                    Username = admin.Username,
                    Email = admin.Email,
                    IsActive = admin.IsActive,
                    ProfilePicture = admin.ProfilePicture,
                    Role = admin.Role
                    // Password intentionally left blank for edit mode
                });
            }

            // ADD mode – blank form with IsActive = true by default
            return View(new UserFormViewModel { IsActive = true });
        }

        /// <summary>
        /// POST /Admin/UserForm
        /// Handles both Add (Id == 0) and Edit (Id > 0).
        ///
        /// Add:  Default password = email. Creates a new Admin record.
        /// Edit: Profile/role only — password not editable by admin.
        ///       Username and Email uniqueness are re-checked (excluding self).
        /// </summary>
        [HttpPost]
        public async Task<IActionResult> UserForm(UserFormViewModel model)
        {
            if (!IsAdmin) return Guard();

            // Password fields removed: new staff default password = email; admin cannot set others' passwords.

            if (!ModelState.IsValid)
            {
                if (model.Id == 0)
                {
                    var adminsInvalid = await _db.Admins.AsNoTracking().OrderByDescending(a => a.CreatedAt).ToListAsync();
                    ViewBag.CurrentAdminId = int.Parse(HttpContext.Session.GetString("AdminId")!);
                    ViewBag.CreateModel = model;
                    return View("UserManagement", adminsInvalid);
                }
                return View(model);
            }

            if (model.Id == 0)
            {
                // ── INSERT – create a new admin account ──────────────────
                // Check that username and email are not already used
                bool duplicate = await _db.Admins.AnyAsync(a =>
                    a.Username == model.Username || a.Email == model.Email);

                if (duplicate)
                {
                    ModelState.AddModelError("", "Username or email already exists.");
                    var adminsDup = await _db.Admins.AsNoTracking().OrderByDescending(a => a.CreatedAt).ToListAsync();
                    ViewBag.CurrentAdminId = int.Parse(HttpContext.Session.GetString("AdminId")!);
                    ViewBag.CreateModel = model;
                    return View("UserManagement", adminsDup);
                }

                var picPath = await SaveUploadAsync(Request.Form.Files.GetFile("ProfilePictureFile"), "profiles");
                _db.Admins.Add(new Admin
                {
                    Username = model.Username.Trim(),
                    Email = model.Email.Trim().ToLower(),
                    PasswordHash = AdminPasswordHasher.Hash(
                        string.IsNullOrWhiteSpace(model.Password) ? model.Email.Trim().ToLower() : model.Password),
                    IsActive = true,
                    ProfilePicture = picPath,
                    Role = model.Role
                });

                TempData["Success"] = $"Admin account '{model.Username}' created successfully.";
            }
            else
            {
                // ── UPDATE – edit an existing admin account ───────────────
                var admin = await _db.Admins.FindAsync(model.Id);
                if (admin == null) return NotFound();

                // Check uniqueness excluding the current record (allow keeping same values)
                bool duplicate = await _db.Admins.AnyAsync(a =>
                    a.Id != model.Id &&
                    (a.Username == model.Username || a.Email == model.Email));

                if (duplicate)
                {
                    ModelState.AddModelError("", "Username or email is already used by another account.");
                    return View(model);
                }

                admin.Username = model.Username.Trim();
                admin.Email = model.Email.Trim().ToLower();
                admin.Role = model.Role;
                // Status is managed from User Management list (Activate/Deactivate), not this form

                // Password is NOT editable by admin — staff use Reset or own Profile.

                var newPic = await SaveUploadAsync(Request.Form.Files.GetFile("ProfilePictureFile"), "profiles", admin.ProfilePicture);
                if (newPic != null) admin.ProfilePicture = newPic;

                TempData["Success"] = $"Admin account '{admin.Username}' updated successfully.";
            }

            await _db.SaveChangesAsync();
            return RedirectToAction("UserManagement");
        }

        /// <summary>
        /// POST /Admin/ToggleAdminStatus/{id}
        /// Activates or deactivates another admin account.
        ///
        /// Safety rules:
        ///   • Cannot deactivate your own account (session admin ID check).
        ///   • Cannot deactivate the seed admin (Id == 1) to prevent lockout.
        /// </summary>
        [HttpPost]
        public async Task<IActionResult> ToggleAdminStatus(int id)
        {
            if (!IsAdmin) return Guard();
            if (!RoleCan("Staff")) return DenyRole();

            int currentAdminId = int.Parse(HttpContext.Session.GetString("AdminId")!);

            // Prevent self-deactivation
            if (id == currentAdminId)
            {
                TempData["Error"] = "You cannot deactivate your own account.";
                return RedirectToAction("UserManagement");
            }

            // Protect the original seed admin (Id == 1) from being locked out
            if (id == 1)
            {
                TempData["Error"] = "The primary admin account cannot be deactivated.";
                return RedirectToAction("UserManagement");
            }

            var admin = await _db.Admins.FindAsync(id);
            if (admin != null)
            {
                admin.IsActive = !admin.IsActive;
                await _db.SaveChangesAsync();
                TempData["Success"] = admin.IsActive
                    ? $"Admin '{admin.Username}' has been activated."
                    : $"Admin '{admin.Username}' has been deactivated.";
            }

            return RedirectToAction("UserManagement");
        }

        /// <summary>POST /Admin/DeleteAdmin/{id} – permanently deletes an admin account.</summary>
        [HttpPost]
        public async Task<IActionResult> DeleteAdmin(int id)
        {
            if (!IsAdmin) return Guard();
            if (!RoleCan("Staff")) return DenyRole();
            int currentAdminId = int.Parse(HttpContext.Session.GetString("AdminId")!);
            if (id == currentAdminId) { TempData["Error"] = "You cannot delete your own account."; return RedirectToAction("UserManagement"); }
            if (id == 1) { TempData["Error"] = "The primary admin account cannot be deleted."; return RedirectToAction("UserManagement"); }
            var admin = await _db.Admins.FindAsync(id);
            if (admin != null)
            {
                if (!string.IsNullOrEmpty(admin.ProfilePicture))
                {
                    var fp = Path.Combine(_env.WebRootPath, admin.ProfilePicture.TrimStart('/'));
                    if (System.IO.File.Exists(fp)) System.IO.File.Delete(fp);
                }
                _db.Admins.Remove(admin);
                await _db.SaveChangesAsync();
                TempData["Success"] = $"Admin '{admin.Username}' deleted.";
            }
            return RedirectToAction("UserManagement");
        }

        /// <summary>POST /Admin/DeleteCustomer/{id} – permanently deletes a customer account.</summary>
        [HttpPost]
        public async Task<IActionResult> DeleteCustomer(int id)
        {
            if (!IsAdmin) return Guard();
            var c = await _db.Customers.FindAsync(id);
            if (c != null)
            {
                if (!string.IsNullOrEmpty(c.ProfilePicture))
                {
                    var fp = Path.Combine(_env.WebRootPath, c.ProfilePicture.TrimStart('/'));
                    if (System.IO.File.Exists(fp)) System.IO.File.Delete(fp);
                }
                _db.Customers.Remove(c);
                await _db.SaveChangesAsync();
                TempData["Success"] = $"Customer '{c.FullName}' deleted.";
            }
            return RedirectToAction("Customers");
        }

        // ══════════════════════════════════════════════════════════════
        //  ADMIN PROFILE
        // ══════════════════════════════════════════════════════════════

        /// <summary>GET /Admin/Profile – shows the logged-in admin's profile.</summary>
        public async Task<IActionResult> Profile()
        {
            if (!IsAdmin) return Guard();
            int adminId = int.Parse(HttpContext.Session.GetString("AdminId")!);
            var admin = await _db.Admins.FindAsync(adminId);
            if (admin == null) return Guard();
            return View(new AdminProfileViewModel
            {
                Id = admin.Id,
                Username = admin.Username,
                Email = admin.Email,
                ProfilePicture = admin.ProfilePicture
            });
        }

        /// <summary>POST /Admin/Profile – saves profile changes including optional picture.</summary>
        [HttpPost]
        public async Task<IActionResult> Profile(AdminProfileViewModel model, IFormFile? ProfilePictureFile)
        {
            if (!IsAdmin) return Guard();
            int adminId = int.Parse(HttpContext.Session.GetString("AdminId")!);
            var admin = await _db.Admins.FindAsync(adminId);
            if (admin == null) return Guard();

            // Check unique username/email excluding self
            if (await _db.Admins.AnyAsync(a => a.Id != adminId && (a.Username == model.Username || a.Email == model.Email)))
            {
                ModelState.AddModelError("", "Username or email already used by another account.");
                model.ProfilePicture = admin.ProfilePicture;
                return View(model);
            }

            admin.Username = model.Username.Trim();
            admin.Email = model.Email.Trim().ToLower();

            if (!string.IsNullOrWhiteSpace(model.NewPassword))
                admin.PasswordHash = AdminPasswordHasher.Hash(model.NewPassword);

            var newPic = await SaveUploadAsync(ProfilePictureFile, "profiles", admin.ProfilePicture);
            if (newPic != null) admin.ProfilePicture = newPic;

            await _db.SaveChangesAsync();

            // Update session
            HttpContext.Session.SetString("AdminUsername", admin.Username);
            HttpContext.Session.SetString("AdminProfilePic", admin.ProfilePicture ?? "");

            TempData["Success"] = "Profile updated successfully.";
            return RedirectToAction("Profile");
        }


        // ── Vouchers (Shopee-style collectible discounts) ─────────────────
        [HttpGet]
        public async Task<IActionResult> Vouchers()
        {
            if (!IsAdmin) return Guard();
            if (!RoleCan("Vouchers")) return DenyRole();
            var list = await _db.Vouchers.AsNoTracking().OrderByDescending(v => v.CreatedAt).ToListAsync();
            return View(list);
        }

        [HttpGet]
        public IActionResult VoucherForm(int? id)
        {
            if (!IsAdmin) return Guard();
            if (id == null) return View(new Voucher { DiscountType = VoucherDiscountType.Percent, DiscountValue = 10, IsActive = true });
            var v = _db.Vouchers.Find(id);
            if (v == null) return NotFound();
            return View(v);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> VoucherForm(Voucher model)
        {
            if (!IsAdmin) return Guard();
            if (!RoleCan("Vouchers")) return DenyRole();
            model.Code = (model.Code ?? "").Trim().ToUpperInvariant();
            if (string.IsNullOrWhiteSpace(model.Code) || string.IsNullOrWhiteSpace(model.Title))
            {
                ModelState.AddModelError("", "Code and title are required.");
                return View(model);
            }
            if (model.Id == 0)
            {
                if (await _db.Vouchers.AnyAsync(x => x.Code == model.Code))
                {
                    ModelState.AddModelError("", "Code already exists.");
                    return View(model);
                }
                model.CreatedAt = DateTime.UtcNow;
                _db.Vouchers.Add(model);
                TempData["Success"] = "Voucher created.";
            }
            else
            {
                var v = await _db.Vouchers.FindAsync(model.Id);
                if (v == null) return NotFound();
                if (await _db.Vouchers.AnyAsync(x => x.Code == model.Code && x.Id != model.Id))
                {
                    ModelState.AddModelError("", "Code already exists.");
                    return View(model);
                }
                v.Code = model.Code;
                v.Title = model.Title;
                v.Description = model.Description;
                v.DiscountType = model.DiscountType;
                v.DiscountValue = model.DiscountValue;
                v.MinSpend = model.MinSpend;
                v.MaxUses = model.MaxUses;
                v.ExpiresAt = model.ExpiresAt;
                v.IsActive = model.IsActive;
                TempData["Success"] = "Voucher updated.";
            }
            await _db.SaveChangesAsync();
            return RedirectToAction("Vouchers");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteVoucher(int id)
        {
            if (!IsAdmin) return Guard();
            var v = await _db.Vouchers.FindAsync(id);
            if (v != null) { _db.Vouchers.Remove(v); await _db.SaveChangesAsync(); TempData["Success"] = "Voucher deleted."; }
            return RedirectToAction("Vouchers");
        }

}
}
