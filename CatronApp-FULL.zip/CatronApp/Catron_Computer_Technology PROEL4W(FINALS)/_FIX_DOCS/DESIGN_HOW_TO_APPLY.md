# Catron Design Improvements — How to apply

## Files to replace / merge

### Customer store
| Source in this package | Destination in project |
|------------------------|------------------------|
| `Views/Shared/_Layout.cshtml` | `Views/Shared/_Layout.cshtml` |
| `Views/Customer/_AccountSidebar.cshtml` | `Views/Customer/_AccountSidebar.cshtml` |
| `wwwroot/css/site-improvements.css` | **Append** contents to `wwwroot/css/site.css` (or link as extra stylesheet in `_Layout`) |

### Admin back-office
| Source | Destination |
|--------|-------------|
| `Views/Shared/_AdminLayout.cshtml` | `Views/Shared/_AdminLayout.cshtml` |
| `Views/Admin/UserManagement.cshtml` | `Views/Admin/UserManagement.cshtml` |
| `wwwroot/css/admin.css` | `wwwroot/css/admin.css` (full replace recommended) |

### Preview
Open `UserManagement_Design_Mockup.html` in a browser for the Staff page design.

## What was fixed / improved

1. **Broken Account sidebar** — fixed garbled “My Vouchers / Wishlist” markup; clean nav with proper links.
2. **Customer header / category nav** — clearer active states, better search placeholder, cleaner top bar.
3. **Footer** — single consistent structure (no competing duplicate CSS).
4. **Admin sidebar** — simplified nav labels (removed nested spans).
5. **User Management** — avatars, search/filter toolbar, icon actions, empty state.
6. **Duplicates** — account sidebar no longer mixes Bootstrap list-group + broken anchors; footer rules consolidated in improvements CSS.

## Optional: link improvements CSS without merging
In `_Layout.cshtml` head, after site.css:
```html
<link rel="stylesheet" href="~/css/site-improvements.css" asp-append-version="true" />
```
