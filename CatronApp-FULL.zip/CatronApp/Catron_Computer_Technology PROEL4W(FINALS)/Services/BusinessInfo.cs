// ============================================================
//  BusinessInfo.cs – Catron Computer Technology
//  Source: https://catroncomputer.com/ (About & Contact)
// ============================================================
namespace Catron_Computer_Technology_PROEL4W_FINALS_.Services
{
    /// <summary>
    /// Official store details aligned with catroncomputer.com
    /// Used on Sales Invoices, About, Contact, footer, chatbot.
    /// </summary>
    public static class BusinessInfo
    {
        public const string LegalName = "Catron Computer Technology";
        public const string TradeName = "Catron Computer Technology - CEBU";
        public const string Tagline = "Computer & Office Solutions Partner";
        public const string Slogan = "Complete Computer & Office Solutions — high-quality computers, printers, office equipment, networking devices, and accessories for businesses and schools.";
        public const string Established = "October 18, 2001";
        public const string WebsiteUrl = "https://catroncomputer.com/";

        public const string AddressLine1 = "#1188 Kimrose Residence, V. Rama Ave.";
        public const string AddressLine2 = "Guadalupe, Cebu City, Philippines";
        public const string FullAddress = "#1188 Kimrose Residence, V. Rama Ave., Guadalupe, Cebu City";
        public const string MapsUrl = "https://maps.app.goo.gl/krdotjHjZkx5T9b69";

        public const string PhonePrimary = "+63 947 471 3330";
        public const string PhoneLandline = "511-1367 · 253-6690 · 254-6984 · 412-6963";
        public const string Viber = "0947-471-3330 · 0939-374-7573 · 0908-515-4932";
        public const string ViberPrimary = "09085154932";
        public const string Email = "catroncomputertech@gmail.com";
        public const string FacebookUrl = "https://www.facebook.com/people/Catron-Computer-Technology-CEBU/100069913147594/";

        /// <summary>Mon–Sat 8:00 AM – 5:00 PM · Sunday closed</summary>
        public const string BusinessHours = "Monday – Saturday, 8:00 AM – 5:00 PM · Sunday CLOSED";

        public const string InvoiceTitle = "SALES INVOICE";
        public const string InvoiceSubtitle = "Sales Invoice (Computer & Office Supplies)";
        public const string TinPlaceholder = "";
    }
}
