// ============================================================
//  OrderLifecycleService
//  AUTHORITATIVE payment + stock + status rules for Catron.
//
//  Rules (do not reinterpret):
//  - Cart never deducts stock
//  - GCash submit → Payment Pending, Order ToPay, NO stock deduct
//  - GCash admin verify → Payment Paid, Order ToShip, deduct stock ONCE
//  - GCash reject → Payment Failed (Rejected), Order stays ToPay, no stock
//  - COD confirm → Payment Unpaid, Order ToShip, deduct stock ONCE
//  - Later status changes NEVER deduct stock again
//  - Cancel before deduction: no stock change
//  - Cancel after deduction: restore ONCE
//  - Returns: stock only after physical return + resalable completion
// ============================================================
using Catron_Computer_Technology_PROEL4W_FINALS_.Data;
using Catron_Computer_Technology_PROEL4W_FINALS_.Models;
using Microsoft.EntityFrameworkCore;

namespace Catron_Computer_Technology_PROEL4W_FINALS_.Services
{
    public interface IOrderLifecycleService
    {
        bool IsValidTransition(OrderStatus from, OrderStatus to);
        IReadOnlyList<OrderStatus> AllowedNextStatuses(Order order);
        Task<(bool ok, string? error)> DeductSaleStockAsync(Order order, int? adminId = null);
        Task<(bool ok, string? error)> RestoreCancelledStockAsync(Order order, int? adminId = null);
        Task<(bool ok, string? error)> AddReturnedStockAsync(int orderId, int productId, int qty, bool resalable, int? adminId = null);
        Task<(bool ok, string? error)> ConfirmGCashSubmissionAsync(Order order, string? reference, string? gcashNumber);
        Task<(bool ok, string? error)> VerifyGCashPaymentAsync(Order order, bool approve, int? adminId = null);
        Task<(bool ok, string? error)> ConfirmCodOrderAsync(Order order);
        Task<(bool ok, string? error)> MarkCodCashCollectedAsync(Order order);
        Task<(bool ok, string? error)> TransitionOrderAsync(Order order, OrderStatus to, int? adminId = null);
        Task<(bool ok, string? error)> CancelOrderAsync(Order order, int? adminId = null);
    }

    public class OrderLifecycleService : IOrderLifecycleService
    {
        private readonly ApplicationDbContext _db;

        public OrderLifecycleService(ApplicationDbContext db)
        {
            _db = db;
        }

        // ── Valid transitions ─────────────────────────────────────────
        private static readonly Dictionary<OrderStatus, OrderStatus[]> Map = new()
        {
            [OrderStatus.ToPay] = new[] { OrderStatus.ToShip, OrderStatus.Cancelled },
            [OrderStatus.ToShip] = new[] { OrderStatus.ToReceive, OrderStatus.Cancelled },
            [OrderStatus.ToReceive] = new[] { OrderStatus.ToReview },
            [OrderStatus.ToReview] = new[] { OrderStatus.Completed, OrderStatus.ReturnRefund },
            [OrderStatus.Completed] = new[] { OrderStatus.ReturnRefund },
            [OrderStatus.ReturnRefund] = new[] { OrderStatus.Completed, OrderStatus.Cancelled },
            [OrderStatus.Cancelled] = Array.Empty<OrderStatus>()
        };

        public bool IsValidTransition(OrderStatus from, OrderStatus to)
        {
            if (from == to) return true;
            return Map.TryGetValue(from, out var next) && next.Contains(to);
        }

        public IReadOnlyList<OrderStatus> AllowedNextStatuses(Order order)
        {
            if (!Map.TryGetValue(order.Status, out var next)) return Array.Empty<OrderStatus>();
            // GCash still Pending: only allow Cancel from ToPay (ToShip comes via Verify)
            if (order.Status == OrderStatus.ToPay
                && order.PaymentMethod == PaymentMethod.GCash
                && order.PaymentStatus == PaymentStatus.Pending)
            {
                return new[] { OrderStatus.Cancelled };
            }
            return next;
        }

        // ── Idempotent stock: Sale ────────────────────────────────────
        public async Task<(bool ok, string? error)> DeductSaleStockAsync(Order order, int? adminId = null)
        {
            // Ensure items + products loaded
            if (order.OrderItems == null || !order.OrderItems.Any())
            {
                await _db.Entry(order).Collection(o => o.OrderItems).LoadAsync();
                foreach (var oi in order.OrderItems)
                    await _db.Entry(oi).Reference(i => i.Product).LoadAsync();
            }

            foreach (var oi in order.OrderItems)
            {
                // Already deducted for this line?
                bool exists = await _db.Set<InventoryMovement>().AnyAsync(m =>
                    m.OrderItemId == oi.Id && m.Reason == InventoryReason.Sale);
                if (exists) continue;

                if (oi.Product == null)
                    return (false, "Order item product missing.");

                if (oi.Product.Stock < oi.Quantity)
                    return (false, $"Insufficient stock for {oi.Product.Name}. Available: {oi.Product.Stock}.");

                oi.Product.Stock -= oi.Quantity;
                _db.Set<InventoryMovement>().Add(new InventoryMovement
                {
                    ProductId = oi.ProductId,
                    QuantityDelta = -oi.Quantity,
                    Reason = InventoryReason.Sale,
                    OrderId = order.Id,
                    OrderItemId = oi.Id,
                    Note = $"Sale order #{order.OrderNumber}",
                    CreatedByAdminId = adminId,
                    CreatedAt = DateTime.UtcNow
                });
            }
            return (true, null);
        }

        public async Task<(bool ok, string? error)> RestoreCancelledStockAsync(Order order, int? adminId = null)
        {
            if (order.OrderItems == null || !order.OrderItems.Any())
            {
                await _db.Entry(order).Collection(o => o.OrderItems).LoadAsync();
                foreach (var oi in order.OrderItems)
                    await _db.Entry(oi).Reference(i => i.Product).LoadAsync();
            }

            foreach (var oi in order.OrderItems)
            {
                // Only restore if Sale movement exists and CancelRestore does not
                bool hadSale = await _db.Set<InventoryMovement>().AnyAsync(m =>
                    m.OrderItemId == oi.Id && m.Reason == InventoryReason.Sale);
                if (!hadSale) continue;

                bool alreadyRestored = await _db.Set<InventoryMovement>().AnyAsync(m =>
                    m.OrderItemId == oi.Id && m.Reason == InventoryReason.CancelRestore);
                if (alreadyRestored) continue;

                if (oi.Product != null)
                    oi.Product.Stock += oi.Quantity;

                _db.Set<InventoryMovement>().Add(new InventoryMovement
                {
                    ProductId = oi.ProductId,
                    QuantityDelta = oi.Quantity,
                    Reason = InventoryReason.CancelRestore,
                    OrderId = order.Id,
                    OrderItemId = oi.Id,
                    Note = $"Cancel restore order #{order.OrderNumber}",
                    CreatedByAdminId = adminId,
                    CreatedAt = DateTime.UtcNow
                });
            }
            return (true, null);
        }

        public async Task<(bool ok, string? error)> AddReturnedStockAsync(
            int orderId, int productId, int qty, bool resalable, int? adminId = null)
        {
            if (qty <= 0) return (false, "Quantity must be positive.");
            var product = await _db.Products.FindAsync(productId);
            if (product == null) return (false, "Product not found.");

            if (resalable)
            {
                product.Stock += qty;
                _db.Set<InventoryMovement>().Add(new InventoryMovement
                {
                    ProductId = productId,
                    QuantityDelta = qty,
                    Reason = InventoryReason.ReturnResalable,
                    OrderId = orderId,
                    Note = "Return resalable",
                    CreatedByAdminId = adminId,
                    CreatedAt = DateTime.UtcNow
                });
            }
            else
            {
                _db.Set<InventoryMovement>().Add(new InventoryMovement
                {
                    ProductId = productId,
                    QuantityDelta = 0,
                    Reason = InventoryReason.Damaged,
                    OrderId = orderId,
                    Note = "Return damaged / non-resalable",
                    CreatedByAdminId = adminId,
                    CreatedAt = DateTime.UtcNow
                });
            }
            return (true, null);
        }

        // ── GCash: customer submits reference only ────────────────────
        public Task<(bool ok, string? error)> ConfirmGCashSubmissionAsync(
            Order order, string? reference, string? gcashNumber)
        {
            if (order.Status != OrderStatus.ToPay)
                return Task.FromResult<(bool, string?)>((false, "Order is not awaiting payment."));

            if (order.PaymentMethod != PaymentMethod.GCash)
                return Task.FromResult<(bool, string?)>((false, "Not a GCash order."));

            // NEVER mark Paid here. NEVER deduct stock here.
            order.GCashReference = string.IsNullOrWhiteSpace(reference) ? order.GCashReference : reference.Trim();
            if (!string.IsNullOrWhiteSpace(gcashNumber))
                order.GCashNumber = gcashNumber.Trim();
            order.PaymentStatus = PaymentStatus.Pending;
            order.Status = OrderStatus.ToPay;
            order.PaidAt = null;
            return Task.FromResult<(bool, string?)>((true, null));
        }

        // ── GCash: admin verifies ─────────────────────────────────────
        public async Task<(bool ok, string? error)> VerifyGCashPaymentAsync(
            Order order, bool approve, int? adminId = null)
        {
            if (order.PaymentMethod != PaymentMethod.GCash)
                return (false, "Not a GCash order.");

            if (approve)
            {
                if (order.PaymentStatus == PaymentStatus.Paid)
                    return (true, null); // already done

                var (stockOk, stockErr) = await DeductSaleStockAsync(order, adminId);
                if (!stockOk) return (false, stockErr);

                order.PaymentStatus = PaymentStatus.Paid;
                order.PaidAt = DateTime.UtcNow;
                order.Status = OrderStatus.ToShip;

                if (!await _db.Receipts.AnyAsync(r => r.OrderId == order.Id))
                {
                    _db.Receipts.Add(new Receipt
                    {
                        OrderId = order.Id,
                        AmountPaid = order.TotalAmount
                    });
                }
            }
            else
            {
                // Reject: no stock was deducted
                order.PaymentStatus = PaymentStatus.Failed; // Rejected
                order.Status = OrderStatus.ToPay;
                order.PaidAt = null;
            }
            return (true, null);
        }

        // ── COD: order confirmed → ToShip + deduct ────────────────────
        public async Task<(bool ok, string? error)> ConfirmCodOrderAsync(Order order)
        {
            if (order.PaymentMethod != PaymentMethod.Cash)
                return (false, "Not a COD order.");

            var (stockOk, stockErr) = await DeductSaleStockAsync(order);
            if (!stockOk) return (false, stockErr);

            order.PaymentStatus = PaymentStatus.Unpaid;
            order.PaidAt = null;
            order.Status = OrderStatus.ToShip;
            return (true, null);
        }

        public Task<(bool ok, string? error)> MarkCodCashCollectedAsync(Order order)
        {
            if (order.PaymentMethod != PaymentMethod.Cash)
                return Task.FromResult<(bool, string?)>((false, "Not a COD order."));

            order.PaymentStatus = PaymentStatus.Paid;
            order.PaidAt = DateTime.UtcNow;
            return Task.FromResult<(bool, string?)>((true, null));
        }

        public async Task<(bool ok, string? error)> TransitionOrderAsync(
            Order order, OrderStatus to, int? adminId = null)
        {
            if (!IsValidTransition(order.Status, to))
                return (false, $"Invalid transition: {order.Status} → {to}.");

            // Special: ToShip from ToPay only via payment confirmation paths
            if (order.Status == OrderStatus.ToPay && to == OrderStatus.ToShip)
            {
                if (order.PaymentMethod == PaymentMethod.GCash)
                {
                    if (order.PaymentStatus != PaymentStatus.Paid)
                        return (false, "GCash must be verified (Paid) before shipping.");
                }
            }

            // COD cash collected when marking Delivered (ToReview)
            if (to == OrderStatus.ToReview
                && order.PaymentMethod == PaymentMethod.Cash
                && order.PaymentStatus == PaymentStatus.Unpaid)
            {
                await MarkCodCashCollectedAsync(order);
                if (!await _db.Receipts.AnyAsync(r => r.OrderId == order.Id))
                {
                    _db.Receipts.Add(new Receipt
                    {
                        OrderId = order.Id,
                        AmountPaid = order.TotalAmount
                    });
                }
            }

            // Cancel path
            if (to == OrderStatus.Cancelled)
                return await CancelOrderAsync(order, adminId);

            order.Status = to;
            return (true, null);
        }

        public async Task<(bool ok, string? error)> CancelOrderAsync(Order order, int? adminId = null)
        {
            if (order.Status == OrderStatus.Cancelled)
                return (true, null);

            // Only allow cancel from ToPay or ToShip (pre-ship)
            if (order.Status is not (OrderStatus.ToPay or OrderStatus.ToShip))
                return (false, "Order can only be cancelled before it is shipped.");

            // Restore stock only if previously deducted
            await RestoreCancelledStockAsync(order, adminId);
            order.Status = OrderStatus.Cancelled;
            return (true, null);
        }
    }
}
