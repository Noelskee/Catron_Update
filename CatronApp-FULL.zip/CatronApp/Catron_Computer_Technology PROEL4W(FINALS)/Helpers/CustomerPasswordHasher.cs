﻿// ============================================================
//  CustomerPasswordHasher.cs
//  Namespace: Catron_Computer_Technology_PROEL4W_FINALS_.Helpers
//
//  Purpose:
//    Static helper that handles all BCrypt password operations
//    specifically for Customer accounts.
//
//    Uses work factor 12 (slightly lower than admin's 13) so that
//    the high volume of customer logins remains responsive while
//    still providing strong brute-force resistance.
//
//  Methods:
//    Hash(plainPassword)               → BCrypt hash string
//    Verify(plainPassword, hash)       → bool
//    GenerateResetToken()              → URL-safe random token
//
//  Usage:
//    string hash  = CustomerPasswordHasher.Hash("MyP@ssword");
//    bool   valid = CustomerPasswordHasher.Verify("MyP@ssword", hash);
// ============================================================

namespace Catron_Computer_Technology_PROEL4W_FINALS_.Helpers
{
    /// <summary>
    /// Provides BCrypt-based password hashing and verification for Customer accounts.
    /// Work factor 12 balances login performance for high customer traffic
    /// while still being resistant to brute-force attacks.
    /// </summary>
    public static class CustomerPasswordHasher
    {
        /// <summary>
        /// BCrypt cost factor.
        /// 12 ≈ ~400 ms per hash on modern hardware – fast enough for
        /// a login endpoint, slow enough to frustrate dictionary attacks.
        /// </summary>
        private const int WorkFactor = 12;

        // ────────────────────────────────────────────────────────────────
        //  Hash
        // ────────────────────────────────────────────────────────────────

        /// <summary>
        /// Hashes a plain-text customer password using BCrypt with work factor 12.
        /// Call this on registration and whenever the customer changes their password.
        /// </summary>
        /// <param name="plainPassword">The raw password typed by the customer.</param>
        /// <returns>A BCrypt hash string safe to store in the Customers table.</returns>
        /// <exception cref="ArgumentException">Thrown if the password is null or whitespace.</exception>
        public static string Hash(string plainPassword)
        {
            // Guard – never attempt to hash an empty value
            if (string.IsNullOrWhiteSpace(plainPassword))
                throw new ArgumentException("Password cannot be empty or whitespace.", nameof(plainPassword));

            return BCrypt.Net.BCrypt.HashPassword(plainPassword, WorkFactor);
        }

        // ────────────────────────────────────────────────────────────────
        //  Verify
        // ────────────────────────────────────────────────────────────────

        /// <summary>
        /// Verifies a plain-text password against a stored BCrypt hash.
        /// BCrypt.Verify() runs in constant time to prevent timing-based attacks.
        /// </summary>
        /// <param name="plainPassword">The raw password the customer submitted at login.</param>
        /// <param name="hashedPassword">The BCrypt hash stored in the Customers table.</param>
        /// <returns>
        ///   True  – password matches (login allowed).
        ///   False – mismatch or either argument is null/empty (login denied).
        /// </returns>
        public static bool Verify(string plainPassword, string hashedPassword)
        {
            // Return false instead of throwing so the controller shows
            // a generic "Invalid credentials" message without leaking details.
            if (string.IsNullOrWhiteSpace(plainPassword) || string.IsNullOrWhiteSpace(hashedPassword))
                return false;

            return BCrypt.Net.BCrypt.Verify(plainPassword, hashedPassword);
        }

        // ────────────────────────────────────────────────────────────────
        //  GenerateResetToken
        // ────────────────────────────────────────────────────────────────

        /// <summary>
        /// Generates a cryptographically random, URL-safe token used in the
        /// customer password-reset email link
        /// (/Customer/ResetPassword?token=...&amp;email=...).
        ///
        /// Derived from a new GUID (128 bits of randomness), Base64-encoded,
        /// and made URL-safe by replacing '+' → '-' and '/' → '_'.
        /// </summary>
        /// <returns>A URL-safe Base64 string suitable for a query-string parameter.</returns>
        public static string GenerateResetToken()
            => Convert.ToBase64String(Guid.NewGuid().ToByteArray())
               .Replace("+", "-")   // Replace URL-unsafe '+' with '-'
               .Replace("/", "_")   // Replace URL-unsafe '/' with '_'
               .TrimEnd('=');       // Strip Base64 padding '=' characters
    }
}
