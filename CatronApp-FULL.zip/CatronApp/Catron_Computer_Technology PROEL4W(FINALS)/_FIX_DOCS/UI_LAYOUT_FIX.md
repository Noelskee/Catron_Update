# UI Layout Consistency Fix

## Root cause
`.main-content { max-width: 1400px; }` without full-width fill left management pages narrow with empty space on the right, while the sidebar already reserved left space.

## Fix
- `#page-content-wrapper` / `.main-content`: **width 100%** of area after sidebar, **no artificial max-width**
- Page headers, cards, tables: **100% of content area**
- Forms: optional `.form-container` max-width 720px centered **within** main content
- Stat grids: equal columns, responsive
- Modals: centered to viewport
- Customer store: containers centered with consistent max-width

## Principle
**Center content within the available main-content area (after sidebar), not the full browser including sidebar.**
