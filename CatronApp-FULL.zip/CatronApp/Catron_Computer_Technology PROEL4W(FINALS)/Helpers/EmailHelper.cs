using System.Net;
using System.Net.Mail;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace Catron_Computer_Technology_PROEL4W_FINALS_.Helpers
{
    /// <summary>
    /// Sends password-reset emails. Uses SMTP from appsettings "Email" section when configured;
    /// otherwise logs the link so it can still be recovered in Development.
    /// </summary>
    public static class EmailHelper
    {
        public static async Task SendAdminPasswordResetAsync(
            string toEmail,
            string username,
            string resetLink,
            IServiceProvider services)
        {
            await SendPasswordResetAsync(
                toEmail,
                username,
                resetLink,
                "Catron Admin — Password Reset",
                "back-office account",
                services);
        }

        public static async Task SendCustomerPasswordResetAsync(
            string toEmail,
            string name,
            string resetLink,
            IServiceProvider services)
        {
            await SendPasswordResetAsync(
                toEmail,
                name,
                resetLink,
                "Catron — Password Reset",
                "store account",
                services);
        }

        public static async Task SendPasswordResetAsync(
            string toEmail,
            string displayName,
            string resetLink,
            string subject,
            string accountKind,
            IServiceProvider services)
        {
            var config = services.GetService<IConfiguration>();
            var logger = services.GetService<ILoggerFactory>()?.CreateLogger("EmailHelper");

            var body =
                $"Hello {displayName},\n\n" +
                $"A password reset was requested for your Catron {accountKind}.\n\n" +
                $"Reset link (valid 1 hour):\n{resetLink}\n\n" +
                "If you did not request this, you can ignore this message.\n\n" +
                "— Catron Computer Technology";

            var host = config?["Email:SmtpHost"];
            var from = config?["Email:From"] ?? "noreply@catroncomputer.com";
            var user = config?["Email:Username"];
            var pass = config?["Email:Password"];
            var port = int.TryParse(config?["Email:SmtpPort"], out var p) ? p : 587;
            var enableSsl = !string.Equals(config?["Email:EnableSsl"], "false", StringComparison.OrdinalIgnoreCase);

            if (string.IsNullOrWhiteSpace(host))
            {
                logger?.LogWarning(
                    "Email SMTP not configured. Password reset for {Email}. Link: {Link}",
                    toEmail, resetLink);
                return;
            }

            try
            {
                using var msg = new MailMessage(from, toEmail, subject, body);
                using var client = new SmtpClient(host, port)
                {
                    EnableSsl = enableSsl,
                    DeliveryMethod = SmtpDeliveryMethod.Network
                };
                if (!string.IsNullOrWhiteSpace(user))
                    client.Credentials = new NetworkCredential(user, pass ?? "");

                await client.SendMailAsync(msg);
                logger?.LogInformation("Password reset email sent to {Email}", toEmail);
            }
            catch (Exception ex)
            {
                logger?.LogError(ex, "Failed to send password reset email to {Email}. Link: {Link}", toEmail, resetLink);
            }
        }
    }
}
